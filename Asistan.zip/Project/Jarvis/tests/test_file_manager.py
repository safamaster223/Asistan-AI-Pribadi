import unittest
import os
import shutil
import tempfile
from core import file_manager

class TestFileManager(unittest.TestCase):
    def setUp(self):
        # Create a temporary directory structure for tests
        self.test_dir = tempfile.mkdtemp()
        self.safe_root = os.path.abspath(os.path.realpath(self.test_dir))

        # Create some mock files and directories
        self.mock_file_path = os.path.join(self.safe_root, "test.txt")
        with open(self.mock_file_path, 'w', encoding='utf-8') as f:
            f.write("Hello World")

        self.mock_sub_dir = os.path.join(self.safe_root, "subdir")
        os.makedirs(self.mock_sub_dir, exist_ok=True)
        self.sub_file_path = os.path.join(self.mock_sub_dir, "sub.txt")
        with open(self.sub_file_path, 'w', encoding='utf-8') as f:
            f.write("Subfile content")

    def tearDown(self):
        # Clean up temporary directory structure
        shutil.rmtree(self.test_dir)

    def test_is_path_safe(self):
        # Paths inside root
        self.assertTrue(file_manager.is_path_safe(self.mock_file_path, [self.safe_root]))
        self.assertTrue(file_manager.is_path_safe(self.sub_file_path, [self.safe_root]))
        self.assertTrue(file_manager.is_path_safe(self.safe_root, [self.safe_root]))

        # Path traversal checks
        traversal_path = os.path.join(self.safe_root, "..", "outside.txt")
        self.assertFalse(file_manager.is_path_safe(traversal_path, [self.safe_root]))

        # Absolute system paths checks
        self.assertFalse(file_manager.is_path_safe("C:\\Windows\\system32", [self.safe_root]))

    def test_read_file(self):
        # Test reading file inside root
        content = file_manager.read_file(self.mock_file_path, [self.safe_root])
        self.assertEqual(content, "Hello World")

        # Test reading missing file
        missing_path = os.path.join(self.safe_root, "missing.txt")
        err = file_manager.read_file(missing_path, [self.safe_root])
        self.assertTrue(err.startswith("Error:"))

        # Test path traversal reading
        traversal_path = os.path.join(self.safe_root, "..", "outside.txt")
        err = file_manager.read_file(traversal_path, [self.safe_root])
        self.assertTrue("blocked" in err)

    def test_write_file(self):
        # Test writing safe file
        new_file = os.path.join(self.safe_root, "new.txt")
        res = file_manager.write_file(new_file, "New Content", [self.safe_root])
        self.assertTrue(res.startswith("Success:"))
        self.assertEqual(file_manager.read_file(new_file, [self.safe_root]), "New Content")

        # Test writing inside new nested directories
        nested_file = os.path.join(self.safe_root, "newdir", "nested.txt")
        res = file_manager.write_file(nested_file, "Nested Content", [self.safe_root])
        self.assertTrue(res.startswith("Success:"))
        self.assertEqual(file_manager.read_file(nested_file, [self.safe_root]), "Nested Content")

        # Test path traversal writing
        traversal_path = os.path.join(self.safe_root, "..", "outside.txt")
        res = file_manager.write_file(traversal_path, "Trap", [self.safe_root])
        self.assertTrue("blocked" in res)

    def test_delete_file(self):
        # Delete file
        res = file_manager.delete_file(self.sub_file_path, [self.safe_root])
        self.assertTrue(res.startswith("Success:"))
        self.assertFalse(os.path.exists(self.sub_file_path))

        # Delete directory
        res = file_manager.delete_file(self.mock_sub_dir, [self.safe_root])
        self.assertTrue(res.startswith("Success:"))
        self.assertFalse(os.path.exists(self.mock_sub_dir))

        # Path traversal delete
        traversal_path = os.path.join(self.safe_root, "..", "outside.txt")
        res = file_manager.delete_file(traversal_path, [self.safe_root])
        self.assertTrue("blocked" in res)

    def test_list_directory_contents(self):
        items = file_manager.list_directory_contents(self.safe_root, [self.safe_root])
        self.assertIsInstance(items, list)
        item_names = [i["name"] for i in items]
        self.assertIn("test.txt", item_names)
        self.assertIn("subdir", item_names)

    def test_get_project_tree(self):
        tree = file_manager.get_project_tree(self.safe_root)
        self.assertIn("test.txt", tree)
        self.assertIn("subdir", tree)
        self.assertIn("sub.txt", tree["subdir"])

    def test_read_pdf_pypdf_missing(self):
        import sys
        from unittest.mock import patch

        pdf_path = os.path.join(self.safe_root, "test.pdf")
        with open(pdf_path, 'wb') as f:
            f.write(b"%PDF dummy data")

        # Mock pypdf import failing
        with patch.dict('sys.modules', {'pypdf': None}):
            result = file_manager.read_file(pdf_path, [self.safe_root])
            self.assertIn("pypdf", result.lower())
            self.assertIn("requirements.txt", result.lower())

    def test_read_pdf_success(self):
        from unittest.mock import MagicMock, patch

        mock_pypdf = MagicMock()
        mock_reader = MagicMock()
        mock_page1 = MagicMock()
        mock_page1.extract_text.return_value = "Hello page one"
        mock_page2 = MagicMock()
        mock_page2.extract_text.return_value = "Hello page two"
        mock_reader.pages = [mock_page1, mock_page2]
        mock_pypdf.PdfReader.return_value = mock_reader

        pdf_path = os.path.join(self.safe_root, "test.pdf")
        with open(pdf_path, 'wb') as f:
            f.write(b"%PDF dummy data")

        with patch.dict('sys.modules', {'pypdf': mock_pypdf}):
            result = file_manager.read_file(pdf_path, [self.safe_root])
            self.assertIn("--- Page 1 ---\nHello page one", result)
            self.assertIn("--- Page 2 ---\nHello page two", result)

if __name__ == "__main__":
    unittest.main()
