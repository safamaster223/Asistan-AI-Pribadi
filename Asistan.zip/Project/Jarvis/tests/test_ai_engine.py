import unittest
import os
import shutil
import tempfile
import subprocess
from unittest.mock import patch, MagicMock
from core.ai_engine import AIEngine

class TestAIEngineOpenResource(unittest.TestCase):
    def setUp(self):
        self.settings = {
            "safe_workspace_dir": os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
        }
        self.engine = AIEngine(self.settings)

    @patch("webbrowser.open")
    def test_open_web_url(self, mock_web_open):
        res = self.engine.execute_open_resource("https://github.com", False, None, os.getcwd(), [os.getcwd()])
        self.assertIn("Success", res)
        mock_web_open.assert_called_once_with("https://github.com")

    @patch("webbrowser.open")
    def test_open_web_url_www(self, mock_web_open):
        res = self.engine.execute_open_resource("www.google.com", False, None, os.getcwd(), [os.getcwd()])
        self.assertIn("Success", res)
        mock_web_open.assert_called_once_with("https://www.google.com")

    @patch("webbrowser.open")
    def test_open_resource_sanitization(self, mock_web_open):
        # Test percent-encoding decoding
        res = self.engine.execute_open_resource("https%3A//github.com", False, None, os.getcwd(), [os.getcwd()])
        self.assertIn("Success", res)
        mock_web_open.assert_any_call("https://github.com")

        # Test stripping whitespaces and nested quotes
        res = self.engine.execute_open_resource("  \"https://github.com\"  ", False, None, os.getcwd(), [os.getcwd()])
        self.assertIn("Success", res)
        mock_web_open.assert_any_call("https://github.com")

        # Test protocol typo: missing colon (https//)
        res = self.engine.execute_open_resource("https//github.com", False, None, os.getcwd(), [os.getcwd()])
        self.assertIn("Success", res)
        mock_web_open.assert_any_call("https://github.com")

        # Test protocol typo: missing slash (https:/)
        res = self.engine.execute_open_resource("https:/github.com", False, None, os.getcwd(), [os.getcwd()])
        self.assertIn("Success", res)
        mock_web_open.assert_any_call("https://github.com")

        # Test protocol typo with http (http//)
        res = self.engine.execute_open_resource("http//github.com", False, None, os.getcwd(), [os.getcwd()])
        self.assertIn("Success", res)
        mock_web_open.assert_any_call("http://github.com")

        # Test protocol typo with space and backslash (https \)
        res = self.engine.execute_open_resource("https \\ github.com", False, None, os.getcwd(), [os.getcwd()])
        self.assertIn("Success", res)
        mock_web_open.assert_any_call("https://github.com")

    @patch("webbrowser.open")
    def test_open_resource_local_files_not_matched(self, mock_web_open):
        # Verify that local file-like names are NOT sanitized into URLs
        res1 = self.engine.execute_open_resource("https_notes.txt", False, None, os.getcwd(), [os.getcwd()])
        self.assertIn("Error", res1)
        mock_web_open.assert_not_called()

        res2 = self.engine.execute_open_resource("http_requests.log", False, None, os.getcwd(), [os.getcwd()])
        self.assertIn("Error", res2)
        mock_web_open.assert_not_called()

        res3 = self.engine.execute_open_resource("https/notes.txt", False, None, os.getcwd(), [os.getcwd()])
        self.assertIn("Error", res3)
        mock_web_open.assert_not_called()

    @patch("os.startfile")
    def test_open_whitelisted_protocol_spotify(self, mock_startfile):
        res = self.engine.execute_open_resource("spotify:track:123", False, None, os.getcwd(), [os.getcwd()])
        self.assertIn("Success", res)
        mock_startfile.assert_called_once_with("spotify:track:123")

    @patch("os.startfile")
    def test_open_whitelisted_app_spotify(self, mock_startfile):
        res = self.engine.execute_open_resource("spotify", False, None, os.getcwd(), [os.getcwd()])
        self.assertIn("Success", res)
        mock_startfile.assert_called_once_with("spotify:")

    @patch("subprocess.Popen")
    @patch("shutil.which")
    def test_open_current_project_in_vscode(self, mock_which, mock_popen):
        mock_which.return_value = "code"
        res = self.engine.execute_open_resource("code", False, None, os.getcwd(), [os.getcwd()])
        self.assertIn("Success", res)
        mock_popen.assert_called_once()

    def test_open_unsafe_target_blocked(self):
        res = self.engine.execute_open_resource("C:\\Windows\\System32\\calc.exe", False, None, os.getcwd(), [os.getcwd()])
        self.assertIn("Error", res)

    @patch("subprocess.run")
    def test_autosave_non_git_repo(self, mock_run):
        # Mock git check failing (not a repo)
        mock_run.return_value = MagicMock(returncode=1, stdout="false")
        res = self.engine.execute_open_resource("https://github.com", True, "Auto commit", os.getcwd(), [os.getcwd()])
        self.assertIn("Warning: Active workspace is not a git repository", res)

    @patch("subprocess.run")
    def test_autosave_git_repo_clean(self, mock_run):
        # Mock git repo check succeeds, status check returns empty (clean)
        mock_run.side_effect = [
            MagicMock(returncode=0, stdout="true\n"),  # is inside work tree
            MagicMock(returncode=0, stdout=""),        # git status clean
            MagicMock(returncode=0)                    # webbrowser call
        ]
        with patch("webbrowser.open") as mock_web_open:
            res = self.engine.execute_open_resource("https://github.com", True, "Auto commit", os.getcwd(), [os.getcwd()])
            self.assertIn("Info: Git workspace is clean", res)

    @patch("subprocess.run")
    def test_autosave_git_repo_dirty(self, mock_run):
        # Mock dirty git status, and successful add/commit
        mock_run.side_effect = [
            MagicMock(returncode=0, stdout="true\n"),   # is inside work tree
            MagicMock(returncode=0, stdout="M file.py"),# git status dirty
            MagicMock(returncode=0),                    # git add
            MagicMock(returncode=0)                     # git commit
        ]
        with patch("webbrowser.open") as mock_web_open:
            res = self.engine.execute_open_resource("https://github.com", True, "Auto commit", os.getcwd(), [os.getcwd()])
            self.assertIn("Success: Active project modifications automatically saved", res)

class TestAIEngineNewTools(unittest.TestCase):
    def setUp(self):
        self.settings = {
            "safe_workspace_dir": os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
        }
        self.engine = AIEngine(self.settings)

    @patch("urllib.request.urlopen")
    def test_youtube_search_success(self, mock_urlopen):
        # Mock HTML returned from YouTube search query
        mock_html = """
        <html>
        <body>
        <script>
        var ytInitialData = {
          "contents": {
            "twoColumnSearchResultRenderer": {
              "primaryContents": {
                "sectionListRenderer": {
                  "contents": [
                    {
                      "itemSectionRenderer": {
                        "contents": [
                          {
                            "videoRenderer": {
                              "videoId": "test_id_123",
                              "title": {
                                "runs": [{"text": "Nidji - Hapus Aku"}]
                              },
                              "ownerText": {
                                "runs": [{"text": "Nidji Official"}]
                              },
                              "lengthText": {
                                "simpleText": "4:15"
                              }
                            }
                          }
                        ]
                      }
                    }
                  ]
                }
              }
            }
          }
        };
        </script>
        </body>
        </html>
        """
        mock_response = MagicMock()
        mock_response.read.return_value = mock_html.encode("utf-8")
        mock_urlopen.return_value.__enter__.return_value = mock_response

        res_str = self.engine.execute_youtube_search("nidji", 1)
        import json
        res = json.loads(res_str)

        self.assertEqual(len(res), 1)
        self.assertEqual(res[0]["title"], "Nidji - Hapus Aku")
        self.assertEqual(res[0]["channel"], "Nidji Official")
        self.assertEqual(res[0]["video_url"], "https://www.youtube.com/watch?v=test_id_123")
        self.assertEqual(res[0]["duration"], "4:15")

    @patch("sys.platform", "win32")
    @patch("ctypes.windll.user32.MapVirtualKeyW")
    @patch("ctypes.windll.user32.keybd_event")
    def test_media_control_win32_success(self, mock_keybd_event, mock_map_virtual_key):
        mock_map_virtual_key.return_value = 0x3E

        res = self.engine.execute_media_control("play_pause")
        self.assertIn("Success", res)

        # Verify key down and key up were triggered
        self.assertEqual(mock_keybd_event.call_count, 2)
        # First call args: (vk_code, scan_code, flags, extra_info) -> VK_MEDIA_PLAY_PAUSE is 0xCD
        mock_keybd_event.assert_any_call(0xCD, 0x3E, 1, 0)
        # Second call args (keyup) -> flag 1 | 2 = 3
        mock_keybd_event.assert_any_call(0xCD, 0x3E, 3, 0)

    @patch("sys.platform", "darwin")
    def test_media_control_non_win32_fails(self):
        res = self.engine.execute_media_control("play_pause")
        self.assertIn("Error: Media controls are only supported on Windows.", res)

class TestAIEngineBrowserTools(unittest.TestCase):
    def setUp(self):
        self.settings = {
            "safe_workspace_dir": os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
        }
        self.engine = AIEngine(self.settings)

    def test_clean_text_html_parser(self):
        from core.ai_engine import CleanTextHTMLParser
        html = """
        <html>
        <head><title>Ignore me</title><style>body { color: red; }</style></head>
        <body>
            <script type="text/javascript">
                console.log("ignore scripts");
            </script>
            <div class="content">
                <h1>Hello World</h1>
                <p>This is a <b>paragraph</b> with some <a href="#">link</a>.</p>
                <!-- comment to ignore -->
                <svg><path d="M10 10"/></svg>
            </div>
            <footer>Ignore footer? No, only specific tags like script/style.</footer>
        </body>
        </html>
        """
        parser = CleanTextHTMLParser()
        parser.feed(html)
        text = parser.get_clean_text()

        # Verify text extracted contains hello world, paragraph and footer, but no script, style or head content
        self.assertIn("Hello World", text)
        self.assertIn("This is a paragraph with some link.", text)
        self.assertIn("Ignore footer? No, only specific tags like script/style.", text)
        self.assertNotIn("ignore scripts", text)
        self.assertNotIn("Ignore me", text)
        self.assertNotIn("color: red", text)

    @patch("sys.platform", "win32")
    @patch("ctypes.windll.user32.GetForegroundWindow")
    @patch("ctypes.windll.user32.GetWindowTextLengthW")
    @patch("ctypes.windll.user32.GetWindowTextW")
    @patch("ctypes.windll.user32.OpenClipboard")
    @patch("ctypes.windll.user32.GetClipboardData")
    @patch("ctypes.windll.kernel32.GlobalLock")
    @patch("ctypes.windll.kernel32.GlobalUnlock")
    @patch("ctypes.windll.user32.CloseClipboard")
    @patch("ctypes.windll.user32.keybd_event")
    def test_get_active_browser_info_success(self, mock_keybd_event, mock_close_clip, mock_unlock, mock_lock, mock_get_clip, mock_open_clip, mock_get_win_text, mock_get_win_len, mock_get_foreground):
        import json
        mock_get_foreground.return_value = 12345
        mock_get_win_len.return_value = 25

        # Mock window title to match Chrome
        def side_effect_win_text(hwnd, buf, length):
            buf.value = "Google Chrome - Github"
            return 25
        mock_get_win_text.side_effect = side_effect_win_text

        # Mock clipboard operations to return a URL
        mock_open_clip.return_value = True
        mock_get_clip.return_value = 9999
        mock_lock.return_value = 8888

        # Mocking ctypes.c_wchar_p conversion or returning string pointer
        with patch("ctypes.c_wchar_p") as mock_c_wchar_p:
            mock_c_wchar_p.return_value = MagicMock(value="https://github.com/myrepo")
            res_str = self.engine.execute_get_active_browser_info()

        res = json.loads(res_str)
        self.assertTrue(res["is_browser"])
        self.assertEqual(res["active_window_title"], "Google Chrome - Github")
        self.assertEqual(res["url"], "https://github.com/myrepo")

    @patch("sys.platform", "darwin")
    def test_get_active_browser_info_non_win32(self):
        import json
        res_str = self.engine.execute_get_active_browser_info()
        res = json.loads(res_str)
        self.assertIn("error", res)

    @patch("requests.get")
    def test_read_webpage_summary_success(self, mock_get):
        mock_response = MagicMock()
        mock_response.text = "<html><body><h1>Article Header</h1><p>Main content text.</p></body></html>"
        mock_response.encoding = "utf-8"
        mock_get.return_value = mock_response

        res = self.engine.execute_read_webpage_summary("https://example.com/article")
        self.assertIn("Article Header", res)
        self.assertIn("Main content text.", res)

if __name__ == "__main__":
    unittest.main()
