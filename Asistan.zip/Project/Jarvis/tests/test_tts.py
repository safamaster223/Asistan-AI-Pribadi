import unittest
from unittest.mock import patch, MagicMock
import sys
import queue

from core.tts import TTSManager, TTSWorker

class TestTTS(unittest.TestCase):
    def test_clean_markdown(self):
        manager = TTSManager()

        # Test basic markdown stripping
        self.assertEqual(manager.clean_markdown("Hello *world*!"), "Hello world!")
        self.assertEqual(manager.clean_markdown("This is _italic_ and `code`"), "This is italic and code")

        # Test code block stripping
        self.assertEqual(
            manager.clean_markdown("Before\n```python\nprint('hello')\n```\nAfter"),
            "Before\n[code block]\nAfter"
        )

        # Test links stripping
        self.assertEqual(manager.clean_markdown("Check [Google](https://google.com) out"), "Check Google out")

        # Test raw URL stripping
        self.assertEqual(manager.clean_markdown("Visit https://example.com/test for info"), "Visit  for info")

        # Test HTML tag stripping
        self.assertEqual(manager.clean_markdown("Hello <br/> <b>world</b>"), "Hello  world")

        # Test empty input
        self.assertEqual(manager.clean_markdown(""), "")
        self.assertEqual(manager.clean_markdown(None), "")

    def test_manager_initialization(self):
        manager = TTSManager()
        self.assertIsNotNone(manager.tts_queue)
        if sys.platform == "win32":
            self.assertIsNotNone(manager.worker)
            self.assertTrue(manager.worker.is_alive())
            # Clean up background thread
            manager.tts_queue.put(None)
            manager.worker.join(timeout=1.0)
        else:
            self.assertIsNone(manager.worker)

    @patch("sys.platform", "win32")
    def test_lazy_initialization_on_speak(self):
        mock_pythoncom = MagicMock()
        mock_pythoncom.COINIT_MULTITHREADED = 0
        mock_win32com_client = MagicMock()

        modules = {
            "pythoncom": mock_pythoncom,
            "win32com": MagicMock(),
            "win32com.client": mock_win32com_client
        }

        with patch.dict("sys.modules", modules):
            q = queue.Queue()
            worker = TTSWorker(q)

            self.assertFalse(worker._com_initialized)
            self.assertIsNone(worker._voice_engine)

            # Put stop task and None sentinel. COM should not initialize since action != "speak"
            q.put(("stop", ""))
            q.put(None)

            worker.run()

            mock_pythoncom.CoInitializeEx.assert_not_called()
            mock_pythoncom.CoInitialize.assert_not_called()
            mock_win32com_client.Dispatch.assert_not_called()
            self.assertFalse(worker._com_initialized)

            # Now test with speak task. COM should initialize.
            q = queue.Queue()
            worker = TTSWorker(q)

            q.put(("speak", "Hello"))
            q.put(None)

            worker.run()

            mock_pythoncom.CoInitializeEx.assert_called_once_with(0)
            mock_pythoncom.CoInitialize.assert_not_called()
            mock_win32com_client.Dispatch.assert_called_once_with("SAPI.SpVoice")
            self.assertTrue(worker._com_initialized)

    @patch("sys.platform", "win32")
    def test_lazy_initialization_fallback_to_coinitialize(self):
        mock_pythoncom = MagicMock()
        mock_pythoncom.COINIT_MULTITHREADED = 0
        mock_pythoncom.CoInitializeEx.side_effect = Exception("MTA failed")
        mock_win32com_client = MagicMock()

        modules = {
            "pythoncom": mock_pythoncom,
            "win32com": MagicMock(),
            "win32com.client": mock_win32com_client
        }

        with patch.dict("sys.modules", modules):
            q = queue.Queue()
            worker = TTSWorker(q)

            q.put(("speak", "Hello"))
            q.put(None)

            worker.run()

            # CoInitializeEx was tried and failed
            mock_pythoncom.CoInitializeEx.assert_called_once_with(0)
            # Fallback CoInitialize should be called
            mock_pythoncom.CoInitialize.assert_called_once()
            # Dispatch should still succeed
            mock_win32com_client.Dispatch.assert_called_once_with("SAPI.SpVoice")
            self.assertTrue(worker._com_initialized)

    @patch("sys.platform", "win32")
    def test_lazy_initialization_both_fail(self):
        mock_pythoncom = MagicMock()
        mock_pythoncom.COINIT_MULTITHREADED = 0
        mock_pythoncom.CoInitializeEx.side_effect = Exception("MTA failed")
        mock_pythoncom.CoInitialize.side_effect = Exception("STA failed")
        mock_win32com_client = MagicMock()

        modules = {
            "pythoncom": mock_pythoncom,
            "win32com": MagicMock(),
            "win32com.client": mock_win32com_client
        }

        with patch.dict("sys.modules", modules):
            q = queue.Queue()
            worker = TTSWorker(q)

            q.put(("speak", "Hello"))
            q.put(None)

            worker.run()

            mock_pythoncom.CoInitializeEx.assert_called_once_with(0)
            mock_pythoncom.CoInitialize.assert_called_once()
            mock_win32com_client.Dispatch.assert_not_called()
            self.assertFalse(worker._com_initialized)

if __name__ == "__main__":
    unittest.main()
