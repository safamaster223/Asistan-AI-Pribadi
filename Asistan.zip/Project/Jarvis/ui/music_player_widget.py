import os
from PyQt6.QtCore import Qt, pyqtSignal, pyqtSlot, QTimer
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton, 
                             QLabel, QSlider, QFrame, QListWidget, QListWidgetItem,
                             QLineEdit, QProgressBar)
from PyQt6.QtGui import QPixmap, QIcon
import requests
from io import BytesIO

class MusicPlayerWidget(QFrame):
    def __init__(self, audio_engine, parent=None):
        super().__init__(parent)
        self.audio_engine = audio_engine
        self.init_ui()
        
        # Timer for updating progress bar
        self.update_timer = QTimer(self)
        self.update_timer.timeout.connect(self.update_progress)
        self.update_timer.start(1000) # Update every second

    def init_ui(self):
        self.setObjectName("MusicPlayerWidget")
        self.setStyleSheet("""
            #MusicPlayerWidget {
                background-color: rgba(15, 23, 42, 0.85);
                border-top: 1px solid rgba(0, 240, 255, 0.3);
                border-radius: 0px;
            }
            QLabel {
                color: #F8FAFC;
                font-family: 'Segoe UI', sans-serif;
            }
            QPushButton {
                background-color: transparent;
                color: #00f0ff;
                border: none;
                font-size: 18px;
            }
            QPushButton:hover {
                color: #d946ef;
            }
            QSlider::groove:horizontal {
                border: 1px solid #999999;
                height: 4px;
                background: #333333;
                margin: 2px 0;
            }
            QSlider::handle:horizontal {
                background: #00f0ff;
                border: 1px solid #00f0ff;
                width: 12px;
                margin: -4px 0;
                border-radius: 6px;
            }
            QLineEdit {
                background-color: rgba(0, 0, 0, 0.5);
                color: white;
                border: 1px solid rgba(0, 240, 255, 0.3);
                border-radius: 4px;
                padding: 4px;
            }
        """)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(8, 8, 8, 8)
        main_layout.setSpacing(4)

        # --- Top Section: Search & Results ---
        search_layout = QHBoxLayout()
        self.search_input = QLineEdit(self)
        self.search_input.setPlaceholderText("Search music on YouTube...")
        self.search_input.returnPressed.connect(self.perform_search)
        
        self.search_btn = QPushButton("🔍", self)
        self.search_btn.clicked.connect(self.perform_search)
        
        search_layout.addWidget(self.search_input)
        search_layout.addWidget(self.search_btn)
        main_layout.addLayout(search_layout)

        self.results_list = QListWidget(self)
        self.results_list.setFixedHeight(100)
        self.results_list.setVisible(False)
        self.results_list.itemDoubleClicked.connect(self.play_selected_result)
        self.results_list.setStyleSheet("""
            QListWidget {
                background-color: rgba(0, 0, 0, 0.6);
                border: 1px solid rgba(0, 240, 255, 0.2);
                color: white;
            }
            QListWidget::item:selected {
                background-color: rgba(0, 240, 255, 0.2);
            }
        """)
        main_layout.addWidget(self.results_list)

        # --- Bottom Section: Player Controls ---
        player_layout = QHBoxLayout()
        
        # Thumbnail & Info
        self.thumbnail_label = QLabel(self)
        self.thumbnail_label.setFixedSize(40, 40)
        self.thumbnail_label.setStyleSheet("background-color: #222; border-radius: 4px;")
        self.thumbnail_label.setScaledContents(True)
        
        info_layout = QVBoxLayout()
        self.title_label = QLabel("No track playing", self)
        self.title_label.setStyleSheet("font-weight: bold; font-size: 12px;")
        self.channel_label = QLabel("-", self)
        self.channel_label.setStyleSheet("font-size: 10px; color: #aaa;")
        info_layout.addWidget(self.title_label)
        info_layout.addWidget(self.channel_label)
        
        player_layout.addWidget(self.thumbnail_label)
        player_layout.addLayout(info_layout)
        player_layout.addStretch()

        # Controls
        controls_layout = QHBoxLayout()
        self.prev_btn = QPushButton("⏮", self)
        self.play_pause_btn = QPushButton("▶", self)
        self.play_pause_btn.clicked.connect(self.toggle_play_pause)
        self.next_btn = QPushButton("⏭", self)
        self.stop_btn = QPushButton("⏹", self)
        self.stop_btn.clicked.connect(self.stop_playback)
        
        controls_layout.addWidget(self.prev_btn)
        controls_layout.addWidget(self.play_pause_btn)
        controls_layout.addWidget(self.next_btn)
        controls_layout.addWidget(self.stop_btn)
        
        player_layout.addLayout(controls_layout)
        player_layout.addStretch()
        
        # Volume
        self.volume_slider = QSlider(Qt.Orientation.Horizontal, self)
        self.volume_slider.setRange(0, 100)
        self.volume_slider.setValue(50)
        self.volume_slider.setFixedWidth(80)
        self.volume_slider.valueChanged.connect(self.change_volume)
        
        player_layout.addWidget(QLabel("🔊"))
        player_layout.addWidget(self.volume_slider)

        main_layout.addLayout(player_layout)

        # Progress Bar
        progress_layout = QHBoxLayout()
        self.time_current = QLabel("0:00", self)
        self.time_current.setStyleSheet("font-size: 10px;")
        
        self.progress_slider = QSlider(Qt.Orientation.Horizontal, self)
        self.progress_slider.setRange(0, 100)
        self.progress_slider.sliderMoved.connect(self.seek_position)
        
        self.time_total = QLabel("0:00", self)
        self.time_total.setStyleSheet("font-size: 10px;")
        
        progress_layout.addWidget(self.time_current)
        progress_layout.addWidget(self.progress_slider)
        progress_layout.addWidget(self.time_total)
        
        main_layout.addLayout(progress_layout)
        
        self.current_search_results = []

    def perform_search(self):
        query = self.search_input.text().strip()
        if not query:
            return
            
        self.search_btn.setText("⏳")
        self.search_btn.setEnabled(False)
        
        # Run search in background thread to avoid freezing UI
        import threading
        def _search():
            results = self.audio_engine.search_and_extract(query)
            # Update UI in main thread
            from PyQt6.QtCore import QMetaObject, Q_ARG
            QMetaObject.invokeMethod(self, "update_search_results", 
                                     Qt.ConnectionType.QueuedConnection, 
                                     Q_ARG(list, results))
                                     
        threading.Thread(target=_search, daemon=True).start()

    @pyqtSlot(list)
    def update_search_results(self, results):
        self.current_search_results = results
        self.results_list.clear()
        
        if results:
            for res in results:
                duration_str = self.format_time(res.get('duration', 0))
                item_text = f"{res.get('title')} - {res.get('channel')} ({duration_str})"
                item = QListWidgetItem(item_text)
                item.setData(Qt.ItemDataRole.UserRole, res)
                self.results_list.addItem(item)
            self.results_list.setVisible(True)
        else:
            self.results_list.addItem("No results found.")
            self.results_list.setVisible(True)
            
        self.search_btn.setText("🔍")
        self.search_btn.setEnabled(True)

    def play_selected_result(self, item):
        track_info = item.data(Qt.ItemDataRole.UserRole)
        if not track_info:
            return
            
        self.results_list.setVisible(False)
        self.title_label.setText(track_info.get('title', 'Unknown Title')[:30] + "...")
        self.channel_label.setText(track_info.get('channel', 'Unknown Channel'))
        
        # Load thumbnail
        thumb_url = track_info.get('thumbnail')
        if thumb_url:
            self.load_thumbnail(thumb_url)
            
        duration = track_info.get('duration', 0)
        self.progress_slider.setRange(0, duration)
        self.time_total.setText(self.format_time(duration))
        
        self.play_pause_btn.setText("⏸")
        self.audio_engine.play_track(track_info)

    def load_thumbnail(self, url):
        import threading
        def _load():
            try:
                response = requests.get(url)
                image_data = response.content
                from PyQt6.QtCore import QMetaObject, Q_ARG
                QMetaObject.invokeMethod(self, "set_thumbnail_image", 
                                         Qt.ConnectionType.QueuedConnection, 
                                         Q_ARG(bytes, image_data))
            except:
                pass
        threading.Thread(target=_load, daemon=True).start()

    @pyqtSlot(bytes)
    def set_thumbnail_image(self, image_data):
        pixmap = QPixmap()
        pixmap.loadFromData(image_data)
        self.thumbnail_label.setPixmap(pixmap)

    def toggle_play_pause(self):
        if self.audio_engine.is_playing:
            self.audio_engine.pause()
            self.play_pause_btn.setText("▶")
        else:
            if self.audio_engine.current_track_info:
                self.audio_engine.resume()
                self.play_pause_btn.setText("⏸")

    def stop_playback(self):
        self.audio_engine.stop()
        self.play_pause_btn.setText("▶")
        self.progress_slider.setValue(0)
        self.time_current.setText("0:00")

    def change_volume(self, value):
        self.audio_engine.set_volume(value)

    def seek_position(self, position):
        self.audio_engine.set_position(position)

    def update_progress(self):
        if self.audio_engine.is_playing:
            pos = self.audio_engine.get_position()
            self.progress_slider.setValue(pos)
            self.time_current.setText(self.format_time(pos))

    def format_time(self, seconds):
        if not seconds:
            return "0:00"
        m, s = divmod(int(seconds), 60)
        h, m = divmod(m, 60)
        if h > 0:
            return f"{h}:{m:02d}:{s:02d}"
        return f"{m}:{s:02d}"
