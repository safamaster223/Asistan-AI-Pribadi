import os
from PyQt6.QtCore import Qt, pyqtSignal, pyqtSlot, QTimer, QPoint, QRect
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QTextBrowser,
                             QTextEdit, QPushButton, QComboBox, QLabel, QFrame, QProgressBar,
                             QTabWidget, QListWidget, QListWidgetItem, QDialog, QDialogButtonBox,
                             QLineEdit, QMessageBox, QInputDialog, QSlider, QApplication)
from PyQt6.QtGui import QTextCursor, QPixmap, QCursor
from ui.styles import DARK_GLASS_STYLE
from core.usage_tracker import UsageTracker
from core.audio_player import CellyaAudioEngine


class TextEditorDialog(QDialog):
    def __init__(self, file_path, parent=None):
        super().__init__(parent)
        self.file_path = file_path
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle(f"Editing: {os.path.basename(self.file_path)}")
        self.resize(500, 400)
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)
        self.setStyleSheet("""
            QDialog {
                background-color: #1E1E1E;
                color: #F8FAFC;
            }
            QTextEdit {
                background-color: #121212;
                color: #F8FAFC;
                border: 1px solid rgba(0, 240, 255, 0.3);
                font-family: 'Consolas', monospace;
                font-size: 13px;
            }
            QPushButton {
                background-color: #0EA5E9;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 5px 12px;
                min-width: 60px;
            }
            QPushButton:hover {
                background-color: #0284C7;
            }
        """)

        layout = QVBoxLayout(self)
        self.editor = QTextEdit(self)

        try:
            with open(self.file_path, 'r', encoding='utf-8', errors='replace') as f:
                self.editor.setPlainText(f.read())
        except Exception as e:
            self.editor.setPlainText(f"Error loading file: {e}")

        layout.addWidget(self.editor)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel, self)
        buttons.accepted.connect(self.save_and_close)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def save_and_close(self):
        try:
            with open(self.file_path, 'w', encoding='utf-8') as f:
                f.write(self.editor.toPlainText())
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save file: {e}")


class ChatWindow(QWidget):
    send_message = pyqtSignal(str, str, str, str)  # prompt, model_name, provider, image_base64
    clear_requested = pyqtSignal()
    capture_screen_requested = pyqtSignal()

    # Session management signals
    load_session_requested = pyqtSignal(str)
    delete_session_requested = pyqtSignal(str)
    new_session_requested = pyqtSignal()

    # Resize edge threshold (pixels)
    EDGE_MARGIN = 8

    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.pending_image = None
        self.audio_engine = CellyaAudioEngine()
        self.audio_engine.track_ended.connect(self.on_track_ended)
        self.audio_engine.error_occurred.connect(self.on_audio_error)
        self.audio_engine.track_loaded.connect(self.on_track_loaded)

        # Drag & Resize state
        self._dragging = False
        self._resizing = False
        self._resize_edge = None
        self._drag_start_pos = QPoint()
        self._drag_start_geom = QRect()

        self.init_ui()

        # Timer for updating audio progress bar
        self.progress_timer = QTimer(self)
        self.progress_timer.timeout.connect(self.update_audio_progress)
        self.progress_timer.start(1000)

    def init_ui(self):
        # Frameless dialog style window
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setObjectName("ChatWindowWidget")
        self.setStyleSheet(DARK_GLASS_STYLE)

        # Minimum & maximum size agar tidak melar gila-gilaan
        self.setMinimumSize(350, 400)
        screen = QApplication.primaryScreen()
        if screen:
            screen_geom = screen.availableGeometry()
            self.setMaximumSize(screen_geom.width(), screen_geom.height())

        # Read saved geometry settings
        geom = self.settings.get("chat_geometry", {"x": 200, "y": 100, "width": 400, "height": 650})
        # Clamp width & height agar tidak melebihi screen
        w = max(350, min(geom["width"], self.maximumWidth()))
        h = max(400, min(geom["height"], self.maximumHeight()))
        x = max(0, geom["x"])
        y = max(0, geom["y"])
        self.setGeometry(x, y, w, h)

        # Setup container frame
        self.container = QFrame(self)
        self.container.setObjectName("MainChatWindow")
        self.container.setGeometry(0, 0, self.width(), self.height())

        # Main horizontal layout (Sidebar Panel + Chat Main Panel)
        main_h_layout = QHBoxLayout(self.container)
        main_h_layout.setContentsMargins(0, 0, 0, 0)
        main_h_layout.setSpacing(0)

        # 1. Sidebar Panel
        self.sidebar_panel = QFrame(self.container)
        self.sidebar_panel.setObjectName("SidebarPanel")
        self.sidebar_panel.setFixedWidth(250)
        self.sidebar_panel.setVisible(False)
        main_h_layout.addWidget(self.sidebar_panel)

        sidebar_layout = QVBoxLayout(self.sidebar_panel)
        sidebar_layout.setContentsMargins(8, 8, 8, 8)
        sidebar_layout.setSpacing(8)

        # Tab Widget inside Sidebar
        self.sidebar_tabs = QTabWidget(self.sidebar_panel)
        self.sidebar_tabs.setObjectName("SidebarTabs")

        # Tab 1: Chats History list
        self.chats_tab = QWidget()
        chats_layout = QVBoxLayout(self.chats_tab)
        chats_layout.setContentsMargins(4, 4, 4, 4)
        chats_layout.setSpacing(6)

        self.new_chat_btn = QPushButton("+ New Chat", self.chats_tab)
        self.new_chat_btn.setObjectName("ActionButton")
        self.new_chat_btn.clicked.connect(self.new_session_requested.emit)
        chats_layout.addWidget(self.new_chat_btn)

        self.sessions_list = QListWidget(self.chats_tab)
        self.sessions_list.setObjectName("SessionsList")
        self.sessions_list.itemClicked.connect(self.handle_session_clicked)
        chats_layout.addWidget(self.sessions_list)

        self.delete_chat_btn = QPushButton("Delete Chat", self.chats_tab)
        self.delete_chat_btn.setObjectName("IconButtonClose")
        self.delete_chat_btn.clicked.connect(self.handle_delete_session_clicked)
        chats_layout.addWidget(self.delete_chat_btn)

        self.sidebar_tabs.addTab(self.chats_tab, "Chats")

        # Tab 2: Files list
        self.files_tab = QWidget()
        files_layout = QVBoxLayout(self.files_tab)
        files_layout.setContentsMargins(4, 4, 4, 4)
        files_layout.setSpacing(6)

        self.create_file_btn = QPushButton("+ Create File", self.files_tab)
        self.create_file_btn.setObjectName("ActionButton")
        self.create_file_btn.clicked.connect(self.create_file_clicked)
        files_layout.addWidget(self.create_file_btn)

        self.files_list = QListWidget(self.files_tab)
        self.files_list.setObjectName("FilesList")
        self.files_list.itemDoubleClicked.connect(self.file_item_double_clicked)
        files_layout.addWidget(self.files_list)

        # File CRUD Buttons Panel
        file_ops_layout = QHBoxLayout()
        self.open_file_btn = QPushButton("Open", self.files_tab)
        self.open_file_btn.setObjectName("ActionButton")
        self.open_file_btn.clicked.connect(self.open_file_clicked)

        self.edit_file_btn = QPushButton("Edit", self.files_tab)
        self.edit_file_btn.setObjectName("ActionButton")
        self.edit_file_btn.clicked.connect(self.edit_file_clicked)

        self.delete_file_btn = QPushButton("Delete", self.files_tab)
        self.delete_file_btn.setObjectName("IconButtonClose")
        self.delete_file_btn.clicked.connect(self.delete_file_clicked)

        file_ops_layout.addWidget(self.open_file_btn)
        file_ops_layout.addWidget(self.edit_file_btn)
        file_ops_layout.addWidget(self.delete_file_btn)
        files_layout.addLayout(file_ops_layout)

        self.refresh_files_btn = QPushButton("Refresh", self.files_tab)
        self.refresh_files_btn.setObjectName("IconButton")
        self.refresh_files_btn.clicked.connect(self.refresh_files_list)
        files_layout.addWidget(self.refresh_files_btn)

        self.sidebar_tabs.addTab(self.files_tab, "Files")

        # Tab 3: Music Player
        self.music_tab = QWidget()
        music_layout = QVBoxLayout(self.music_tab)
        music_layout.setContentsMargins(4, 4, 4, 4)
        music_layout.setSpacing(6)

        # Search Bar
        search_layout = QHBoxLayout()
        self.music_search_input = QLineEdit(self.music_tab)
        self.music_search_input.setPlaceholderText("Search YouTube...")
        self.music_search_input.setStyleSheet("background-color: #121212; color: white; border: 1px solid #0EA5E9; border-radius: 4px; padding: 4px;")
        self.music_search_input.returnPressed.connect(self.search_music)

        self.music_search_btn = QPushButton("Search", self.music_tab)
        self.music_search_btn.setObjectName("ActionButton")
        self.music_search_btn.clicked.connect(self.search_music)

        search_layout.addWidget(self.music_search_input)
        search_layout.addWidget(self.music_search_btn)
        music_layout.addLayout(search_layout)

        # Results List
        self.music_results_list = QListWidget(self.music_tab)
        self.music_results_list.setObjectName("SessionsList")
        self.music_results_list.itemDoubleClicked.connect(self.play_selected_music)
        music_layout.addWidget(self.music_results_list)

        # Now Playing Info
        self.now_playing_lbl = QLabel("Not Playing", self.music_tab)
        self.now_playing_lbl.setStyleSheet("color: #00f0ff; font-weight: bold; font-size: 11px;")
        self.now_playing_lbl.setWordWrap(True)
        music_layout.addWidget(self.now_playing_lbl)

        # Progress Bar
        self.music_progress = QSlider(Qt.Orientation.Horizontal, self.music_tab)
        self.music_progress.setRange(0, 1000)
        self.music_progress.sliderReleased.connect(self.seek_music)
        music_layout.addWidget(self.music_progress)

        # Controls
        controls_layout = QHBoxLayout()

        self.music_prev_btn = QPushButton("Prev", self.music_tab)
        self.music_prev_btn.setObjectName("ActionButton")
        self.music_prev_btn.clicked.connect(self.play_prev_music)

        self.music_play_btn = QPushButton("Play", self.music_tab)
        self.music_play_btn.setObjectName("ActionButton")
        self.music_play_btn.clicked.connect(self.toggle_play_music)

        self.music_next_btn = QPushButton("Next", self.music_tab)
        self.music_next_btn.setObjectName("ActionButton")
        self.music_next_btn.clicked.connect(self.play_next_music)

        self.music_stop_btn = QPushButton("Stop", self.music_tab)
        self.music_stop_btn.setObjectName("IconButtonClose")
        self.music_stop_btn.clicked.connect(self.stop_music)

        controls_layout.addWidget(self.music_prev_btn)
        controls_layout.addWidget(self.music_play_btn)
        controls_layout.addWidget(self.music_next_btn)
        controls_layout.addWidget(self.music_stop_btn)
        music_layout.addLayout(controls_layout)

        # Repeat & Shuffle controls
        mode_layout = QHBoxLayout()

        self.music_repeat_btn = QPushButton("Repeat: OFF", self.music_tab)
        self.music_repeat_btn.setObjectName("IconButton")
        self.music_repeat_btn.clicked.connect(self.toggle_repeat)

        self.music_shuffle_btn = QPushButton("Shuffle: OFF", self.music_tab)
        self.music_shuffle_btn.setObjectName("IconButton")
        self.music_shuffle_btn.clicked.connect(self.toggle_shuffle)

        self.music_clear_queue_btn = QPushButton("Clear Queue", self.music_tab)
        self.music_clear_queue_btn.setObjectName("IconButtonClose")
        self.music_clear_queue_btn.clicked.connect(self.clear_music_queue)

        mode_layout.addWidget(self.music_repeat_btn)
        mode_layout.addWidget(self.music_shuffle_btn)
        mode_layout.addWidget(self.music_clear_queue_btn)
        music_layout.addLayout(mode_layout)

        # Queue info label
        self.queue_info_lbl = QLabel("Queue: 0 tracks", self.music_tab)
        self.queue_info_lbl.setStyleSheet("color: #8892b0; font-size: 10px;")
        music_layout.addWidget(self.queue_info_lbl)

        # Volume slider
        vol_layout = QHBoxLayout()
        vol_label = QLabel("Vol:", self.music_tab)
        vol_label.setStyleSheet("color: #8892b0; font-size: 11px;")
        self.music_volume_slider = QSlider(Qt.Orientation.Horizontal, self.music_tab)
        self.music_volume_slider.setRange(0, 100)
        self.music_volume_slider.setValue(50)
        self.music_volume_slider.valueChanged.connect(lambda v: self.audio_engine.set_volume(v))
        vol_layout.addWidget(vol_label)
        vol_layout.addWidget(self.music_volume_slider)
        music_layout.addLayout(vol_layout)

        self.sidebar_tabs.addTab(self.music_tab, "Music")

        sidebar_layout.addWidget(self.sidebar_tabs)

        # 2. Chat Main Panel
        self.chat_main_panel = QFrame(self.container)
        self.chat_main_panel.setObjectName("ChatMainPanel")
        self.chat_main_panel.setFrameShape(QFrame.Shape.NoFrame)
        main_h_layout.addWidget(self.chat_main_panel)

        # Main layout inside the chat main panel
        layout = QVBoxLayout(self.chat_main_panel)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        # 1. Header bar
        header_layout = QHBoxLayout()

        # Sidebar Toggle Button
        self.sidebar_btn = QPushButton("Menu", self)
        self.sidebar_btn.setObjectName("IconButton")
        self.sidebar_btn.setFixedSize(40, 24)
        self.sidebar_btn.clicked.connect(self.toggle_sidebar)
        header_layout.addWidget(self.sidebar_btn)

        self.title_label = QLabel("Jarvis Assistant", self)
        self.title_label.setObjectName("ChatTitle")

        # Model Selector dropdown
        self.model_combo = QComboBox(self)
        self.model_combo.setObjectName("ModelSelector")
        self.model_combo.addItem("Claude 3.5 Sonnet (Agent)", ("ag/gemini-pro-agent", "gravity"))
        self.model_combo.addItem("Claude 3.5 Flash (Agent)", ("ag/gemini-3-flash-agent", "gravity"))
        self.model_combo.addItem("Claude 3.5 Haiku (Agent)", ("ag/gemini-3-flash", "gravity"))
        self.model_combo.addItem("Claude Web (Free)", ("claude_web", "web_proxy"))
        self.model_combo.addItem("Gemini Web (Free)", ("gemini_web", "web_proxy"))
        self.model_combo.addItem("Llama 3.3 70B (Groq)", ("llama-3.3-70b-versatile", "groq"))
        self.model_combo.addItem("Gemini 2.5 Flash (Direct)", ("gemini-2.5-flash", "gemini"))
        self.model_combo.addItem("Gemini 2.5 Pro (Direct)", ("gemini-2.5-pro", "gemini"))

        self.stats_btn = QPushButton("Stats", self)
        self.stats_btn.setObjectName("IconButton")
        self.stats_btn.setFixedSize(40, 24)
        self.stats_btn.clicked.connect(self.toggle_usage_panel)

        self.voice_btn = QPushButton("Voice", self)
        self.voice_btn.setObjectName("IconButton")
        self.voice_btn.setFixedSize(40, 24)
        self.voice_btn.clicked.connect(self.toggle_voice_mode)
        self.update_voice_button_ui()

        self.close_btn = QPushButton("X", self)
        self.close_btn.setObjectName("IconButtonClose")
        self.close_btn.setFixedSize(24, 24)
        self.close_btn.clicked.connect(self.hide_animated)

        header_layout.addWidget(self.title_label)
        header_layout.addStretch()
        header_layout.addWidget(self.model_combo)
        header_layout.addWidget(self.voice_btn)
        header_layout.addWidget(self.stats_btn)
        header_layout.addWidget(self.close_btn)
        layout.addLayout(header_layout)

        # Usage Stats panel (hidden by default)
        self.usage_widget = QFrame(self)
        self.usage_widget.setObjectName("UsagePanel")

        usage_layout = QVBoxLayout(self.usage_widget)
        usage_layout.setContentsMargins(8, 8, 8, 8)
        usage_layout.setSpacing(6)

        title_lbl = QLabel("Daily API Usage Stats", self.usage_widget)
        title_lbl.setObjectName("UsageTitle")
        usage_layout.addWidget(title_lbl)

        # Groq Stats
        self.groq_req_lbl = QLabel("Groq Requests: 0 / 14,400 RPD", self.usage_widget)
        self.groq_req_bar = QProgressBar(self.usage_widget)
        self.groq_req_bar.setRange(0, 14400)
        self.groq_req_bar.setValue(0)

        self.groq_tok_lbl = QLabel("Groq Tokens: 0 / 100K TPD", self.usage_widget)
        self.groq_tok_bar = QProgressBar(self.usage_widget)
        self.groq_tok_bar.setRange(0, 100000)
        self.groq_tok_bar.setValue(0)

        usage_layout.addWidget(self.groq_req_lbl)
        usage_layout.addWidget(self.groq_req_bar)
        usage_layout.addWidget(self.groq_tok_lbl)
        usage_layout.addWidget(self.groq_tok_bar)

        # Gravity Stats
        self.gravity_req_lbl = QLabel("Gravity Requests: 0 / 10,000 RPD", self.usage_widget)
        self.gravity_req_bar = QProgressBar(self.usage_widget)
        self.gravity_req_bar.setRange(0, 10000)
        self.gravity_req_bar.setValue(0)

        self.gravity_tok_lbl = QLabel("Gravity Tokens: 0 / 5,000,000 TPD", self.usage_widget)
        self.gravity_tok_bar = QProgressBar(self.usage_widget)
        self.gravity_tok_bar.setRange(0, 5000000)
        self.gravity_tok_bar.setValue(0)

        usage_layout.addWidget(self.gravity_req_lbl)
        usage_layout.addWidget(self.gravity_req_bar)
        usage_layout.addWidget(self.gravity_tok_lbl)
        usage_layout.addWidget(self.gravity_tok_bar)

        # Gemini Stats
        self.gemini_req_lbl = QLabel("Gemini Requests: 0 / 1,500 RPD", self.usage_widget)
        self.gemini_req_bar = QProgressBar(self.usage_widget)
        self.gemini_req_bar.setRange(0, 1500)
        self.gemini_req_bar.setValue(0)

        self.gemini_tok_lbl = QLabel("Gemini Tokens: 0 / 1M TPM", self.usage_widget)
        self.gemini_tok_bar = QProgressBar(self.usage_widget)
        self.gemini_tok_bar.setRange(0, 1000000)
        self.gemini_tok_bar.setValue(0)

        usage_layout.addWidget(self.gemini_req_lbl)
        usage_layout.addWidget(self.gemini_req_bar)
        usage_layout.addWidget(self.gemini_tok_lbl)
        usage_layout.addWidget(self.gemini_tok_bar)

        self.usage_widget.setVisible(False)
        layout.addWidget(self.usage_widget)

        # 2. Text Browser (Message History)
        self.chat_history = QTextBrowser(self)
        self.chat_history.setObjectName("ChatHistory")
        self.chat_history.setOpenExternalLinks(True)
        self.chat_history.document().setDefaultStyleSheet("""
            body {
                font-family: 'Segoe UI', Arial, sans-serif;
                color: #e2e8f0;
                font-size: 13px;
                line-height: 1.5;
            }
            code {
                background-color: rgba(0, 240, 255, 0.08);
                border: 1px solid rgba(0, 240, 255, 0.2);
                border-radius: 3px;
                padding: 1px 3px;
                font-family: 'Consolas', monospace;
                color: #00f0ff;
            }
            pre {
                background-color: rgba(15, 23, 42, 0.85);
                border: 1px solid rgba(0, 240, 255, 0.25);
                border-radius: 4px;
                padding: 10px;
                font-family: 'Consolas', monospace;
                color: #38bdf8;
            }
            a {
                color: #d946ef;
                text-decoration: none;
                font-weight: bold;
            }
            a:hover {
                text-decoration: underline;
                color: #00f0ff;
            }
        """)
        self.chat_history.setHtml(
            "<div style='color: #00f0ff; font-family: Consolas, monospace; font-size: 11px; padding: 6px 10px; "
            "background-color: rgba(0, 240, 255, 0.03); border: 1px solid rgba(0, 240, 255, 0.15); margin-bottom: 12px;'>"
            "SYSTEM INITIALIZED // CELLYA CLAIRE ONLINE<br/>"
            "&gt; Double-click overlay bubble to show/hide this console.<br/>"
            "&gt; Input commands or ask questions below."
            "</div>"
        )
        layout.addWidget(self.chat_history)

        # Status Label badge
        self.status_badge = QLabel("", self)
        self.status_badge.setObjectName("StatusBadge")
        layout.addWidget(self.status_badge)

        # Thumbnail Preview Frame
        self.preview_frame = QFrame(self)
        self.preview_frame.setObjectName("PreviewFrame")

        preview_layout = QHBoxLayout(self.preview_frame)
        preview_layout.setContentsMargins(4, 4, 4, 4)
        preview_layout.setSpacing(6)

        self.preview_label = QLabel(self.preview_frame)
        self.preview_label.setFixedSize(60, 45)
        self.preview_label.setScaledContents(True)

        self.preview_text = QLabel("Screenshot attached", self.preview_frame)
        self.preview_text.setObjectName("PreviewText")

        self.clear_preview_btn = QPushButton("X", self.preview_frame)
        self.clear_preview_btn.setObjectName("IconButton")
        self.clear_preview_btn.setFixedSize(20, 20)
        self.clear_preview_btn.clicked.connect(self.clear_attached_image)

        preview_layout.addWidget(self.preview_label)
        preview_layout.addWidget(self.preview_text)
        preview_layout.addStretch()
        preview_layout.addWidget(self.clear_preview_btn)

        self.preview_frame.setVisible(False)
        layout.addWidget(self.preview_frame)

        # 3. Message Input Area
        input_layout = QHBoxLayout()

        self.snap_btn = QPushButton("Snap", self)
        self.snap_btn.setObjectName("IconButton")
        self.snap_btn.setFixedSize(40, 50)
        self.snap_btn.clicked.connect(self.capture_screen_requested.emit)

        self.prompt_input = QTextEdit(self)
        self.prompt_input.setObjectName("PromptInput")
        self.prompt_input.setPlaceholderText("Type a message or file command...")
        self.prompt_input.setFixedHeight(50)
        self.prompt_input.installEventFilter(self)  # Intercept enter key presses

        self.send_btn = QPushButton("Send", self)
        self.send_btn.setObjectName("ActionButton")
        self.send_btn.setFixedSize(60, 50)
        self.send_btn.clicked.connect(self.submit_prompt)

        input_layout.addWidget(self.snap_btn)
        input_layout.addWidget(self.prompt_input)
        input_layout.addWidget(self.send_btn)
        layout.addLayout(input_layout)

        # Enable mouse tracking for resize cursor
        self.setMouseTracking(True)
        self.container.setMouseTracking(True)

    # ==========================================
    # Drag & Resize Handlers (Frameless Window)
    # ==========================================

    def _get_resize_edge(self, pos):
        """Deteksi apakah cursor ada di edge untuk resize."""
        rect = self.rect()
        m = self.EDGE_MARGIN

        edges = []
        if pos.x() <= m:
            edges.append("left")
        elif pos.x() >= rect.width() - m:
            edges.append("right")
        if pos.y() <= m:
            edges.append("top")
        elif pos.y() >= rect.height() - m:
            edges.append("bottom")

        if edges:
            return "-".join(edges)
        return None

    def _update_cursor_shape(self, edge):
        """Update cursor shape berdasarkan edge yang di-hover."""
        if edge in ("left", "right"):
            self.setCursor(Qt.CursorShape.SizeHorCursor)
        elif edge in ("top", "bottom"):
            self.setCursor(Qt.CursorShape.SizeVerCursor)
        elif edge in ("top-left", "bottom-right"):
            self.setCursor(Qt.CursorShape.SizeFDiagCursor)
        elif edge in ("top-right", "bottom-left"):
            self.setCursor(Qt.CursorShape.SizeBDiagCursor)
        elif edge in ("left-top", "right-bottom"):
            self.setCursor(Qt.CursorShape.SizeFDiagCursor)
        elif edge in ("left-bottom", "right-top"):
            self.setCursor(Qt.CursorShape.SizeBDiagCursor)
        else:
            self.setCursor(Qt.CursorShape.ArrowCursor)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            edge = self._get_resize_edge(event.pos())
            if edge:
                # Start resize
                self._resizing = True
                self._resize_edge = edge
                self._drag_start_pos = event.globalPosition().toPoint()
                self._drag_start_geom = self.geometry()
            elif event.pos().y() <= 40:
                # Start drag (header area only — top 40px)
                self._dragging = True
                self._drag_start_pos = event.globalPosition().toPoint()
                self._drag_start_geom = self.geometry()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._resizing:
            delta = event.globalPosition().toPoint() - self._drag_start_pos
            geom = QRect(self._drag_start_geom)

            edge = self._resize_edge
            if "right" in edge:
                geom.setRight(geom.right() + delta.x())
            if "left" in edge:
                geom.setLeft(geom.left() + delta.x())
            if "bottom" in edge:
                geom.setBottom(geom.bottom() + delta.y())
            if "top" in edge:
                geom.setTop(geom.top() + delta.y())

            # Enforce min size
            if geom.width() < self.minimumWidth():
                if "left" in edge:
                    geom.setLeft(geom.right() - self.minimumWidth())
                else:
                    geom.setRight(geom.left() + self.minimumWidth())
            if geom.height() < self.minimumHeight():
                if "top" in edge:
                    geom.setTop(geom.bottom() - self.minimumHeight())
                else:
                    geom.setBottom(geom.top() + self.minimumHeight())

            self.setGeometry(geom)
        elif self._dragging:
            delta = event.globalPosition().toPoint() - self._drag_start_pos
            new_pos = self._drag_start_geom.topLeft() + delta
            self.move(new_pos)
        else:
            # Update cursor shape on hover
            edge = self._get_resize_edge(event.pos())
            self._update_cursor_shape(edge)

        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            if self._resizing or self._dragging:
                self._resizing = False
                self._dragging = False
                self._resize_edge = None
                self.save_geometry()
                self.setCursor(Qt.CursorShape.ArrowCursor)
        super().mouseReleaseEvent(event)

    # ==========================================
    # Event Filter & Submission
    # ==========================================

    def eventFilter(self, obj, event):
        # Override Enter key behaviour to submit message
        if obj == self.prompt_input and event.type() == event.Type.KeyPress:
            if event.key() == Qt.Key.Key_Return:
                if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                    # Normal newline
                    return False
                else:
                    self.submit_prompt()
                    return True
        return super().eventFilter(obj, event)

    def submit_prompt(self):
        text = self.prompt_input.toPlainText().strip()
        if not text and not self.pending_image:
            return

        self.prompt_input.clear()
        self.prompt_input.setEnabled(False)
        self.send_btn.setEnabled(False)
        self.snap_btn.setEnabled(False)

        model_data = self.model_combo.currentData()  # returns (model_name, provider)
        model_name, provider = model_data[0], model_data[1]

        image_data = self.pending_image
        self.clear_attached_image()

        self.send_message.emit(text, model_name, provider, image_data)

    def attach_screenshot(self, pixmap, base64_str):
        self.pending_image = base64_str
        self.preview_label.setPixmap(pixmap)
        self.preview_frame.setVisible(True)

    def clear_attached_image(self):
        self.pending_image = None
        self.preview_label.clear()
        self.preview_frame.setVisible(False)

    def append_user_message(self, text, image_base64=None):
        formatted = (
            "<div style='margin-bottom: 12px; margin-top: 4px; padding: 8px; "
            "background-color: rgba(217, 70, 239, 0.04); border-left: 3px solid #d946ef; "
            "border-radius: 0px 4px 4px 0px;'>"
            "<span style='color: #d946ef; font-weight: bold; font-family: Consolas, monospace; font-size: 10px;'>[TRANSMISSION // USER]</span>"
            f"<div style='color: #e2e8f0; font-family: Segoe UI, Arial; font-size: 13px; margin-top: 4px; line-height: 1.5;'>{text}</div>"
        )
        if image_base64:
            formatted += f"<br/><img src='data:image/png;base64,{image_base64}' width='180' style='margin-top: 6px; border: 1px solid rgba(217, 70, 239, 0.3);'/>"
        formatted += "</div>"
        self.chat_history.append(formatted)

    def append_ai_chunk(self, chunk, is_new=False):
        if is_new:
            from config import get_personality_config
            p_config = get_personality_config(self.settings)
            name = p_config.get("name", "Cellya Claire").upper()
            self.chat_history.append(
                f"<div style='margin-bottom: 4px; margin-top: 12px; padding: 4px 8px; "
                f"background-color: rgba(0, 240, 255, 0.04); border-left: 3px solid #00f0ff;'>"
                f"<span style='color: #00f0ff; font-weight: bold; font-family: Consolas, monospace; font-size: 10px;'>[RESPONSE // {name}]</span>"
                f"</div>"
                f"<div style='padding-left: 8px; margin-bottom: 12px; color: #f1f5f9; font-family: Segoe UI, Arial; font-size: 13px; line-height: 1.6;'>"
            )

        cursor = self.chat_history.textCursor()
        cursor.movePosition(cursor.MoveOperation.End)
        self.chat_history.setTextCursor(cursor)
        self.chat_history.insertPlainText(chunk)

        # Scroll to bottom
        sb = self.chat_history.verticalScrollBar()
        sb.setValue(sb.maximum())

    def toggle_usage_panel(self):
        is_visible = self.usage_widget.isVisible()
        self.usage_widget.setVisible(not is_visible)
        if not is_visible:
            self.update_usage_display()

    def update_usage_display(self):
        stats = UsageTracker.load_stats()

        # Groq
        g_reqs = stats["groq"]["requests"]
        g_tokens = stats["groq"]["tokens"]
        self.groq_req_lbl.setText(f"Groq Requests: {g_reqs:,} / 14,400 RPD")
        self.groq_req_bar.setValue(g_reqs)
        self.groq_tok_lbl.setText(f"Groq Tokens: {g_tokens:,} / 100,000 TPD")
        self.groq_tok_bar.setValue(g_tokens)

        # Gravity
        grav_reqs = stats.get("gravity", {}).get("requests", 0)
        grav_tokens = stats.get("gravity", {}).get("tokens", 0)
        self.gravity_req_lbl.setText(f"Gravity Requests: {grav_reqs:,} / 10,000 RPD")
        self.gravity_req_bar.setValue(grav_reqs)
        self.gravity_tok_lbl.setText(f"Gravity Tokens: {grav_tokens:,} / 5,000,000 TPD")
        self.gravity_tok_bar.setValue(grav_tokens)

        # Gemini
        gem_reqs = stats["gemini"]["requests"]
        gem_tokens = stats["gemini"]["tokens"]
        self.gemini_req_lbl.setText(f"Gemini Requests: {gem_reqs:,} / 1,500 RPD")
        self.gemini_req_bar.setValue(gem_reqs)
        self.gemini_tok_lbl.setText(f"Gemini Tokens: {gem_tokens:,} / 1,000,000 TPM")
        self.gemini_tok_bar.setValue(gem_tokens)

    def update_status(self, message):
        self.status_badge.setText(message)

    def finish_stream(self):
        self.status_badge.setText("")
        self.prompt_input.setEnabled(True)
        self.send_btn.setEnabled(True)
        self.snap_btn.setEnabled(True)
        self.prompt_input.setFocus()
        self.chat_history.append("</div><hr style='border: none; border-top: 1px solid rgba(0, 240, 255, 0.1); margin: 8px 0;'/>")
        if self.usage_widget.isVisible():
            self.update_usage_display()

    def show_animated(self, parent_pos):
        # Anchor adjacent to overlay bubble
        x_target = parent_pos.x() - self.width() - 10
        y_target = parent_pos.y()

        # Monitor edge protection
        screen = QApplication.primaryScreen()
        if screen:
            screen_geom = screen.availableGeometry()
            if x_target < screen_geom.x():
                x_target = parent_pos.x() + 70  # Show on the right side instead
            # Clamp vertically
            if y_target + self.height() > screen_geom.bottom():
                y_target = screen_geom.bottom() - self.height()
            if y_target < screen_geom.y():
                y_target = screen_geom.y()
        elif x_target < 0:
            x_target = parent_pos.x() + 70

        self.move(x_target, y_target)
        self.show()
        self.raise_()
        self.prompt_input.setFocus()
        self.save_geometry()

    def hide_animated(self):
        self.save_geometry()
        self.hide()

    def save_geometry(self):
        # We save the baseline width (excluding the sidebar)
        is_visible = hasattr(self, "sidebar_panel") and self.sidebar_panel.isVisible()
        base_width = self.width() - (250 if is_visible else 0)
        base_x = self.x() + (250 if is_visible else 0)

        self.settings["chat_geometry"] = {
            "x": base_x,
            "y": self.y(),
            "width": max(350, base_width),
            "height": max(400, self.height())
        }

    def toggle_voice_mode(self):
        current_state = self.settings.get("voice_mode", False)
        new_state = not current_state
        self.settings["voice_mode"] = new_state
        self.update_voice_button_ui()

    def update_voice_button_ui(self):
        is_active = self.settings.get("voice_mode", False)
        if is_active:
            self.voice_btn.setObjectName("IconButtonActive")
            self.voice_btn.setText("ON")
        else:
            self.voice_btn.setObjectName("IconButton")
            self.voice_btn.setText("OFF")
        # Force stylesheet update
        self.voice_btn.style().unpolish(self.voice_btn)
        self.voice_btn.style().polish(self.voice_btn)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.container.setGeometry(0, 0, self.width(), self.height())

    def update_personality_title(self, p_name):
        """
        Updates the title text of the chat window based on the active personality.
        """
        self.title_label.setText(p_name)

    # ==========================================
    # Sidebar Operations & Callbacks
    # ==========================================

    def toggle_sidebar(self):
        is_visible = self.sidebar_panel.isVisible()
        self.sidebar_panel.setVisible(not is_visible)

        geom = self.geometry()
        if not is_visible:
            # Expanding: Shift X left by 250, increase width by 250
            new_width = geom.width() + 250
            new_x = geom.x() - 250
            self.refresh_files_list()
        else:
            # Collapsing: Shift X right by 250, decrease width by 250
            new_width = geom.width() - 250
            new_x = geom.x() + 250

        if new_x < 0:
            new_x = 0

        # Clamp width to screen
        screen = QApplication.primaryScreen()
        if screen:
            max_w = screen.availableGeometry().width()
            new_width = min(new_width, max_w - new_x)

        self.setGeometry(new_x, geom.y(), new_width, geom.height())
        self.save_geometry()

    def update_session_list(self, sessions, active_session_id=None):
        self.sessions_list.clear()
        for s in sessions:
            title = s.get("title", "Untitled Chat")
            session_id = s.get("session_id")
            item = QListWidgetItem(title)
            item.setData(Qt.ItemDataRole.UserRole, session_id)
            self.sessions_list.addItem(item)
            if active_session_id and session_id == active_session_id:
                self.sessions_list.setCurrentItem(item)

    def handle_session_clicked(self, item):
        session_id = item.data(Qt.ItemDataRole.UserRole)
        self.load_session_requested.emit(session_id)

    def handle_delete_session_clicked(self):
        item = self.sessions_list.currentItem()
        if not item:
            QMessageBox.warning(self, "No Selection", "Please select a chat session to delete.")
            return
        session_id = item.data(Qt.ItemDataRole.UserRole)
        title = item.text()
        ret = QMessageBox.question(
            self, "Confirm Delete",
            f"Are you sure you want to delete the chat session: '{title}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if ret == QMessageBox.StandardButton.Yes:
            self.delete_session_requested.emit(session_id)

    def refresh_files_list(self):
        self.files_list.clear()
        from core import file_manager
        safe_roots = file_manager.get_safe_roots(self.settings)
        if not safe_roots:
            return
        primary_root = safe_roots[0]

        # Traverse folder for generated documents & source files
        ignore_dirs = {'.git', 'venv', '__pycache__', 'node_modules', '.claude', 'history', 'assets', 'config', 'ui', 'core', 'personalities', 'learnings'}
        allowed_extensions = ('.docx', '.pdf', '.csv', '.txt', '.html', '.py', '.json', '.pptx')

        files_found = []
        for dirpath, dirnames, filenames in os.walk(primary_root):
            # Prune ignored directories in place
            dirnames[:] = [d for d in dirnames if d not in ignore_dirs]

            for name in filenames:
                if name.endswith(allowed_extensions) and name not in ('settings.json', 'usage_stats.json', '.env'):
                    full_path = os.path.join(dirpath, name)
                    rel_path = os.path.relpath(full_path, primary_root)
                    files_found.append((rel_path, full_path))

        # Sort alphabetically
        files_found.sort(key=lambda x: x[0].lower())

        for rel_path, full_path in files_found:
            item = QListWidgetItem(rel_path)
            item.setData(Qt.ItemDataRole.UserRole, full_path)
            self.files_list.addItem(item)

    def open_file_clicked(self):
        item = self.files_list.currentItem()
        if not item:
            QMessageBox.warning(self, "No Selection", "Please select a file to open.")
            return
        full_path = item.data(Qt.ItemDataRole.UserRole)
        if os.path.exists(full_path):
            try:
                os.startfile(full_path)
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Could not open file: {e}")
        else:
            QMessageBox.warning(self, "Not Found", f"File does not exist: {full_path}")
            self.refresh_files_list()

    def file_item_double_clicked(self, item):
        self.open_file_clicked()

    def delete_file_clicked(self):
        item = self.files_list.currentItem()
        if not item:
            QMessageBox.warning(self, "No Selection", "Please select a file to delete.")
            return
        full_path = item.data(Qt.ItemDataRole.UserRole)
        ret = QMessageBox.question(
            self, "Confirm Delete",
            f"Are you sure you want to delete '{os.path.basename(full_path)}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if ret == QMessageBox.StandardButton.Yes:
            try:
                os.remove(full_path)
                self.refresh_files_list()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to delete file: {e}")

    def edit_file_clicked(self):
        item = self.files_list.currentItem()
        if not item:
            QMessageBox.warning(self, "No Selection", "Please select a file to edit.")
            return
        full_path = item.data(Qt.ItemDataRole.UserRole)

        # Check if text-based
        text_extensions = ('.txt', '.html', '.py', '.json', '.csv', '.md', '.ini', '.yaml', '.yml', '.env')
        if not full_path.lower().endswith(text_extensions):
            QMessageBox.information(
                self, "Binary File",
                "This file is a binary format (.docx, .pdf, etc.).\n"
                "Please click 'Open' to view/edit it in Microsoft Word, Acrobat, or another external application."
            )
            return

        dialog = TextEditorDialog(full_path, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.refresh_files_list()

    def create_file_clicked(self):
        text, ok = QInputDialog.getText(
            self, 'Create New File',
            'Enter relative file path/name (e.g. note.txt or Cellya_Outputs/file.py):',
            QLineEdit.EchoMode.Normal, ""
        )
        if ok and text.strip():
            filename = text.strip()
            from core import file_manager
            safe_roots = file_manager.get_safe_roots(self.settings)
            primary_root = safe_roots[0] if safe_roots else os.getcwd()
            full_path = os.path.abspath(os.path.join(primary_root, filename))

            if not file_manager.is_path_safe(full_path, safe_roots):
                QMessageBox.warning(self, "Access Denied", "Path traversal detected. File cannot be created outside workspace.")
                return

            if os.path.exists(full_path):
                QMessageBox.warning(self, "Exists", "File already exists.")
                return

            try:
                os.makedirs(os.path.dirname(full_path), exist_ok=True)
                with open(full_path, 'w', encoding='utf-8') as f:
                    f.write("")
                self.refresh_files_list()

                # Open edit dialog immediately on the created file
                dialog = TextEditorDialog(full_path, self)
                if dialog.exec() == QDialog.DialogCode.Accepted:
                    self.refresh_files_list()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to create file: {e}")

    # ==========================================
    # Music Player Operations
    # ==========================================
    def search_music(self):
        query = self.music_search_input.text().strip()
        if not query:
            return

        self.music_search_btn.setEnabled(False)
        self.music_search_btn.setText("Wait...")
        self.music_results_list.clear()

        # Run search in background to avoid freezing UI
        import threading
        def _do_search():
            results = self.audio_engine.search_and_extract(query)
            # Update UI in main thread
            from PyQt6.QtCore import QMetaObject, Q_ARG
            QMetaObject.invokeMethod(self, "_update_music_results",
                                     Qt.ConnectionType.QueuedConnection,
                                     Q_ARG(list, results))

        threading.Thread(target=_do_search, daemon=True).start()

    @pyqtSlot(list)
    def _update_music_results(self, results):
        self.music_search_btn.setEnabled(True)
        self.music_search_btn.setText("Search")

        for res in results:
            title = res.get('title', 'Unknown')
            channel = res.get('channel', 'Unknown')
            duration = res.get('duration', 0)

            # Format duration
            mins, secs = divmod(int(duration) if duration else 0, 60)
            dur_str = f"{mins}:{secs:02d}"

            display_text = f"{title}\n{channel} - {dur_str}"
            item = QListWidgetItem(display_text)
            item.setData(Qt.ItemDataRole.UserRole, res)
            self.music_results_list.addItem(item)

    def play_selected_music(self, item):
        track_info = item.data(Qt.ItemDataRole.UserRole)
        if not track_info:
            return

        title = track_info.get('title')
        self.now_playing_lbl.setText(f"Loading: {title}...")

        # Add to queue and play
        self.audio_engine.add_to_queue(track_info)
        self._update_queue_info()

    def toggle_play_music(self):
        if self.audio_engine.is_playing:
            self.audio_engine.pause()
            self.music_play_btn.setText("Play")
        else:
            self.audio_engine.resume()
            self.music_play_btn.setText("Pause")

    def stop_music(self):
        self.audio_engine.stop()
        self.now_playing_lbl.setText("Not Playing")
        self.music_play_btn.setText("Play")
        self.music_progress.setValue(0)

    def play_next_music(self):
        track = self.audio_engine.play_next()
        if track:
            self.now_playing_lbl.setText(f"Loading: {track.get('title')}...")

    def play_prev_music(self):
        track = self.audio_engine.play_prev()
        if track:
            self.now_playing_lbl.setText(f"Loading: {track.get('title')}...")

    def update_audio_progress(self):
        if self.audio_engine.is_playing:
            pos = self.audio_engine.get_position()
            if pos >= 0:
                self.music_progress.setValue(int(pos * 1000))

    def seek_music(self):
        val = self.music_progress.value()
        pos = val / 1000.0
        self.audio_engine.set_position(pos)

    @pyqtSlot()
    def on_track_ended(self):
        # Auto play next track based on repeat/shuffle mode
        track = self.audio_engine.auto_next()
        if track:
            self.now_playing_lbl.setText(f"Loading: {track.get('title')}...")
            self._update_queue_info()
        else:
            self.stop_music()

    @pyqtSlot(dict)
    def on_track_loaded(self, track_info):
        title = track_info.get('title', 'Unknown')
        self.now_playing_lbl.setText(f"Playing: {title}")
        self.music_play_btn.setText("Pause")
        self._update_queue_info()

    @pyqtSlot(str)
    def on_audio_error(self, error_msg):
        self.now_playing_lbl.setText(f"Error: {error_msg[:50]}...")
        self.music_play_btn.setText("Play")

    def toggle_repeat(self):
        mode = self.audio_engine.toggle_repeat()
        labels = {"off": "Repeat: OFF", "one": "Repeat: ONE", "all": "Repeat: ALL"}
        self.music_repeat_btn.setText(labels.get(mode, "Repeat: OFF"))
        # Highlight when active
        if mode == "off":
            self.music_repeat_btn.setObjectName("IconButton")
        else:
            self.music_repeat_btn.setObjectName("IconButtonActive")
        self.music_repeat_btn.style().unpolish(self.music_repeat_btn)
        self.music_repeat_btn.style().polish(self.music_repeat_btn)

    def toggle_shuffle(self):
        is_on = self.audio_engine.toggle_shuffle()
        self.music_shuffle_btn.setText(f"Shuffle: {'ON' if is_on else 'OFF'}")
        if is_on:
            self.music_shuffle_btn.setObjectName("IconButtonActive")
        else:
            self.music_shuffle_btn.setObjectName("IconButton")
        self.music_shuffle_btn.style().unpolish(self.music_shuffle_btn)
        self.music_shuffle_btn.style().polish(self.music_shuffle_btn)

    def clear_music_queue(self):
        self.audio_engine.clear_queue()
        self.stop_music()
        self.now_playing_lbl.setText("Not Playing")
        self._update_queue_info()

    def _update_queue_info(self):
        total = len(self.audio_engine.queue)
        current = self.audio_engine.current_index + 1
        if total > 0 and self.audio_engine.current_track_info:
            self.queue_info_lbl.setText(f"Queue: {current}/{total} tracks")
        else:
            self.queue_info_lbl.setText(f"Queue: {total} tracks")
