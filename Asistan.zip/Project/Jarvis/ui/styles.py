DARK_GLASS_STYLE = """
/* Main Overlay Widget Bubble */
#OverlayBubble {
    background-color: rgba(10, 11, 20, 0.82);
    border: 2px solid qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1,
        stop:0 rgba(0, 240, 255, 0.8),
        stop:0.5 rgba(217, 70, 239, 0.3),
        stop:1 rgba(0, 240, 255, 0.8));
    border-radius: 30px;
}

/* Base Window styles */
QFrame#MainChatWindow {
    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1,
        stop:0 rgba(16, 20, 35, 0.94),
        stop:1 rgba(10, 11, 20, 0.98));
    border: 1px solid rgba(0, 240, 255, 0.25);
    border-top: 2px solid rgba(0, 240, 255, 0.7);
    border-radius: 6px;
}

/* Header bar components */
QLabel#ChatTitle {
    color: #00f0ff;
    font-weight: bold;
    font-size: 13px;
    font-family: 'Segoe UI Semibold', 'Arial', sans-serif;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}

/* Text Areas and Input Fields */
QTextBrowser#ChatHistory {
    background-color: transparent;
    border: none;
    color: #e2e8f0;
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 13px;
    line-height: 1.6;
}

QTextEdit#PromptInput {
    background-color: rgba(15, 23, 42, 0.6);
    border: 1px solid rgba(0, 240, 255, 0.2);
    border-radius: 4px;
    color: #f8fafc;
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 13px;
    padding: 6px;
}
QTextEdit#PromptInput:focus {
    border: 1px solid rgba(0, 240, 255, 0.85);
    background-color: rgba(15, 23, 42, 0.8);
}

/* Control Buttons & Dropdowns */
QComboBox#ModelSelector {
    background-color: rgba(15, 23, 42, 0.8);
    border: 1px solid rgba(0, 240, 255, 0.25);
    border-radius: 4px;
    color: #00f0ff;
    padding: 4px 8px;
    font-size: 11px;
    font-family: 'Segoe UI Semibold', sans-serif;
}
QComboBox#ModelSelector::drop-down {
    border: none;
    subcontrol-origin: padding;
    subcontrol-position: top right;
    width: 15px;
}
QComboBox#ModelSelector QAbstractItemView {
    background-color: rgba(10, 11, 20, 0.96);
    border: 1px solid rgba(0, 240, 255, 0.3);
    selection-background-color: rgba(0, 240, 255, 0.2);
    selection-color: #00f0ff;
    color: #e2e8f0;
}

QPushButton#ActionButton {
    background-color: rgba(0, 240, 255, 0.12);
    border: 1px solid rgba(0, 240, 255, 0.5);
    border-radius: 4px;
    color: #00f0ff;
    font-weight: bold;
    font-size: 11px;
    padding: 5px 12px;
    text-transform: uppercase;
    letter-spacing: 1px;
}
QPushButton#ActionButton:hover {
    background-color: rgba(0, 240, 255, 0.25);
    border: 1px solid #00f0ff;
    color: #ffffff;
}
QPushButton#ActionButton:pressed {
    background-color: rgba(0, 240, 255, 0.45);
    border: 1px solid #00f0ff;
}

QPushButton#IconButton {
    background-color: rgba(15, 23, 42, 0.4);
    border: 1px solid rgba(255, 255, 255, 0.05);
    border-radius: 4px;
    color: #8892b0;
}
QPushButton#IconButton:hover {
    background-color: rgba(0, 240, 255, 0.1);
    border: 1px solid rgba(0, 240, 255, 0.35);
    color: #00f0ff;
}

QPushButton#IconButtonClose {
    background-color: rgba(15, 23, 42, 0.4);
    border: 1px solid rgba(255, 255, 255, 0.05);
    border-radius: 4px;
    color: #8892b0;
}
QPushButton#IconButtonClose:hover {
    background-color: rgba(239, 68, 68, 0.15);
    border: 1px solid rgba(239, 68, 68, 0.6);
    color: #ef4444;
}

QPushButton#IconButtonActive {
    background-color: rgba(16, 185, 129, 0.15);
    border: 1px solid rgba(16, 185, 129, 0.6);
    border-radius: 4px;
    color: #10b981;
}
QPushButton#IconButtonActive:hover {
    background-color: rgba(16, 185, 129, 0.25);
    border: 1px solid #10b981;
    color: #34d399;
}

/* Panels */
QFrame#UsagePanel {
    background-color: rgba(10, 11, 20, 0.95);
    border: 1px solid rgba(0, 240, 255, 0.25);
    border-radius: 4px;
    padding: 10px;
}
#UsagePanel QLabel {
    color: #8892b0;
    font-size: 11px;
}
#UsagePanel QLabel#UsageTitle {
    color: #00f0ff;
    font-weight: bold;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 1px;
}
QProgressBar {
    background-color: rgba(255, 255, 255, 0.03);
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 2px;
    text-align: center;
    color: #f8fafc;
    font-weight: bold;
    font-size: 9px;
    height: 12px;
}
QProgressBar::chunk {
    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(0, 240, 255, 0.4),
        stop:1 rgba(0, 240, 255, 0.8));
    border-radius: 1px;
}

QFrame#PreviewFrame {
    background-color: rgba(15, 23, 42, 0.6);
    border: 1px solid rgba(0, 240, 255, 0.2);
    border-radius: 4px;
    padding: 4px;
}
QLabel#PreviewText {
    color: #8892b0;
    font-size: 11px;
}
QLabel#StatusBadge {
    color: #d946ef;
    font-size: 11px;
    font-family: 'Consolas', monospace;
}

/* Scrollbars */
QScrollBar:vertical {
    border: none;
    background: rgba(10, 11, 20, 0.3);
    width: 6px;
    margin: 0px;
}
QScrollBar::handle:vertical {
    background: rgba(0, 240, 255, 0.25);
    min-height: 20px;
    border-radius: 3px;
}
QScrollBar::handle:vertical:hover {
    background: rgba(0, 240, 255, 0.6);
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

/* Sidebar Panel */
QFrame#SidebarPanel {
    background-color: rgba(10, 11, 20, 0.96);
    border-right: 1px solid rgba(0, 240, 255, 0.25);
    border-top-left-radius: 6px;
    border-bottom-left-radius: 6px;
}

/* Sidebar ListWidgets */
QListWidget {
    background-color: transparent;
    border: none;
    outline: none;
    color: #e2e8f0;
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 12px;
}
QListWidget::item {
    background-color: rgba(255, 255, 255, 0.02);
    border: 1px solid rgba(255, 255, 255, 0.05);
    border-radius: 4px;
    padding: 6px 8px;
    margin-bottom: 4px;
}
QListWidget::item:hover {
    background-color: rgba(0, 240, 255, 0.08);
    border: 1px solid rgba(0, 240, 255, 0.25);
    color: #ffffff;
}
QListWidget::item:selected {
    background-color: rgba(0, 240, 255, 0.15);
    border: 1px solid rgba(0, 240, 255, 0.6);
    color: #00f0ff;
    font-weight: bold;
}

/* Tab Widget and TabBar */
QTabWidget::pane {
    border: none;
    background: transparent;
}
QTabBar::tab {
    background: rgba(15, 23, 42, 0.6);
    border: 1px solid rgba(0, 240, 255, 0.2);
    border-bottom: none;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    color: #8892b0;
    padding: 6px 12px;
    font-family: 'Segoe UI Semibold', sans-serif;
    font-size: 11px;
}
QTabBar::tab:selected {
    background: rgba(0, 240, 255, 0.12);
    border: 1px solid rgba(0, 240, 255, 0.5);
    border-bottom: none;
    color: #00f0ff;
    font-weight: bold;
}
QTabBar::tab:hover {
    color: #ffffff;
    background: rgba(0, 240, 255, 0.05);
}
"""
