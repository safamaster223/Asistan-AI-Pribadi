from PyQt6.QtCore import Qt, QPoint, pyqtSignal, QUrl
from PyQt6.QtWidgets import QWidget, QMenu
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWebEngineCore import QWebEnginePage, QWebEngineSettings
from ui.styles import DARK_GLASS_STYLE
import os
import json

class WebConsolePage(QWebEnginePage):
    """
    Subclasses QWebEnginePage to pipe console messages from the
    JavaScript environment directly to Python's standard output.
    """
    def javaScriptConsoleMessage(self, level, message, lineNumber, sourceID):
        try:
            level_str = level.name.replace("MessageLevel", "").upper()
        except AttributeError:
            level_str = str(level)
        print(f"[JS {level_str}] Line {lineNumber}: {message} (Source: {sourceID})")

class OverlayWidget(QWidget):
    double_clicked = pyqtSignal()
    settings_requested = pyqtSignal()
    clear_chat_requested = pyqtSignal()
    exit_requested = pyqtSignal()
    personality_changed = pyqtSignal(str)

    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.drag_position = QPoint()
        self.is_dragging = False

        # State options: 'idle', 'thinking', 'working', 'error'
        self.state = 'idle'

        self.init_ui()

    def init_ui(self):
        # Frameless window, stays on top, tool window (hidden from alt+tab)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setFixedSize(60, 60)
        self.setObjectName("OverlayBubble")
        self.setStyleSheet(DARK_GLASS_STYLE)

        # Restore overlay location settings
        geom = self.settings.get("overlay_geometry", {"x": 100, "y": 100})
        self.move(geom["x"], geom["y"])

        # Create transparent WebEngine View for Lottie animation
        self.browser = QWebEngineView(self)
        self.browser.setGeometry(0, 0, 60, 60)
        self.browser.setStyleSheet("background: transparent;")
        self.browser.settings().setAttribute(
            QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls, True
        )

        # Set custom page to redirect JavaScript console output to python
        self.page = WebConsolePage(self.browser)
        self.browser.setPage(self.page)
        self.browser.page().setBackgroundColor(Qt.GlobalColor.transparent)

        # Pass through mouse events to parent OverlayWidget
        self.browser.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.browser.setContextMenuPolicy(Qt.ContextMenuPolicy.NoContextMenu)

        # Load local HTML player
        import os
        assets_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "assets"))
        html_path = os.path.join(assets_dir, "player.html")
        self.browser.setUrl(QUrl.fromLocalFile(html_path))
        self.browser.show()

        # Once page loads, trigger Lottie loading
        self.browser.loadFinished.connect(self.on_player_loaded)

    def on_player_loaded(self, ok):
        if ok:
            self.update_avatar()

    def update_avatar(self):
        from config import get_personality_config
        p_config = get_personality_config(self.settings)
        file_name = p_config.get("avatar_file", "serious.json")

        # Call JS function loadLottieFile to fetch the file asynchronously in JS
        try:
            js_code = f"loadLottieFile('{file_name}');"
            self.browser.page().runJavaScript(js_code)
        except Exception as e:
            print(f"Error loading Lottie animation '{file_name}': {e}")

    def set_state(self, state):
        if state in ['idle', 'thinking', 'working', 'error']:
            self.state = state

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.is_dragging = True
            self.drag_position = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.MouseButton.LeftButton and self.is_dragging:
            self.move(event.globalPosition().toPoint() - self.drag_position)
            event.accept()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.is_dragging = False
            self.settings["overlay_geometry"] = {
                "x": self.x(),
                "y": self.y(),
                "width": self.width(),
                "height": self.height()
            }
            event.accept()

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.double_clicked.emit()
            event.accept()

    def contextMenuEvent(self, event):
        from config import load_personalities, save_settings
        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background-color: rgba(10, 11, 20, 0.96);
                color: #e2e8f0;
                border: 1px solid rgba(0, 240, 255, 0.3);
                font-family: 'Segoe UI', sans-serif;
                font-size: 11px;
            }
            QMenu::item {
                padding: 6px 20px;
                background-color: transparent;
            }
            QMenu::item:selected {
                background-color: rgba(0, 240, 255, 0.15);
                color: #00f0ff;
            }
            QMenu::separator {
                height: 1px;
                background-color: rgba(0, 240, 255, 0.15);
                margin: 4px 0px;
            }
            QMenu::indicator {
                width: 13px;
                height: 13px;
            }
        """)

        mode_menu = menu.addMenu("Change Personality")
        personalities = load_personalities()
        active_id = self.settings.get("active_personality", "serious")

        action_map = {}
        for p_id, p_info in personalities.items():
            name = p_info.get("name", p_id)
            action = mode_menu.addAction(name)
            action.setCheckable(True)
            action.setChecked(p_id == active_id)
            action_map[action] = p_id

        menu.addSeparator()
        clear_action = menu.addAction("Clear Conversation")
        settings_action = menu.addAction("Settings")
        menu.addSeparator()
        exit_action = menu.addAction("Exit Cellya Claire")

        action = menu.exec(event.globalPos())

        if action in action_map:
            new_p_id = action_map[action]
            self.settings["active_personality"] = new_p_id

            # Synchronize avatar_mode config with the selected avatar_file
            p_info = personalities[new_p_id]
            avatar_mode = "serious"
            if p_info.get("avatar_file") == "fun.json" or "fun" in new_p_id.lower():
                avatar_mode = "fun"
            self.settings["avatar_mode"] = avatar_mode

            save_settings(self.settings)
            self.update_avatar()
            self.personality_changed.emit(new_p_id)
        elif action == clear_action:
            self.clear_chat_requested.emit()
        elif action == settings_action:
            self.settings_requested.emit()
        elif action == exit_action:
            self.exit_requested.emit()
