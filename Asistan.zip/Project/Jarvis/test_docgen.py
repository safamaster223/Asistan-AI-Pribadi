import os
import sys
import json
from core.automator.docgen import DocumentGenerator

def main():
    print("Testing document_generate wrapper and layout engine...")
    generator = DocumentGenerator()

    # 1. Create a detailed document template payload (Academic format)
    test_data = {
        "title": "Analisis Pengaruh Deforestasi Terhadap Pemanasan Global",
        "subtitle": "Sebuah Kajian Literatur dan Metodologi Penelitian Iklim",
        "sections": {
            "Abstrak": (
                "Deforestasi merupakan salah satu kontributor utama perubahan iklim global melalui pelepasan karbon "
                "ke atmosfer dan penurunan kapasitas bumi untuk menyerap gas rumah kaca. Jurnal ini mengkaji hubungan "
                "kausal antara hilangnya tutupan hutan tropis dengan peningkatan suhu global permukaan. Melalui metode "
                "analisis data sekunder dan pemodelan sirkulasi umum (GCM), studi ini merangkum dampak ekologis jangka panjang "
                "serta merekomendasikan kebijakan konservasi berbasis ekonomi sirkular."
            ),
            "I. Pendahuluan": (
                "Hutan memiliki peran penting sebagai paru-paru dunia dan penyerap karbon alami (carbon sink). Namun, aktivitas "
                "industrialisasi dan perluasan lahan pertanian secara masif telah memicu eksploitasi hutan global pada tingkat yang "
                "belum pernah terjadi sebelumnya. Sejak era pra-industri, suhu rata-rata permukaan bumi telah meningkat sekitar "
                "1.1°C, di mana 15-20% dari total emisi gas rumah kaca bersumber dari degradasi kawasan hutan tropis.\n\n"
                "Rumusan masalah dalam kajian ini berpusat pada seberapa signifikan kontribusi laju deforestasi tahunan terhadap "
                "anomali suhu lokal dan global. Dengan memahami korelasi ini, pemangku kebijakan diharapkan dapat merumuskan "
                "langkah mitigasi yang lebih taktis untuk mempertahankan target Perjanjian Paris di bawah ambang batas kenaikan 1.5°C."
            ),
            "II. Metodologi Penelitian": (
                "Studi ini menggunakan pendekatan campuran kuantitatif-kualitatif melalui tinjauan literatur sistematis dan analisis "
                "meta-data satelit MODIS. Parameter yang diukur meliputi laju perubahan tutupan pohon (tree cover loss) dan fluktuasi "
                "albedo permukaan. Data yang terkumpul diolah menggunakan statistik regresi linier berganda untuk memodelkan hubungan "
                "antar variabel bebas berupa luas deforestasi dan variabel terikat berupa temperatur udara lokal."
            ),
            "Data Statistik Deforestasi (Tabel Pengamatan)": {
                "type": "table",
                "headers": ["Tahun", "Luas Deforestasi (Hektar)", "Emisi CO2 (Mega Ton)", "Kenaikan Suhu Lokal (°C)"],
                "rows": [
                    ["2021", "120.000", "45.2", "0.08"],
                    ["2022", "145.000", "52.8", "0.11"],
                    ["2023", "180.000", "64.1", "0.15"],
                    ["2024", "210.000", "78.4", "0.19"]
                ]
            },
            "III. Tinjauan Pustaka & Daftar Referensi": (
                "1. Aldrian, E., & Karmini, M. (2020). Analisis Variabilitas Iklim Nusantara. Jakarta: BMKG Press.\n"
                "2. IPCC. (2023). Climate Change 2023: Synthesis Report. Contribution of Working Groups I, II and III to the Sixth Assessment Report. Geneva: IPCC.\n"
                "3. Margono, B. A., et al. (2022). Primary forest loss in Indonesia over 2010–2022. Nature Climate Change, 12(4), 345-351."
            )
        }
    }

    # Generate PDF
    pdf_path = os.path.abspath("test_output_academic.pdf")
    res_pdf = generator.write("pdf", pdf_path, test_data)
    print(res_pdf)

    # Generate DOCX
    docx_path = os.path.abspath("test_output_academic.docx")
    res_docx = generator.write("docx", docx_path, test_data)
    print(res_docx)

    # 1.1 Create a detailed document template payload with list-based sections (guaranteed order)
    test_data_list = {
        "title": "Analisis Pengaruh Deforestasi Terhadap Pemanasan Global (List Format)",
        "subtitle": "Sebuah Kajian Literatur dan Metodologi Penelitian Iklim",
        "sections": [
            {
                "heading": "Abstrak",
                "content": "Deforestasi merupakan salah satu kontributor utama perubahan iklim global melalui pelepasan karbon..."
            },
            {
                "heading": "I. Pendahuluan",
                "content": "Hutan memiliki peran penting sebagai paru-paru dunia..."
            },
            {
                "heading": "II. Metodologi Penelitian",
                "content": "Studi ini menggunakan pendekatan campuran kuantitatif-kualitatif..."
            },
            {
                "heading": "Data Statistik Deforestasi (Tabel Pengamatan)",
                "content": {
                    "type": "table",
                    "headers": ["Tahun", "Luas Deforestasi (Hektar)", "Emisi CO2 (Mega Ton)", "Kenaikan Suhu Lokal (°C)"],
                    "rows": [
                        ["2021", "120.000", "45.2", "0.08"],
                        ["2022", "145.000", "52.8", "0.11"],
                        ["2023", "180.000", "64.1", "0.15"],
                        ["2024", "210.000", "78.4", "0.19"]
                    ]
                }
            },
            {
                "heading": "III. Tinjauan Pustaka & Daftar Referensi",
                "content": "1. Aldrian, E., & Karmini, M. (2020)..."
            }
        ]
    }

    # Generate PDF (List Format)
    pdf_path_list = os.path.abspath("test_output_list.pdf")
    res_pdf_list = generator.write("pdf", pdf_path_list, test_data_list)
    print(res_pdf_list)

    # Generate DOCX (List Format)
    docx_path_list = os.path.abspath("test_output_list.docx")
    res_docx_list = generator.write("docx", docx_path_list, test_data_list)
    print(res_docx_list)

    # 2. Test Slide Deck (.pptx & .html presentation)
    test_slide_data = {
        "title": "Kecerdasan Buatan & Masa Depan Pekerjaan",
        "subtitle": "Bagaimana Generative AI Mengubah Lanskap Industri dan Pendidikan",
        "html_presentation": True,
        "slides": [
            {
                "title": "Perkembangan Generative AI",
                "content": [
                    "Transformasi Digital: AI mempercepat efisiensi operasional hingga 40%.",
                    "Otomatisasi Tugas: 60-70% pekerjaan rutin saat ini dapat diautomasi oleh model bahasa besar.",
                    "Sinergi Manusia & AI: Kolaborasi meningkatkan kreativitas dan kecepatan inovasi produk."
                ]
            },
            {
                "title": "Pilar Utama Implementasi",
                "content": [
                    {"title": "Infrastruktur Cloud", "desc": "Penyediaan komputasi GPU berkinerja tinggi untuk model pelatihan skala besar."},
                    {"title": "Keamanan Data", "desc": "Kepatuhan privasi data sensitif perusahaan menggunakan hosting model lokal terenkripsi."},
                    {"title": "Pelatihan SDM", "desc": "Kurikulum upskilling karyawan untuk menguasai teknik Prompt Engineering profesional."}
                ]
            },
            {
                "title": "Tantangan dan Mitigasi Dampak",
                "content": [
                    "Kehilangan Pekerjaan: Risiko displacement untuk entri data dan administrasi kantor.",
                    "Bias Algoritma: Perlunya regulasi audit etika model secara periodik sebelum peluncuran.",
                    "Kualitas Output: Mitigasi halusinasi model dengan sistem RAG (Retrieval-Augmented Generation) terverifikasi."
                ]
            }
        ]
    }

    pptx_path = os.path.abspath("test_presentation.pptx")
    res_pptx = generator.write("pptx", pptx_path, test_slide_data)
    print(res_pptx)

    print("Testing complete. Check the generated files in Jarvis/ directory.")

if __name__ == "__main__":
    # Add root folder to python path so core modules can be resolved
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    main()
