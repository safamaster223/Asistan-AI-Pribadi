@echo off
REM Windows Startup Automation for Jarvis Assistant
cd /d "%~dp0"
echo Starting Jarvis Floating Desktop Assistant...
call venv\Scripts\activate.bat
start pythonw main.py
exit

