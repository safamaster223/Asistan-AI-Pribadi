@echo off
setlocal enabledelayedexpansion

echo ===================================================
echo Jarvis Chrome Remote Debugging Launcher
echo ===================================================
echo.
echo This script will close all running Chrome windows and
echo relaunch Chrome with remote debugging enabled on port 9222.
echo This allows Jarvis to connect to your existing Chrome profile.
echo.
set /p CONFIRM="Are you sure you want to close Chrome and relaunch it? (Y/N): "
if /i not "!CONFIRM!"=="Y" (
    echo Launch cancelled.
    pause
    exit /b 0
)

echo.
echo Closing all running Google Chrome instances...
taskkill /f /im chrome.exe >nul 2>&1
timeout /t 2 /nobreak >nul

set "CHROME_PATH="
for /f "usebackq tokens=2,*" %%A in (`reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe" /ve 2^>nul`) do (
    set "CHROME_PATH=%%B"
)

if not defined CHROME_PATH (
    if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
        set "CHROME_PATH=C:\Program Files\Google\Chrome\Application\chrome.exe"
    ) else if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
        set "CHROME_PATH=C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
    ) else if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" (
        set "CHROME_PATH=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
    )
)

if not defined CHROME_PATH (
    echo [ERROR] Google Chrome could not be found automatically.
    echo Please launch Chrome manually from the command line with:
    echo chrome.exe --remote-debugging-port=9222
    echo.
    pause
    exit /b 1
)

echo Found Chrome at: "%CHROME_PATH%"
echo Launching Chrome with remote debugging on port 9222...
start "" "%CHROME_PATH%" --remote-debugging-port=9222

echo.
echo Chrome has been launched with debugging enabled.
echo.
timeout /t 3 >nul
exit /b 0
