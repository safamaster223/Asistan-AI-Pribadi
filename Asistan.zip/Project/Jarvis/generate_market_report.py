import os
import sys

# Tambahkan path root proyek agar modul 'core' bisa di-import
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.automator.docgen import DocumentGenerator

def main():
    print("Menginisialisasi Document Generator...")
    generator = DocumentGenerator()

    # Data Laporan Komparatif yang sudah diurutkan secara logis dan terstruktur
    report_data = {
        "title": "Laporan Komparatif: Pasar Tradisional vs Pasar Modern",
        "subtitle": "Analisis Karakteristik, Sosial-Ekonomi, dan Infrastruktur",
        "sections": {
            "Daftar Isi": (
                "1. Abstrak .......................................................................................................... 1\n"
                "2. Pendahuluan .................................................................................................. 1\n"
                "3. Tinjauan Pustaka ............................................................................................ 2\n"
                "4. Metodologi ..................................................................................................... 2\n"
                "5. Pembahasan Detail .......................................................................................... 3\n"
                "6. Tabel Perbandingan Komprehensif ................................................................ 4\n"
                "7. Kesimpulan ..................................................................................................... 4\n"
                "8. Daftar Pustaka ............................................................................................... 5"
            ),
            "1. Abstrak": (
                "Laporan ini menyajikan analisis komparatif yang mendalam mengenai perbedaan fundamental antara pasar tradisional "
                "dan pasar modern di era kontemporer. Seiring dengan pesatnya urbanisasi dan perubahan gaya hidup masyarakat, "
                "eksistensi pusat perbelanjaan mengalami transformasi yang signifikan. Melalui pendekatan deskriptif analitis, "
                "laporan ini membedah lima aspek utama pembeda: sistem penentuan harga, infrastruktur fisik, kualitas produk, "
                "interaksi sosial, serta manajemen tata kelola. Hasil analisis menunjukkan bahwa meskipun pasar modern menawarkan "
                "keunggulan absolut dalam hal kenyamanan dan standardisasi, pasar tradisional tetap memegang peranan krusial sebagai "
                "urat nadi ekonomi kerakyatan, penyedia produk segar harian, dan ruang kohesi sosial. Laporan ini menyimpulkan bahwa "
                "kedua entitas tersebut tidak saling mematikan, melainkan berpotensi untuk bersinergi melayani segmentasi konsumen "
                "yang berbeda."
            ),
            "2. Pendahuluan": (
                "Dalam dinamika perekonomian suatu negara, pasar berfungsi sebagai institusi sentral tempat bertemunya kekuatan penawaran "
                "dan permintaan. Secara historis, pasar tradisional telah menjadi pusat perputaran ekonomi masyarakat lokal selama berabad-abad. "
                "Namun, seiring dengan arus globalisasi, modernisasi, dan peningkatan daya beli masyarakat kelas menengah, lanskap ritel "
                "mulai bergeser dengan kemunculan pasar modern seperti minimarket, supermarket, hingga hipermarket. Pergeseran ini "
                "memicu diskursus akademis maupun praktis mengenai daya saing dan keberlangsungan pasar tradisional di tengah gempuran "
                "kapitalisme ritel modern.\n\n"
                "Penelitian dan penyusunan laporan ini bertujuan untuk memberikan pemahaman yang komprehensif mengenai dikotomi antara "
                "pasar tradisional dan pasar modern. Pemahaman ini sangat penting bagi para pemangku kepentingan, termasuk pemerintah "
                "daerah dalam merumuskan kebijakan tata ruang kota, serta bagi pelaku Usaha Mikro, Kecil, dan Menengah (UMKM) dalam "
                "merancang strategi adaptasi. Dengan membedah karakteristik masing-masing pasar, kita dapat mengidentifikasi kekuatan, "
                "kelemahan, serta peluang sinergi di antara keduanya.\n\n"
                "Lebih jauh, laporan ini tidak hanya menyoroti aspek ekonomi transaksional, tetapi juga dimensi sosiologis dan kultural. "
                "Pasar bukan sekadar tempat pertukaran barang dengan uang, melainkan juga ruang publik tempat interaksi sosial dan "
                "pelestarian budaya lokal terjadi. Oleh karena itu, analisis komparatif ini disusun secara holistik untuk memberikan "
                "perspektif yang berimbang dan berbasis data empiris."
            ),
            "3. Tinjauan Pustaka": (
                "Berdasarkan Peraturan Presiden Republik Indonesia Nomor 112 Tahun 2007 tentang Penataan dan Pembinaan Pasar Tradisional, "
                "Pusat Perbelanjaan dan Toko Modern, Pasar Tradisional didefinisikan sebagai pasar yang dibangun dan dikelola oleh "
                "Pemerintah, Pemerintah Daerah, Swasta, Badan Usaha Milik Negara dan Badan Usaha Milik Daerah termasuk kerjasama dengan "
                "swasta dengan tempat usaha berupa toko, kios, los dan tenda yang dimiliki/dikelola oleh pedagang kecil, menengah, "
                "swadaya masyarakat atau koperasi dengan usaha skala kecil, modal kecil dan dengan proses jual beli barang dagangan "
                "melalui tawar menawar.\n\n"
                "Di sisi lain, Pasar Modern merujuk pada toko dengan sistem pelayanan mandiri (swalayan), menjual berbagai jenis barang "
                "secara eceran yang berbentuk Minimarket, Supermarket, Department Store, Hypermarket ataupun grosir yang berbentuk "
                "Perkulakan. Literatur ekonomi ritel modern menekankan bahwa keunggulan kompetitif pasar modern terletak pada efisiensi "
                "rantai pasok (supply chain), manajemen inventaris berbasis teknologi informasi, serta penciptaan atmosfer berbelanja "
                "(store atmosphere) yang dirancang secara psikologis untuk memicu perilaku pembelian impulsif (impulsive buying) dari konsumen."
            ),
            "4. Metodologi": (
                "Penyusunan laporan ini menggunakan metode kualitatif dengan pendekatan deskriptif komparatif. Pengumpulan data "
                "dilakukan melalui studi literatur (library research) yang bersumber dari jurnal ilmiah, regulasi pemerintah, dan "
                "publikasi ekonomi ritel. Data yang terkumpul kemudian direduksi, diklasifikasikan ke dalam lima variabel pembanding "
                "utama, dan dianalisis secara naratif untuk menarik kesimpulan yang logis dan terstruktur."
            ),
            "5. Pembahasan Detail": (
                "Perbedaan antara pasar tradisional dan pasar modern dapat dibedah melalui beberapa dimensi fundamental. Dimensi pertama "
                "adalah sistem penentuan harga. Di pasar tradisional, harga bersifat asimetris dan fleksibel. Terjadi proses negosiasi "
                "atau tawar-menawar secara langsung antara penjual dan pembeli. Proses ini tidak hanya menentukan harga akhir, tetapi "
                "juga membangun kedekatan emosional. Sebaliknya, pasar modern menerapkan sistem harga tetap (fixed price). Barang telah "
                "dilabeli dengan barcode dan harga yang terintegrasi dengan sistem basis data kasir. Konsumen tidak memiliki ruang untuk "
                "bernegosiasi, namun mendapatkan kepastian harga dan transparansi struk belanja.\n\n"
                "Dimensi kedua dan ketiga mencakup infrastruktur fisik serta kualitas produk. Pasar tradisional sering kali dihadapkan "
                "pada stigma infrastruktur yang kurang memadai, lorong yang sempit, sirkulasi udara alami yang terkadang pengap, serta "
                "kondisi sanitasi yang perlu ditingkatkan (terutama di area pasar basah). Namun, kelemahan fisik ini dikompensasi oleh "
                "tingkat kesegaran produk yang sangat tinggi, di mana komoditas pangan seperti sayur, daging, dan ikan didistribusikan "
                "langsung dari produsen pada hari yang sama. Di sisi lain, pasar modern menawarkan infrastruktur yang megah, bersih, "
                "berpendingin udara (AC), dan tata letak rak (planogram) yang sangat sistematis. Kualitas produk dijaga melalui standar "
                "operasional prosedur (SOP) yang ketat dan penggunaan mesin pendingin, serta menawarkan variasi produk yang jauh lebih "
                "luas termasuk barang impor dan manufaktur berskala besar.\n\n"
                "Dimensi keempat dan kelima berkaitan dengan interaksi sosial dan manajemen tata kelola. Pasar tradisional adalah ruang "
                "kohesi sosial yang kaya; interaksi yang terjadi bersifat personal, hangat, dan sering kali melampaui batas transaksional "
                "murni. Pedagang mengenal pelanggan tetapnya, menciptakan loyalitas berbasis hubungan antarmanusia. Secara manajerial, "
                "pasar tradisional dikelola secara terdesentralisasi dan individual oleh masing-masing pedagang dengan modal terbatas. "
                "Sebaliknya, pasar modern dikelola oleh entitas korporasi dengan manajemen terpusat. Interaksi sosial di pasar modern "
                "sangat minim dan murni transaksional (pembeli melayani diri sendiri dan berinteraksi singkat dengan kasir). Manajemen "
                "korporasi memungkinkan efisiensi biaya, kampanye promosi yang masif, dan analisis data konsumen (big data) untuk strategi pemasaran."
            ),
            "6. Tabel Perbandingan Komprehensif": {
                "type": "table",
                "headers": ["Aspek Perbandingan", "Pasar Tradisional", "Pasar Modern"],
                "rows": [
                    ["Sistem Harga", "Fleksibel, tawar-menawar, negosiasi langsung.", "Harga tetap (fixed price), terkomputerisasi."],
                    ["Infrastruktur & Fasilitas", "Sederhana, terbuka, pencahayaan alami, fasilitas dasar.", "Megah, tertutup, ber-AC, bersih, troli, parkir luas."],
                    ["Kualitas & Jenis Produk", "Sangat segar (harian), didominasi produk lokal/pangan.", "Terstandarisasi, tahan lama, variasi sangat luas (impor/lokal)."],
                    ["Interaksi Sosial", "Tinggi, personal, komunal, membangun keakraban.", "Rendah, transaksional, individualis (swalayan)."],
                    ["Manajemen & Tata Kelola", "Individual, modal kecil, pembukuan manual.", "Korporasi, terpusat, SOP ketat, sistem informasi terpadu."]
                ]
            },
            "7. Kesimpulan": (
                "Berdasarkan analisis komparatif yang telah diuraikan, dapat disimpulkan bahwa pasar tradisional dan pasar modern memiliki "
                "karakteristik, keunggulan, dan kelemahan yang saling bertolak belakang. Pasar modern unggul mutlak dalam hal kenyamanan "
                "infrastruktur, kelengkapan produk, dan efisiensi manajemen. Namun, pasar tradisional tetap tidak tergantikan dalam perannya "
                "sebagai penyedia komoditas pangan segar dengan harga yang lebih terjangkau, serta fungsinya sebagai ruang interaksi sosial "
                "dan penggerak ekonomi kerakyatan (UMKM).\n\n"
                "Ke depan, eksistensi keduanya tidak harus dipandang sebagai sebuah zero-sum game (saling mematikan). Diperlukan sinergi "
                "dan intervensi kebijakan, seperti program revitalisasi fisik dan digitalisasi pembayaran (misalnya adopsi QRIS) di pasar "
                "tradisional, agar dapat bersaing secara relevan. Pada akhirnya, keberagaman format ritel ini memberikan keuntungan maksimal "
                "bagi konsumen untuk memilih tempat berbelanja sesuai dengan preferensi, kebutuhan, dan daya beli mereka."
            ),
            "8. Daftar Pustaka": (
                "[1] Peraturan Presiden Republik Indonesia Nomor 112 Tahun 2007 tentang Penataan dan Pembinaan Pasar Tradisional, Pusat Perbelanjaan dan Toko Modern.\n"
                "[2] Kotler, P., & Keller, K. L. (2016). Marketing Management (15th ed.). Pearson Education.\n"
                "[3] Sinaga, P. (2010). Mengelola Pasar Tradisional di Era Modern. Jakarta: Penerbit Ekonomi Kerakyatan.\n"
                "[4] Levy, M., Weitz, B. A., & Grewal, D. (2018). Retailing Management (10th ed.). McGraw-Hill Education."
            )
        }
    }

    pdf_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "Pasar_Tradisional_vs_Modern.pdf"))
    docx_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "Pasar_Tradisional_vs_Modern.docx"))

    res_pdf = generator.write("pdf", pdf_path, report_data)
    print(f"Hasil PDF: {res_pdf}")

    res_docx = generator.write("docx", docx_path, report_data)
    print(f"Hasil Word: {res_docx}")

if __name__ == "__main__":
    main()
