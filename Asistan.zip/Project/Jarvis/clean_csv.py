import pandas as pd
import numpy as np
import re

# Path file
input_path = r"C:\Users\heker\Downloads\dataset_transaksi_rancu.csv"
output_path = r"C:\Users\heker\Downloads\dataset_transaksi_bersih.csv"

# 1. Membaca data
df = pd.read_csv(input_path)

# 2. Membersihkan nama kolom (menghapus spasi di awal/akhir)
df.columns = df.columns.str.strip()

# 3. Membersihkan Transaction ID dan menghapus duplikat
df['Transaction ID'] = df['Transaction ID'].astype(str).str.strip()
df = df.drop_duplicates(subset=['Transaction ID'], keep='first')

# 4. Membersihkan Tanggal Transaksi
def clean_date(d):
    if pd.isna(d) or str(d).strip() in ['INVALID_DATE', '', 'nan']:
        return pd.NaT
    d = str(d).strip()
    # Replace . and / with -
    d = d.replace('.', '-').replace('/', '-')
    try:
        return pd.to_datetime(d).strftime('%Y-%m-%d')
    except:
        return pd.NaT

df['Tgl_Trans_'] = df['Tgl_Trans_'].apply(clean_date)

# 5. Membersihkan ID Produk
df['ID_Produk'] = df['ID_Produk'].astype(str).str.strip().str.upper().str.replace(' ', '-')

# 6. Membersihkan Nama Barang
df['Nama Barang'] = df['Nama Barang'].astype(str).str.strip().str.title()
df['Nama Barang'] = df['Nama Barang'].replace('Nan', np.nan)

# 7. Membersihkan Kategori
df['Kategori_'] = df['Kategori_'].astype(str).str.strip().str.upper()
df['Kategori_'] = df['Kategori_'].replace(['NAN', 'N/A'], np.nan)

# 8. Membersihkan Harga Satuan & Total Bayar
def clean_currency(val):
    if pd.isna(val):
        return np.nan
    val = str(val).strip().upper()
    if val in ['UNKNOWN', '-', 'N/A', 'NAN', '']:
        return np.nan
    # Hapus karakter non-digit
    val = re.sub(r'[^\d]', '', val)
    if val == '':
        return np.nan
    return float(val)

df['Harga Satuan'] = df['Harga Satuan'].apply(clean_currency)
df['Total_Bayar'] = df['Total_Bayar'].apply(clean_currency)

# 9. Membersihkan Jumlah Jual
def clean_qty(val):
    if pd.isna(val):
        return np.nan
    val = str(val).strip().lower()
    if val == 'dua':
        return 2
    if val in ['nan', 'n/a', '', '-']:
        return np.nan
    try:
        num = int(float(val))
        return abs(num) if num != 0 else np.nan # Mengubah negatif jadi positif, 0 jadi NaN (asumsi tidak valid)
    except:
        return np.nan

df['Jumlah_Jual'] = df['Jumlah_Jual'].apply(clean_qty)

# 10. Membersihkan Metode Pembayaran
df['Metode Pembayaran'] = df['Metode Pembayaran'].astype(str).str.strip().str.upper().str.replace('_', ' ')
df['Metode Pembayaran'] = df['Metode Pembayaran'].replace(['NAN', 'N/A', ''], np.nan)

# 11. Membersihkan Status Order
df['Status_Order'] = df['Status_Order'].astype(str).str.strip().str.upper()
df['Status_Order'] = df['Status_Order'].replace(['NAN', 'N/A', ''], np.nan)

# 12. Mengisi Total Bayar yang kosong jika Harga Satuan dan Jumlah Jual ada
mask = df['Total_Bayar'].isna() & df['Harga Satuan'].notna() & df['Jumlah_Jual'].notna()
df.loc[mask, 'Total_Bayar'] = df.loc[mask, 'Harga Satuan'] * df.loc[mask, 'Jumlah_Jual']

# Simpan ke CSV baru
df.to_csv(output_path, index=False)
print("Data berhasil dibersihkan dan disimpan ke:", output_path)
