import sys
import os
import datetime
import argparse
import threading
import time
from PyQt6.QtWidgets import QApplication, QSystemTrayIcon, QMenu, QMessageBox
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QBuffer, QIODevice
from PyQt6.QtGui import QIcon, QPixmap, QPainter, QColor

def ensure_lottie_js():
    def download():
        assets_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "assets"))
        lottie_path = os.path.join(assets_dir, "lottie.min.js")
        if not os.path.exists(lottie_path):
            import urllib.request
            url = "https://cdnjs.cloudflare.com/ajax/libs/bodymovin/5.12.2/lottie.min.js"
            try:
                os.makedirs(assets_dir, exist_ok=True)
                with urllib.request.urlopen(url, timeout=5) as response:
                    data = response.read()
                with open(lottie_path, "wb") as f:
                    f.write(data)
                print("Successfully downloaded lottie.min.js to local assets.")
            except Exception as e:
                print(f"Warning: Could not download lottie.min.js: {e}")

    threading.Thread(target=download, daemon=True).start()

from config import load_settings, save_settings, get_personality_config
from ui.overlay_widget import OverlayWidget
from ui.chat_window import ChatWindow
from core.ai_engine import AIEngine
from core.tts import TTSManager
import core.history_manager as history_manager

class AIRequestWorker(QThread):
    chunk_received = pyqtSignal(str)
    status_changed = pyqtSignal(str)
    tool_called = pyqtSignal(str, dict)
    permission_requested = pyqtSignal(str, dict)
    finished = pyqtSignal(str)

    def __init__(self, ai_engine, messages, model_name, provider):
        super().__init__()
        self.ai_engine = ai_engine
        self.messages = messages
        self.model_name = model_name
        self.provider = provider
        self.full_response = ""

    def run(self):
        import threading

        def on_status(msg):
            self.status_changed.emit(msg)

        def on_tool(name, args):
            self.tool_called.emit(name, args)

        def on_permission(command):
            result = {"approved": False, "event": threading.Event()}
            self.permission_requested.emit(command, result)
            result["event"].wait()
            return result["approved"]

        stream = self.ai_engine.run_chat_stream(
            self.messages,
            self.model_name,
            self.provider,
            status_callback=on_status,
            tool_callback=on_tool,
            permission_callback=on_permission
        )

        for chunk in stream:
            self.chunk_received.emit(chunk)
            self.full_response += chunk

        self.finished.emit(self.full_response)


class JarvisApp:
    def __init__(self, workspace_override=None):
        self.settings = load_settings()
        if workspace_override:
            self.settings["safe_workspace_dir"] = os.path.abspath(workspace_override)

        self.ai_engine = AIEngine(self.settings)
        self.tts_manager = TTSManager()

        # Load or create active session
        self.active_session_id = None
        self.sessions = history_manager.load_sessions()
        if self.sessions:
            self.active_session_id = self.sessions[0]["session_id"]
            self.chat_history = history_manager.load_session_messages(self.active_session_id)
        else:
            self.start_new_session(save=False)

        # UI Components
        self.overlay = OverlayWidget(self.settings)
        self.chat_window = ChatWindow(self.settings)

        # Update lists in sidebar
        self.chat_window.update_session_list(self.sessions, self.active_session_id)
        self.chat_window.refresh_files_list()

        # Apply initial personality title
        p_config = get_personality_config(self.settings)
        self.chat_window.update_personality_title(p_config.get("name", "Cellya Claire"))

        self.setup_signals()
        self.setup_system_tray()

        self.overlay.show()
        # Display active session history or greet
        if self.chat_history:
            self.display_active_session_history()
        else:
            self.greet_user()

    def setup_signals(self):
        self.overlay.double_clicked.connect(self.toggle_chat)
        self.overlay.clear_chat_requested.connect(self.clear_history)
        self.overlay.exit_requested.connect(self.exit_app)
        self.overlay.personality_changed.connect(self.handle_personality_changed)

        self.chat_window.send_message.connect(self.handle_send_message)
        self.chat_window.clear_requested.connect(self.clear_history)
        self.chat_window.capture_screen_requested.connect(self.handle_capture_screen)

        # Connect session manager signals
        self.chat_window.load_session_requested.connect(self.handle_load_session)
        self.chat_window.delete_session_requested.connect(self.handle_delete_session)
        self.chat_window.new_session_requested.connect(self.handle_new_session)

    def handle_personality_changed(self, personality_id):
        p_config = get_personality_config(self.settings)
        p_name = p_config.get("name", "Cellya Claire")
        self.chat_window.update_personality_title(p_name)
        self.chat_window.chat_history.append(
            f"<div style='color: #10b981; font-family: Consolas, monospace; margin-bottom: 8px; font-size: 10px; padding: 4px 8px; background-color: rgba(16, 185, 129, 0.04); border: 1px solid rgba(16, 185, 129, 0.15);'>"
            f"SYSTEM // CORE PERSONALITY LOADED: {p_name.upper()}"
            f"</div>"
        )

    def setup_system_tray(self):
        self.tray_icon = QSystemTrayIcon(self.overlay)

        # Draw a sleek circular pixmap icon for system tray
        pixmap = QPixmap(16, 16)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setBrush(QColor(14, 165, 233))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(0, 0, 16, 16)
        painter.end()

        self.tray_icon.setIcon(QIcon(pixmap))

        self.tray_menu = QMenu(self.overlay)
        show_action = self.tray_menu.addAction("Show/Hide Overlay")
        show_action.triggered.connect(self.toggle_overlay)

        clear_action = self.tray_menu.addAction("Clear Conversation")
        clear_action.triggered.connect(self.clear_history)

        self.tray_menu.addSeparator()
        exit_action = self.tray_menu.addAction("Exit Cellya Claire")
        exit_action.triggered.connect(self.exit_app)

        self.tray_icon.setContextMenu(self.tray_menu)
        self.tray_icon.show()

    def toggle_overlay(self):
        if self.overlay.isVisible():
            self.overlay.hide()
            self.chat_window.hide()
        else:
            self.overlay.show()

    def toggle_chat(self):
        if self.chat_window.isVisible():
            self.tts_manager.stop()
            self.chat_window.hide_animated()
        else:
            self.chat_window.show_animated(self.overlay.pos())

    def greet_user(self):
        hour = datetime.datetime.now().hour
        if hour < 12:
            greeting = "Good morning, Sir"
        elif hour < 18:
            greeting = "Good afternoon, Sir"
        else:
            greeting = "Good evening, Sir"

        p_config = get_personality_config(self.settings)
        p_name = p_config.get("name", "Cellya Claire")

        safe_root = self.settings.get("safe_workspace_dir", os.getcwd())
        self.chat_window.chat_history.append(
            f"<div style='margin-bottom: 10px; color: #38BDF8;'><b>{p_name}:</b><br/>{greeting}. Safe workspace: <code>{safe_root}</code>. How can I assist you today?</div>"
        )

    def handle_send_message(self, text, model_name, provider, image_base64=None):
        # Stop any running Speech output immediately when sending a new message
        self.tts_manager.stop()
        self.chat_window.append_user_message(text, image_base64)

        if image_base64:
            content_list = [
                {"type": "text", "text": text},
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_base64}"}}
            ]
            self.chat_history.append({"role": "user", "content": content_list})
        else:
            self.chat_history.append({"role": "user", "content": text})

        # Save user message to active session file
        history_manager.save_session(self.active_session_id, "Untitled Chat", self.chat_history)
        self.sessions = history_manager.load_sessions()
        self.chat_window.update_session_list(self.sessions, self.active_session_id)

        self.overlay.set_state("thinking")
        self.chat_window.update_status("Thinking...")
        self.chat_window.append_ai_chunk("", is_new=True)

        self.worker = AIRequestWorker(self.ai_engine, self.chat_history, model_name, provider)
        self.worker.chunk_received.connect(self.on_chunk_received)
        self.worker.status_changed.connect(self.on_status_changed)
        self.worker.tool_called.connect(self.on_tool_called)
        self.worker.permission_requested.connect(self.prompt_user_permission)
        self.worker.finished.connect(self.on_request_finished)
        self.worker.start()

    def prompt_user_permission(self, command, result_dict):
        msg_box = QMessageBox(self.chat_window)
        msg_box.setWindowTitle("Permission Required")
        msg_box.setText("Jarvis is requesting permission to execute a terminal command:")
        msg_box.setInformativeText(f"<code>{command}</code>")
        msg_box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        msg_box.setDefaultButton(QMessageBox.StandardButton.No)

        msg_box.setStyleSheet("""
            QMessageBox {
                background-color: #1E1E1E;
                color: #F8FAFC;
            }
            QLabel {
                color: #E2E8F0;
                font-size: 12px;
            }
            QPushButton {
                background-color: #0EA5E9;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 5px 12px;
                min-width: 60px;
            }
            QPushButton:hover {
                background-color: #0284C7;
            }
        """)

        ret = msg_box.exec()

        if ret == QMessageBox.StandardButton.Yes:
            result_dict["approved"] = True
        else:
            result_dict["approved"] = False

        result_dict["event"].set()

    def handle_capture_screen(self):
        self.chat_window.hide()
        self.overlay.hide()

        QApplication.processEvents()
        QThread.msleep(250)

        screen = QApplication.primaryScreen()
        if screen:
            pixmap = screen.grabWindow(0)

            self.overlay.show()
            self.chat_window.show()
            self.chat_window.raise_()
            self.chat_window.activateWindow()

            buffer = QBuffer()
            buffer.open(QIODevice.OpenModeFlag.WriteOnly)
            pixmap.save(buffer, "PNG")
            base64_data = buffer.data().toBase64().data().decode("utf-8")
            buffer.close()

            self.chat_window.attach_screenshot(pixmap, base64_data)
        else:
            self.overlay.show()
            self.chat_window.show()

    def on_chunk_received(self, chunk):
        self.chat_window.append_ai_chunk(chunk)

    def on_status_changed(self, msg):
        self.chat_window.update_status(msg)
        if "Running tool" in msg:
            self.overlay.set_state("working")
        else:
            self.overlay.set_state("thinking")

    def on_tool_called(self, name, args):
        path_arg = args.get('file_path', args.get('dir_path', ''))
        detail = f": {path_arg}" if path_arg else ""
        self.chat_window.chat_history.append(
            f"<div style='color: #F59E0B; margin-bottom: 5px; font-size: 11px;'><i>[Executing system operation: {name}{detail}]</i></div>"
        )

    def on_request_finished(self, full_response):
        self.chat_history.append({"role": "assistant", "content": full_response})
        self.chat_window.finish_stream()
        self.overlay.set_state("idle")
        self.worker = None

        # Save assistant message to active session file
        history_manager.save_session(self.active_session_id, "Untitled Chat", self.chat_history)
        self.sessions = history_manager.load_sessions()
        self.chat_window.update_session_list(self.sessions, self.active_session_id)
        self.chat_window.refresh_files_list()  # Auto-refresh files in case any document was written!

        # Read aloud if voice mode is activated
        if self.settings.get("voice_mode", False):
            self.tts_manager.speak(full_response)

    def clear_history(self):
        self.tts_manager.stop()
        self.chat_history.clear()
        self.chat_window.chat_history.clear()
        self.chat_window.chat_history.setHtml("<p style='color:#64748B;'>Conversation cleared.</p>")
        self.overlay.set_state("idle")

        # Save empty history for the active session file
        history_manager.save_session(self.active_session_id, "Untitled Chat", self.chat_history)
        self.sessions = history_manager.load_sessions()
        self.chat_window.update_session_list(self.sessions, self.active_session_id)

    def exit_app(self):
        self.chat_window.save_geometry()
        save_settings(self.settings)
        QApplication.quit()

    # ==========================================
    # Session Loading, Deleting, and Creation Handlers
    # ==========================================

    def handle_load_session(self, session_id):
        self.active_session_id = session_id
        self.chat_history = history_manager.load_session_messages(session_id)
        self.display_active_session_history()
        self.chat_window.update_session_list(self.sessions, self.active_session_id)

    def handle_delete_session(self, session_id):
        history_manager.delete_session(session_id)
        self.sessions = history_manager.load_sessions()
        if self.active_session_id == session_id:
            if self.sessions:
                self.active_session_id = self.sessions[0]["session_id"]
                self.chat_history = history_manager.load_session_messages(self.active_session_id)
                self.display_active_session_history()
            else:
                self.start_new_session(save=True)
        else:
            self.chat_window.update_session_list(self.sessions, self.active_session_id)

    def handle_new_session(self):
        self.start_new_session(save=True)

    def start_new_session(self, save=True):
        self.active_session_id = str(int(time.time()))
        self.chat_history = []
        if save:
            history_manager.save_session(self.active_session_id, "Untitled Chat", self.chat_history)
            self.sessions = history_manager.load_sessions()
            self.chat_window.update_session_list(self.sessions, self.active_session_id)
            self.chat_window.chat_history.clear()
            self.chat_window.chat_history.setHtml("<p style='color:#64748B;'>New chat started.</p>")
            self.greet_user()

    def display_active_session_history(self):
        self.chat_window.chat_history.clear()

        # Re-display initialized system block
        self.chat_window.chat_history.setHtml(
            "<div style='color: #00f0ff; font-family: Consolas, monospace; font-size: 11px; padding: 6px 10px; "
            "background-color: rgba(0, 240, 255, 0.03); border: 1px solid rgba(0, 240, 255, 0.15); margin-bottom: 12px;'>"
            "SYSTEM INITIALIZED // CELLYA CLAIRE ONLINE<br/>"
            "&gt; Double-click overlay bubble to show/hide this console.<br/>"
            "&gt; Input commands or ask questions below."
            "</div>"
        )

        for msg in self.chat_history:
            role = msg.get("role")
            content = msg.get("content")
            if role == "user":
                if isinstance(content, list):
                    text = ""
                    image_base64 = None
                    for part in content:
                        if part.get("type") == "text":
                            text = part.get("text", "")
                        elif part.get("type") == "image_url":
                            url = part["image_url"]["url"]
                            if ";base64," in url:
                                image_base64 = url.split(";base64,")[1]
                    self.chat_window.append_user_message(text, image_base64)
                else:
                    self.chat_window.append_user_message(str(content))
            elif role == "assistant":
                if isinstance(content, list):
                    text_parts = [part["text"] for part in content if part.get("type") == "text"]
                    text = " ".join(text_parts)
                else:
                    text = str(content)
                if text:
                    self.chat_window.append_ai_chunk(text, is_new=True)
                    self.chat_window.finish_stream()


if __name__ == "__main__":
    ensure_lottie_js()
    parser = argparse.ArgumentParser(description="Jarvis - Floating Desktop AI Agent")
    parser.add_argument("--workspace", help="Sets safe directory root for file operations")
    args, unknown = parser.parse_known_args()

    app = QApplication(sys.argv)
    jarvis = JarvisApp(workspace_override=args.workspace)
    sys.exit(app.exec())
