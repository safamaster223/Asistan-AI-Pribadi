import asyncio
import edge_tts
import os

# Teks yang akan diubah menjadi suara
TEXT = "Halo Tuan, perkenalkan, ini adalah suara Gadis dari Microsoft Edge Neural. Bagaimana menurut Anda? Apakah suara saya sudah terdengar lebih natural, fasih, dan tidak kaku lagi?"
VOICE = "id-ID-GadisNeural"
OUTPUT_FILE = "suara_cellya.mp3"

async def amain() -> None:
    print(f"Menghasilkan suara menggunakan model: {VOICE}...")
    communicate = edge_tts.Communicate(TEXT, VOICE)
    await communicate.save(OUTPUT_FILE)
    print(f"File audio berhasil disimpan di: {OUTPUT_FILE}")

if __name__ == "__main__":
    # Menjalankan fungsi async
    asyncio.run(amain())
    
    # Memutar file audio secara otomatis di Windows
    print("Memutar audio...")
    os.startfile(OUTPUT_FILE)
