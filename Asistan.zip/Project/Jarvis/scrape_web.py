import asyncio
import argparse
import re
from urllib.parse import urlparse
from playwright.async_api import async_playwright

def clean_markdown(text):
    # Bersihkan spasi ganda dan baris kosong berlebih
    text = re.sub(r' {2,}', ' ', text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()

async def scrape_generic(url, output_file=None):
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )
        page = await context.new_page()
        
        try:
            # Gunakan networkidle karena Google Translate memuat konten secara dinamis via AJAX
            print(f"Navigating to {url}...")
            await page.goto(url, wait_until="networkidle", timeout=60000)
            
            # Tunggu ekstra beberapa detik untuk memastikan Google Translate selesai me-render teks
            await page.wait_for_timeout(3000)
            
            title = await page.title()
            
            # In-Browser Evaluation dengan Generic Selector
            markdown_content = await page.evaluate('''() => {
                // Cari container utama, fallback ke body jika tidak ada tag semantic
                let container = document.querySelector('main') || document.querySelector('article') || document.body;
                if (!container) return "";

                const clone = container.cloneNode(true);

                // Hapus elemen non-konten (noise) umum pada website
                const noiseSelectors = [
                    'nav', 'header', 'footer', 'aside', 'script', 'style', 
                    'noscript', 'svg', 'form', 'button', '.menu', '.sidebar', 
                    'iframe', '.cookie-banner'
                ];
                noiseSelectors.forEach(sel => {
                    clone.querySelectorAll(sel).forEach(el => el.remove());
                });

                let md = "";
                // Ambil elemen teks dan tabel
                const elements = clone.querySelectorAll('p, h1, h2, h3, h4, h5, h6, li, table');
                
                elements.forEach(el => {
                    const tag = el.tagName.toLowerCase();
                    const text = el.innerText.trim();
                    
                    if (!text) return;

                    if (tag === 'p') {
                        md += text + "\\n\\n";
                    } else if (tag.startsWith('h')) {
                        const level = parseInt(tag.substring(1));
                        md += "#".repeat(level) + " " + text + "\\n\\n";
                    } else if (tag === 'li') {
                        md += "- " + text + "\\n";
                    } else if (tag === 'table') {
                        const rows = el.querySelectorAll('tr');
                        let isFirstRow = true;
                        
                        rows.forEach(row => {
                            const cells = row.querySelectorAll('th, td');
                            if (cells.length === 0) return;
                            
                            let rowMd = "|";
                            cells.forEach(cell => {
                                let cellText = cell.innerText.replace(/\\r?\\n/g, " ").trim();
                                rowMd += ` ${cellText} |`;
                            });
                            md += rowMd + "\\n";
                            
                            if (isFirstRow) {
                                let sepMd = "|";
                                cells.forEach(() => { sepMd += "---|"; });
                                md += sepMd + "\\n";
                                isFirstRow = false;
                            }
                        });
                        md += "\\n";
                    }
                });
                
                return md;
            }''')
            
            final_content = f"# {title}\n\n{markdown_content}"
            final_content = clean_markdown(final_content)
            
            if not output_file:
                domain = urlparse(url).netloc.replace('.', '_')
                output_file = f"{domain}_scraped.md"
            
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(final_content)
                
            print(f"SUCCESS: Scraping selesai. Hasil disimpan di {output_file}")
            
        except Exception as e:
            print(f"ERROR: {e}")
        finally:
            await browser.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generic Web Scraper")
    parser.add_argument("url", help="Target URL to scrape")
    parser.add_argument("-o", "--output", help="Output Markdown file name", default=None)
    args = parser.parse_args()
    
    asyncio.run(scrape_generic(args.url, args.output))
