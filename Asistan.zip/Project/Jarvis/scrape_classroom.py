import json
import argparse
import sys
from config import load_settings
from core.automator.browser import BrowserManager
from core.automator.classroom import ClassroomScraper

def main():
    parser = argparse.ArgumentParser(description="Google Classroom Scraper for Jarvis")
    parser.add_argument("--login", action="store_true", help="Launch Chrome in headed mode to login to Google Classroom once")
    parser.add_argument("--headless", action="store_true", default=False, help="Launch Chrome in headless mode for background operations")
    args = parser.parse_args()

    try:
        settings = load_settings()
        profile_dir = settings.get("chrome_profile_directory", "Default")

        # If --login is requested, we MUST run headed (not headless)
        headless_mode = args.headless if not args.login else False

        if args.login:
            print("==================================================================")
            print("LAUCHING GOOGLE CHROME FOR FIRST-TIME LOGIN SETUP")
            print("------------------------------------------------------------------")
            print("1. Please log in to your Google/Google Classroom account in the")
            print("   Chrome window that opens.")
            print("2. Once successfully logged in, simply CLOSE the Google Chrome window")
            print("   to complete the setup and save your session details.")
            print("==================================================================")

        # For login helper, run on port 9223 to avoid conflicts with main app's port 9222
        port = 9223 if args.login else 9222
        bm = BrowserManager(profile_directory=profile_dir, port=port)
        bm.start_session(headless=headless_mode)
        page = bm.get_active_page()

        if args.login:
            # Navigate to classroom home so user can sign in
            page.goto("https://classroom.google.com/h")
            print("\nWaiting for Chrome window to be closed...")

            try:
                # Check both page status and connection status. If the browser window
                # is closed, the connection is lost and bm.browser.is_connected() becomes False.
                while bm.browser and bm.browser.is_connected() and not page.is_closed():
                    page.wait_for_timeout(500)
            except Exception:
                pass

            bm.close()
            print("Login helper finished. Session saved.")
            return

        scraper = ClassroomScraper(page)
        courses = scraper.get_courses()
        print(json.dumps(courses, indent=2, ensure_ascii=False))

        # Clean up browser session
        bm.close()
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
