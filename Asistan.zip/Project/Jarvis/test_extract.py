import yt_dlp

def test_extract():
    print("Mencoba mengekstrak URL audio dari YouTube...")
    ydl_opts = {
        'format': 'bestaudio/best',
        'quiet': True
    }
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            # Menggunakan video pendek untuk tes
            info = ydl.extract_info("https://www.youtube.com/watch?v=BaW_jenozKc", download=False)
            print("BERHASIL! URL Audio murni didapatkan:")
            print(info['url'][:100] + "...") # Print sebagian URL saja
    except Exception as e:
        print(f"GAGAL mengekstrak: {e}")

test_extract()
