hello mas al 
Jarvis/venv/Scripts/python.exe Jarvis/main.py
 Jarvis/venv/Scripts/python.exe Jarvis/main.py