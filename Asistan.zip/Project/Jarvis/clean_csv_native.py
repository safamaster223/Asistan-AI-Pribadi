import csv
import re
from datetime import datetime

input_path = r"C:\Users\heker\Downloads\dataset_transaksi_rancu.csv"
output_path = r"C:\Users\heker\Downloads\dataset_transaksi_bersih.csv"

def clean_date(d):
    d = d.strip()
    if d in ['INVALID_DATE', '', 'nan', 'N/A']:
        return ''
    d = d.replace('.', '-').replace('/', '-')
    try:
        # Try parsing different formats
        for fmt in ('%d-%b-%Y', '%Y-%m-%d', '%d-%m-%Y'):
            try:
                return datetime.strptime(d, fmt).strftime('%Y-%m-%d')
            except ValueError:
                pass
        return d # Return as is if parsing fails
    except:
        return ''

def clean_currency(val):
    val = val.strip().upper()
    if val in ['UNKNOWN', '-', 'N/A', 'NAN', '']:
        return ''
    val = re.sub(r'[^\d]', '', val)
    return val

def clean_qty(val):
    val = val.strip().lower()
    if val == 'dua':
        return '2'
    if val in ['nan', 'n/a', '', '-']:
        return ''
    try:
        num = int(float(val))
        if num == 0: return ''
        return str(abs(num))
    except:
        return ''

with open(input_path, 'r', encoding='utf-8') as infile, open(output_path, 'w', encoding='utf-8', newline='') as outfile:
    reader = csv.reader(infile)
    writer = csv.writer(outfile)
    
    headers = next(reader)
    headers = [h.strip() for h in headers]
    writer.writerow(headers)
    
    seen_trx = set()
    
    for row in reader:
        if not row: continue
        
        # Pad row if it's shorter than headers
        row = row + [''] * (len(headers) - len(row))
        
        trx_id = row[0].strip()
        if trx_id in seen_trx or not trx_id:
            continue
        seen_trx.add(trx_id)
        
        tgl = clean_date(row[1])
        id_prod = row[2].strip().upper().replace(' ', '-')
        nama = row[3].strip().title()
        if nama.lower() == 'nan': nama = ''
        
        kategori = row[4].strip().upper()
        if kategori in ['NAN', 'N/A']: kategori = ''
        
        harga = clean_currency(row[5])
        qty = clean_qty(row[6])
        total = clean_currency(row[7])
        
        metode = row[8].strip().upper().replace('_', ' ')
        if metode in ['NAN', 'N/A']: metode = ''
        
        status = row[9].strip().upper()
        if status in ['NAN', 'N/A']: status = ''
        
        # Calculate total if missing
        if not total and harga and qty:
            total = str(int(harga) * int(qty))
            
        writer.writerow([trx_id, tgl, id_prod, nama, kategori, harga, qty, total, metode, status])

print("Data berhasil dibersihkan dan disimpan ke:", output_path)
