# Situs web

Situs web (bahasa Inggris: website ) adalah sekumpulan halaman web yang saling berhubungan yang umumnya berada pada peladen yang sama berisikan kumpulan informasi yang disediakan secara perorangan, kelompok, atau organisasi. Sebuah situs web biasanya ditempatkan setidaknya pada sebuah server web yang dapat diakses melalui jaringan seperti Internet, ataupun jaringan area lokal (LAN) melalui alamat Internet yang dikenali sebagai URL. Gabungan atas semua situs yang dapat diakses publik di Internet disebut pula sebagai World Wide Web atau lebih dikenal dengan singkatan WWW. Meskipun setidaknya halaman beranda situs Internet umumnya dapat diakses publik secara bebas, pada praktiknya tidak semua situs memberikan kebebasan bagi publik untuk mengaksesnya, beberapa situs web mewajibkan pengunjung untuk melakukan pendaftaran sebagai anggota, atau bahkan meminta pembayaran untuk dapat menjadi anggota untuk dapat mengakses isi yang terdapat dalam situs web tersebut, misalnya situs-situs yang menampilkan pornografi, situs-situs berita, layanan surel (e-mail), dan lain-lain. Pembatasan-pembatasan ini umumnya dilakukan karena alasan keamanan, menghormati privasi, atau karena tujuan komersial tertentu.

Sebuah halaman web adalah berkas yang ditulis sebagai berkas teks biasa (plain text ) yang diatur dan dikombinasikan sedemikian rupa dengan instruksi-instruksi berbasis HTML atau XHTML, kadang-kadang pula disisipi dengan sekelumit bahasa skrip. Berkas tersebut kemudian diterjemahkan oleh peramban web dan ditampilkan seperti layaknya sebuah halaman pada monitor komputer.

Halaman-halaman web tersebut diakses oleh pengguna melalui protokol komunikasi jaringan yang disebut sebagai HTTP, sebagai tambahan untuk meningkatkan aspek keamanan dan aspek privasi yang lebih baik, situs web dapat pula mengimplementasikan mekanisme pengaksesan melalui protokol HTTPS.

## Sejarah

Penemu situs web adalah Sir Timothy John "Tim" Berners-Lee, sedangkan situs web yang tersambung dengan jaringan pertama kali muncul pada tahun 1991. Maksud dari Tim ketika merancang situs web adalah untuk memudahkan tukar menukar dan memperbarui informasi pada sesama peneliti di tempat ia bekerja. Pada tanggal 30 April 1993, CERN (tempat di mana Tim bekerja) mengumumkan bahwa WWW dapat digunakan secara gratis oleh publik.

Sebuah situs web bisa berupa hasil kerja dari perorangan atau individu, atau menunjukkan kepemilikan dari suatu organisasi, perusahaan. biasanya pembahasan dalam sebuah situs web merujuk pada sebuah ataupun beberapa topik khusus, atau kepentingan tertentu. Sebuah situs web bisa berisi pranala yang menghubungkan ke situs web lain, demikian pula dengan situs web lainnya. Hal ini terkadang membuat perbedaan antara situs web yang dibuat oleh individu ataupun perseorangan dengan situs web yang dibuat oleh organisasi bisnis menjadi tidak begitu jelas.

Situs web biasanya ditempatkan pada server web. Sebuah server web umumnya telah dilengkapi dengan perangkat-perangkat lunak khusus untuk menangani pengaturan nama ranah, serta menangani layanan atas protokol HTTP yang disebut sebagai Server HTTP (bahasa Inggris: HTTP Server) seperti Apache HTTP Server, atau Internet Information Services (IIS).

## Deskripsi

Supaya bisa berkomunikasi dengan semua komputer yang tersambung ke Internet, digunakan sebuah protokol komunikasi yang menggunakan TCP/IP (Transmission Control Protocol/Internet Protocol). Setiap komputer yang terhubung ke Internet mempunyai sebuah alamat, misalnya 192.168.14.96. Untuk memperoleh informasi atau data di Internet, kita dapat mengaksesnya dengan mengetikkan suatu alamat web pada address bar. Alamat suatu situs di Internet disebut nama domain. Jadi, nama domain adalah alamat permanen situs didunia Internet yang digunakan untuk mengidentifikasikan sebuah situs. Dengan kata lain, Domain Name adalah alamat yang digunakan untuk menemukan suatu situs pada Internet.

Kaitannya dengan protokol komunikasi TCP/IP, nama domain dapat diibaratkan seperti buku telepon, kita menggunakan sebuah nomor untuk memanggil seseorang. misalnya ketika kita mengekses situs www.wikipedia.com maka penjelajah web Internet Explorer akan menghubungi sebuah IP misalnya 202.68.0.134.

Istilah umum dan nama domain adalah URL (Uniform Resource Locator) yang merupakan sarana untuk menentukan alamat yang akan dipakai untuk mengakses Internet. Alamat URL merupakan alamat khusus untuk file tertentu yang bisa diakses oleh Internet. Alamat URL mencakup semua jenis file lain yang bisa diakses oleh Internet, misalnya file html, zip, rar, jpg, gif, dan png.

Alamat URL yang lengkap adalah sebagai berikut:
Protokol://nama-host/path/nama file

Contoh: http://www.wikipedia.co.id/artikel/ensiklopedia.htm

Secara garis besar, situs web bisa digolongkan menjadi 3 bagian yaitu:

## Situs web statis

Situs web statis merupakan situs web yang memiliki isi tidak dimaksudkan untuk diperbarui secara berkala sehingga pengaturan ataupun pemutakhiran isi atas situs web tersebut dilakukan secara manual. Ada tiga jenis perangkat utilitas yang biasa digunakan dalam pengaturan situs web statis:

## Situs web dinamis

Situs web dinamis merupakan situs web yang secara spesifik didisain agar isi yang terdapat dalam situs tersebut dapat diperbarui secara berkala dengan mudah. Sesuai dengan namanya, isi yang terkadung dalam situs web ini umumnya akan berubah setelah melewati satu periode tertentu. Situs berita adalah salah satu contoh jenis situs yang umumnya mengimplementasikan situs web dinamis.

Tidak seperti halnya situs web statis, pengimplementasian situs web dinamis umumnya membutuhkan keberadaan infrastruktur yang lebih kompleks dibandingkan situs web statis. Hal ini disebabkan karena pada situs web dinamis halaman web umumnya baru akan dibuat saat ada pengguna yang mengaksesnya, berbeda dengan situs web statis yang umumnya telah membentuk sejumlah halaman web saat diunggah di server web sehingga saat pengguna mengaksesnya server web hanya tinggal memberikan halaman tersebut tanpa perlu membuatnya terlebih dulu.

Untuk memungkinkan server web menciptakan halaman web pada saat pengguna mengaksesnya, umumnya pada server web dilengkapi dengan mesin penerjemah bahasa skrip (PHP, ASP, ColdFusion, atau lainnya), serta perangkat lunak sistem manajemen basisdata relasional seperti MySQL.

Struktur berkas sebuah situs web dinamis umumnya berbeda dengan situs web statis, berkas-berkas pada situs web statis umumnya merupakan sekumpulan berkas yang membentuk sebuah situs web. Berbeda halnya dengan situs web dinamis, berkas-berkas pada situs web dinamis umumnya merupakan sekumpulan berkas yang membentuk perangkat lunak aplikasi web yang akan dijalankan oleh mesin penerjemah server web, berfungsi memanajemen pembuatan halaman web saat halaman tersebut diminta oleh pengguna.

## Domain

Domain adalah adalah alamat sebuah situs web, sebenarnya alamat dari situs-situs yang eksis di Internet ini bentuk dasarnya berupa angka-angka, contohnya 17.125.135.147 bila angka ini diketik di addres bar di penejelajah web maka akan terbuka situs web Google, contoh lain 72.30.38.140 kalau ini yang diketik maka akan terbuka Yahoo. Penggunaan angka-angka ini sering disebut dengan alamat IP padahal itu sebenarnya adalah alamat domain.

Domain menggunakan kata-kata bertujuan supaya penggunaannya lebih mudah diingat daripada harus menghafal urutan angka-angka yang panjang. Oleh sebab itu, para ahli Internet membuat sistem penamaan domain dalam bentuk kata untuk pengganti urutan angka-angka tersebut.

Bagian-bagian dari domain.

Contohnya: wikipedia.org yang menjadi nama domain adalah wikipedia dan ekstensi yang digunakan adalah.org. Pada awalnya, ekstensi domain tidak begitu banyak, sekarang ekstensi domain sudah sangat banyak di antaranya (.com,.edu,.co.id,.gov,.org dan sebagainya). Pemberian extensi terhadap sebuah domain tidak boleh sembarangan terutama untuk.edu,.gov,.go.id dan berbagai ekstensi yang hanya disediakan bagi lembaga pendidikan dan pemerintah saja.

### Subdomain

Subdomain jika analogikan sebagai sebuah buku, dalam sebuah buku ada bab dan juga ada subbab yang merupakan bagian dari sebuh bab. Begitu juga dengan domain, subdomain merupakan halaman bagian dari sebuah domain. Contohnya http://id.wikipedia.org/ wikipedia.org merupakan sebuah domain dan id adalah subdomain dari domain wikipedia.org tersebut.

#### Top Level Domain

Top Level Domain Name adalah deretan kata dibelakang nama domain. Ada dua macam Top Level Domain, yaitu Global Top Level Domain (gTLD) dan Country Code Top Level Domain (ccTLD). Contoh gTLD adalah seperti.com (dotcommercial),.net (dotnetwork),.org (dotorganization),.edu (doteducation),.gov (dotgoverment), dan.mil (dotmilitary). Sedangkan ccTLD adalah TLD yang diperuntukkan untuk masing-masing negara, seperti Indonesia dengan kode ID (co.id, net.id, or.id).

#### Second Level Domain (SLD)

Second Level Domain Name (SLD) adalah nama domain yang anda daftarkan. Misalnya nama domain yang anda daftarkan adalah domainku.com, maka domainku adalah SLD dan.comnya adalah TLD.

#### Third Level Domain

Third Level Domain adalah nama sebelum Second Level Domain dan Top Level Domain. Misalnya nama domain yang anda miliki adalah domainku.com, maka anda dapat menambahkan nama lain sebelum domainku, yaitu mail.domainku.com atau search.domainku.com.

## Jenis Domain

Domain dibedakan dalam beberapa tipe sesuai dengan tujuan dan kegunaan masing-masing. Kita bebas dalam memilih dan menggunakan domain yang kita inginkan (kecuali beberapa domain yang harus memiliki izin khusus) tetapi penggunaan domain harus dipertanggungjawabkan penggunaannya. Ada baiknya penggunaan domain sesuai dengan konten dari blog atau situs web. Misalnya domain.info, benar-benar digunakan sebagai media informasi. Berikut adalah jenis-jenis domain:

### GTLD (Generic Top Level Domain)

Domain jenis ini adalah sebenarnya milik Amerika, namun karena domain-domain GTLD sering digunakan sehingga terlihat seperti domain standar untuk alamat Internet.

Contoh GTLD:

### ccTLD (Country Coded Top Level Domains)

Domain yang disediakan untuk masing-masing negara seperti:

Untuk Indonesia terbagi menjadi beberapa sub domain seperti:

##.id

.id adalah top-level domain kode negara Internet untuk Indonesia. Sejak 1 September 2005, domain.id dikelola oleh Kementerian Komunikasi dan Informasi Indonesia. Sebelumnya domain.id dikelola melalui kerjasama antara Asosiasi Penyelenggara Jasa Internet Indonesia (APJII) dan pengelola domain.id (ccTLD-ID).

Mulai 1 Mei 2007, pengelolaan domain.id sepenuhnya berada di tangan Pengelola Nama Domain Internet Indonesia, sebuah organisasi nirlaba yang dibentuk komunitas teknologi informasi di Indonesia.

## URL (Uniform Resource Locator)

URL adalah Uniform Resource Locator, yaitu cara penamaan alamat file di Internet. URL merupakan serangkaian karakter (dapat berupa huruf, angka, ataupun simbol) yang sesuai dengan format standar yang sudah ditentukan, URL digunakan untuk menunjukkan alamat/ address suatu sumber yang ada. URL biasa disebut dengan nama domain, contohnya http://www.ensiklopedia.com. URL diciptakan pertama kalinya oleh Tim Berners-Lee yaitu pada tahun 1991.

URL adalah singkatan dari Uniform Resource Locator yang berarti suatu “pathname” untuk mengidentifikasi sebuah dokumen di web. Di dalam URL terdapat informasi nama mesin/host (dalam hal ini komputer) yang akan diakses, nama dokumen beserta logical pathnamenya serta jenis protokol yang akan digunakan untuk melakukan akses ke web.

Pengertian URL (Uniform Resource Locator) adalah rangkaian karakter menurut suatu format standar tertentu, yang digunakan untuk menunjukkan alamat suatu sumber seperti dokumen dan gambar di Internet. URL pertama kali diciptakan oleh Tim Berners-Lee pada tahun 1991 agar penulis-penulis dokumen dapat mereferensikan pranala ke World Wide Web. Sejak 1994, konsep URL telah dikembangkan menjadi istilah Uniform Resource Identifier (URI) yang lebih umum sifatnya.

Contoh dari URL adalah sebagai berikut:

URL mempunyai beberapa bagian penting, di antaranya yaitu:

Tanpa adanya protocol yang tepat maka kita tidak akan dapat mengakses URL, contoh protokol yaitu: http://, https://, ftp://

Dalam mengakses URL tentunya kita harus mengetahui alamat server/ penyedianya. Contohnya yaitu: temukanpengertian.blogspot.com

Merupakan tempat/ lokasi file yang akan kita tuju. Contohnya kita ingin melihat halaman pada sebuah situs web pada blog ini maka file pathnya yaitu:

### Fungsi atau kegunaan URL

## Server web

Server web atau peladen web dapat merujuk baik pada perangkat keras ataupun perangkat lunak yang menyediakan layanan akses kepada pengguna melalui protokol komunikasi HTTP atau HTTPS atas berkas-berkas yang terdapat pada suatu situs web dalam layanan ke pengguna dengan menggunakan aplikasi tertentu seperti peramban web.

Penggunaan paling umum server web adalah untuk menempatkan situs web, namun pada praktiknya penggunaannya diperluas sebagai tempat peyimpanan data ataupun untuk menjalankan sejumlah aplikasi kelas bisnis.

## Layanan web

Layanan web merupakan fenomena yang sangat panas saat ini karena, banyak kelebihan yang ditawarkan oleh layanan web terutama interoperabilitas tinggi dan penggunaannya yang dapat diakses kapan pun dan di mana pun selama mesin kita terhubung oleh jaringan Internet salah satunya.

## Penyedia jasa Internet

Penyedia jasa Internet (disingkat PJI) (bahasa Inggris: Internet Service Provider disingkat ISP) adalah perusahaan atau badan yang menyediakan jasa sambungan Internet dan jasa lainnya yang berhubungan. Kebanyakan perusahaan telepon merupakan penyedia jasa Internet. Mereka menyediakan jasa seperti hubungan ke Internet, pendaftaran nama domain, dan hosting.

ISP ini mempunyai jaringan baik secara domestik maupun internasional sehingga pelanggan atau pengguna dari sambungan yang disediakan oleh ISP dapat terhubung ke jaringan Internet global. Jaringan di sini berupa media transmisi yang dapat mengalirkan data yang dapat berupa kabel (modem, sewa kabel, dan jalur lebar), radio, maupun VSAT.

## Pusat data

Pusat data (bahasa Inggris: Data center ) adalah suatu fasilitas yang digunakan untuk menempatkan sistem komputer dan komponen-komponen terkaitnya, seperti sistem telekomunikasi dan penyimpanan data. Fasilitas ini biasanya mencakup juga catu daya redundan atau cadangan, koneksi komunikasi data redundan, pengontrol lingkungan (misalnya AC dan ventilasi).

## Mesin pencari web

Mesin pencari adalah program komputer yang dirancang untuk membantu seseorang menemukan file-file yang disimpan dalam komputer, misalnya dalam sebuah server umum di web (WWW) atau dalam komputer sendiri.

Mesin pencari memungkinkan kita untuk meminta content media dengan kriteria yang spesifik (biasanya yang berisi kata atau frasa yang kita tentukan) dan memperoleh daftar file yang memenuhi kriteria tersebut. Mesin pencari biasanya menggunakan indeks (yang sudah dibuat sebelumnya dan dimutakhirkan secara teratur) untuk mencari file setelah pengguna memasukkan kriteria pencarian.

Dalam konteks Internet, mesin pencari biasanya merujuk kepada WWW dan bukan protokol ataupun area lainnya. Selain itu, mesin pencari mengumpulkan data yang tersedia di newsgroup, basis data besar, atau direktori terbuka seperti DMOZ.org. Karena pengumpulan datanya dilakukan secara otomatis, mesin pencari berbeda dengan direktori Web yang dikerjakan manusia.

Sebagian besar mesin pencari dijalankan oleh perusahaan swasta yang menggunakan algoritma kepemilikan dan basis data tertutup, yang paling populer adalah Google (MSN Search dan Yahoo! tertinggal sedikit di belakang). Telah ada beberapa upaya menciptakan mesin pencari dengan sumber terbuka, contohnya adalah Htdig, Nutch, Egothor dan OpenFTS.

## Penjelajah web

Penjelajah web (bahasa Inggris: Web browser ) adalah perangkat lunak yang berfungsi untuk menerima dan menyajikan sumber informasi di Internet. Sebuah sumber informasi diidentifikasi dengan Pengidentifikasi Sumber Seragam (bahasa Inggris: Uniform Resource Identifier ) yang dapat berupa halaman web, gambar, video, atau jenis konten lainnya.

Meskipun penjelajah web terutama ditujukan untuk mengakses Internet, sebuah penjelajah juga dapat digunakan untuk mengakses informasi yang disediakan oleh server web dalam jaringan pribadi atau berkas pada sistem berkas. Beberapa penjelajah web yang populer adalah Google Chrome, Firefox, Internet Explorer, Opera, dan Safari.

## Lihat pula

## Referensi

## Pranala luar