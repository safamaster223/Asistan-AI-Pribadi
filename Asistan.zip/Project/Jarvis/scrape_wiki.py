import asyncio
import argparse
import re
from urllib.parse import unquote
from playwright.async_api import async_playwright

def clean_markdown(text):
    """
    Regex Post-Processing untuk membersihkan artefak teks.
    """
    # Hapus artefak template Wikipedia (misal: "code: en is deprecated")
    text = re.sub(r'code:\s*[a-zA-Z-]+\s*is deprecated', '', text, flags=re.IGNORECASE)
    
    # Hapus sisa sitasi seperti [1], [2], [butuh rujukan], [pranala nonaktif permanen]
    text = re.sub(r'\[\d+\]', '', text)
    text = re.sub(r'\[butuh rujukan\]', '', text, flags=re.IGNORECASE)
    text = re.sub(r'\[pranala nonaktif permanen\]', '', text, flags=re.IGNORECASE)
    
    # Bersihkan spasi ganda dan spasi sebelum tanda baca
    text = re.sub(r' {2,}', ' ', text)
    text = re.sub(r' \.', '.', text)
    text = re.sub(r' ,', ',', text)
    
    # Pastikan maksimal hanya ada 2 baris kosong berurutan
    text = re.sub(r'\n{3,}', '\n\n', text)
    
    return text.strip()

async def scrape_article(url, output_file=None):
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )
        page = await context.new_page()
        
        try:
            # Navigasi cepat
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await page.wait_for_selector('#mw-content-text', state='visible')
            
            title = await page.locator('#firstHeading').inner_text()
            
            # In-Browser Evaluation dengan Table Parser
            markdown_content = await page.evaluate('''() => {
                const container = document.querySelector('#mw-content-text .mw-parser-output');
                if (!container) return "";

                const clone = container.cloneNode(true);

                // Hapus elemen non-konten
                const noiseSelectors = [
                    '.mw-editsection', '.navbox', '.reference', '#toc', 
                    '.mw-empty-elt', '.infobox', '.thumb', '.metadata', 
                    'style', 'script', '.reflist', '.portal', '.noprint'
                ];
                noiseSelectors.forEach(sel => {
                    clone.querySelectorAll(sel).forEach(el => el.remove());
                });

                let md = "";
                // Ambil elemen p, h2, h3, h4, dan tabel
                const elements = clone.querySelectorAll('p, h2, h3, h4, table.wikitable');
                
                elements.forEach(el => {
                    const tag = el.tagName.toLowerCase();
                    
                    if (tag === 'table') {
                        const rows = el.querySelectorAll('tr');
                        let tableMd = "\\n";
                        let isFirstRow = true;
                        
                        rows.forEach(row => {
                            const cells = row.querySelectorAll('th, td');
                            if (cells.length === 0) return;
                            
                            let rowMd = "|";
                            cells.forEach(cell => {
                                // Bersihkan newline di dalam sel tabel agar tidak merusak format Markdown
                                let cellText = cell.innerText.replace(/\\r?\\n/g, " ").trim();
                                rowMd += ` ${cellText} |`;
                            });
                            tableMd += rowMd + "\\n";
                            
                            // Tambahkan separator Markdown setelah baris header pertama
                            if (isFirstRow) {
                                let sepMd = "|";
                                cells.forEach(() => { sepMd += "---|"; });
                                tableMd += sepMd + "\\n";
                                isFirstRow = false;
                            }
                        });
                        md += tableMd + "\\n";
                    } else {
                        const text = el.innerText.trim();
                        if (!text) return;

                        if (tag === 'p') md += text + "\\n\\n";
                        else if (tag === 'h2') md += "## " + text + "\\n\\n";
                        else if (tag === 'h3') md += "### " + text + "\\n\\n";
                        else if (tag === 'h4') md += "#### " + text + "\\n\\n";
                    }
                });
                
                return md;
            }''')
            
            # Gabungkan judul dan konten
            final_content = f"# {title}\n\n{markdown_content}"
            
            # Terapkan Regex Post-Processing
            final_content = clean_markdown(final_content)
            
            # Tentukan nama file jika tidak diberikan
            if not output_file:
                safe_title = unquote(url.split('/')[-1]).replace('_', ' ')
                output_file = f"{safe_title}.md"
            
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(final_content)
                
            print(f"SUCCESS: Scraping selesai. Hasil disimpan di {output_file}")
            
        except Exception as e:
            print(f"ERROR: {e}")
        finally:
            await browser.close()

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Web Automation & Extraction Engine")
    parser.add_argument("url", help="Target URL to scrape")
    parser.add_argument("-o", "--output", help="Output Markdown file name", default=None)
    args = parser.parse_args()
    
    asyncio.run(scrape_article(args.url, args.output))
