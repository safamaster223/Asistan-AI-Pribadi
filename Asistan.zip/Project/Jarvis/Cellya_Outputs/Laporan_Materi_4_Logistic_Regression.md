# Analisis Mendalam Regresi Logistik dan Pengenalan CART (Classification and Regression Trees)
**Rangkuman Materi Ke-4: Pembelajaran Mesin**

---

## 1. Abstrak
Dokumen ini menyajikan analisis komprehensif mengenai dua algoritma fundamental dalam pembelajaran mesin: Regresi Logistik (*Logistic Regression*) dan pengenalan awal terhadap CART (*Classification and Regression Trees*). Fokus utama pada Regresi Logistik mencakup formulasi matematis model probabilitas, mekanisme pelatihan, evaluasi kinerja melalui *Confusion Matrix*, serta implementasi praktis menggunakan Scikit-Learn. Sementara itu, pembahasan CART menyoroti konsep dasar *Decision Tree* untuk klasifikasi multikelas, dengan penekanan pada metrik *Gini Impurity* dan *Gini Split* sebagai kriteria pemisahan (*split*), lengkap dengan formulasi matematis dan studi kasus perhitungannya. Analisis ini bertujuan untuk memberikan pemahaman teoretis dan praktis mengenai bagaimana model-model ini dilatih, dievaluasi, dan diimplementasikan.

## 2. Pendahuluan
Dalam domain pembelajaran mesin (*machine learning*) dan penambangan data, klasifikasi merupakan salah satu tugas prediktif yang paling krusial. Materi ke-4 ini membahas dua pendekatan yang berbeda namun sama-sama penting:
1.  **Regresi Logistik:** Model klasifikasi linier parametrik yang sangat ideal untuk klasifikasi biner (dua kelas) dengan memetakan output ke dalam probabilitas (0 hingga 1).
2.  **CART (Classification and Regression Trees):** Model non-parametrik berbasis pohon keputusan (*decision tree*) yang sangat intuitif dan mampu menangani klasifikasi multikelas secara langsung.

Pemahaman yang mendalam terhadap kedua arsitektur ini, mulai dari representasi matematis hingga metrik evaluasinya, sangat penting bagi praktisi *data science* untuk membangun model prediktif yang akurat dan dapat diandalkan.

## 3. Tinjauan Pustaka
Klasifikasi biner (*Binary Classification*) adalah proses memprediksi ke dalam salah satu dari dua kelas yang saling eksklusif. Dalam konteks ini, Regresi Logistik bertindak sebagai estimator probabilitas dengan mengasumsikan adanya hubungan linier antara variabel prediktor dengan *log-odds* dari peristiwa yang diprediksi. Fungsi aktivasi utamanya adalah fungsi Sigmoid.

Di sisi lain, algoritma berbasis pohon seperti CART menggunakan pendekatan *divide-and-conquer*. Model ini mempartisi ruang fitur secara rekursif berdasarkan aturan keputusan (*decision rules*) sederhana yang disimpulkan dari data fitur. Untuk menentukan pemisahan (*split*) terbaik pada setiap *node*, CART menggunakan metrik ketidakmurnian (*impurity*) seperti *Gini Impurity*.

## 4. Metodologi dan Model Matematis (Regresi Logistik)
Berdasarkan materi presentasi, model Regresi Logistik didefinisikan melalui persamaan matematis berikut:

$$f(x; w) = \frac{1}{1 + e^{-(w_0 + w_1x_1 + w_2x_2 + ... + w_dx_d)}}$$

Persamaan di atas merepresentasikan probabilitas (*prob.*) bahwa sebuah instans data $x$ termasuk dalam kelas positif. Komponen-komponen dalam persamaan tersebut meliputi:
- **$f(x; w)$**: Output probabilitas dari model.
- **$e$**: Bilangan Euler (konstanta matematika sekitar 2.71828).
- **$w_0$**: *Bias term* (intersep).
- **$w_1, w_2, ..., w_d$**: Nilai bobot (*weights value*) yang berkorespondensi dengan setiap fitur $x_1, x_2, ..., x_d$.

Kombinasi linier $(w_0 + w_1x_1 + ... + w_dx_d)$ sering disebut sebagai $z$. Fungsi sigmoid $\frac{1}{1 + e^{-z}}$ memastikan bahwa berapapun nilai $z$ (dari negatif tak hingga hingga positif tak hingga), outputnya akan selalu terkompresi dalam rentang (0, 1).

## 5. Pembahasan Detail: Pelatihan, Pengujian, dan Evaluasi Model
### 5.1. Hasil Pelatihan (Training) Regresi Logistik
Proses pelatihan (*training*) Regresi Logistik bertujuan untuk menemukan nilai bobot ($w$) yang optimal sehingga model dapat memprediksi probabilitas seakurat mungkin. Berdasarkan studi kasus pada materi presentasi, setelah melalui proses pelatihan, diperoleh nilai bobot sebagai berikut:
- **$w_0$ (Bias)** = -2
- **$w_1$ (Bobot fitur pertama)** = 1

Nilai-nilai ini menunjukkan bahwa model telah mempelajari pola dari data latih dan siap digunakan untuk melakukan prediksi pada data baru.

### 5.2. Pengujian (Testing) dan Prediksi Kelas
Tahap pengujian (*testing*) dilakukan untuk mengevaluasi kinerja model pada data yang belum pernah dilihat sebelumnya. Dalam studi kasus ini, kita diminta untuk memprediksi kelas untuk data baru dengan nilai fitur **$x = 2$**.

Mari kita substitusikan nilai-nilai yang diketahui ke dalam persamaan model:
1. Hitung kombinasi linier ($z$):
   $$z = w_0 + w_1x$$
   $$z = -2 + (1 \cdot 2)$$
   $$z = -2 + 2 = 0$$

2. Hitung probabilitas menggunakan fungsi sigmoid:
   $$f(x=2; w) = \frac{1}{1 + e^{-0}}$$
   $$f(x=2; w) = \frac{1}{1 + 1}$$
   $$f(x=2; w) = \frac{1}{2} = 0.5$$

**Interpretasi Hasil:**
Nilai probabilitas yang dihasilkan adalah 0.5 (atau 50%). Dalam klasifikasi biner standar, ambang batas (*threshold*) keputusan biasanya ditetapkan pada 0.5. 
- Jika probabilitas $\ge 0.5$, data diklasifikasikan ke kelas positif (misalnya, Kelas 1).
- Jika probabilitas $< 0.5$, data diklasifikasikan ke kelas negatif (misalnya, Kelas 0).

Karena probabilitas tepat berada di angka 0.5, keputusan klasifikasi akan bergantung pada aturan spesifik yang ditetapkan dalam sistem (misalnya, apakah 0.5 inklusif ke kelas positif atau negatif). Namun, secara umum, ini menunjukkan ketidakpastian maksimal dari model untuk titik data tersebut.

### 5.3. Evaluasi Model: Confusion Matrix dan Metrik Kinerja

> **[PLACEHOLDER GAMBAR: Masukkan Gambar Slide Confusion Matrix di sini]**

Setelah model melakukan prediksi, penting untuk mengevaluasi seberapa baik kinerjanya. Salah satu alat evaluasi yang paling umum digunakan untuk klasifikasi biner adalah **Confusion Matrix**. Matriks ini membandingkan nilai prediksi model dengan nilai target aktual.

Dalam klasifikasi biner, terdapat dua kelas: **Positif** dan **Negatif**. Confusion Matrix membagi hasil evaluasi menjadi empat komponen utama:

1.  **True Positive (TP):** Prediksi Positif, Aktual Positif (Benar).
2.  **True Negative (TN):** Prediksi Negatif, Aktual Negatif (Benar).
3.  **False Positive (FP):** Prediksi Positif, Aktual Negatif (Salah / Type I Error).
4.  **False Negative (FN):** Prediksi Negatif, Aktual Positif (Salah / Type II Error).

**Studi Kasus Perhitungan Confusion Matrix:**
Berdasarkan materi presentasi, diberikan deret data aktual (Target) dan tebakan model (Prediction) sebagai berikut:
*   **Target:** `[1, 1, 0, 1, 1, 0, 0, 0, 1, 0]`
*   **Prediction:** `[0, 1, 0, 1, 1, 1, 0, 1, 1, 0]`

Jika kita evaluasi satu per satu:
*   Data ke-1: Target 1, Prediksi 0 -> **FN**
*   Data ke-2: Target 1, Prediksi 1 -> **TP**
*   Data ke-3: Target 0, Prediksi 0 -> **TN**
*   Data ke-4: Target 1, Prediksi 1 -> **TP**
*   Data ke-5: Target 1, Prediksi 1 -> **TP**
*   Data ke-6: Target 0, Prediksi 1 -> **FP**
*   Data ke-7: Target 0, Prediksi 0 -> **TN**
*   Data ke-8: Target 0, Prediksi 1 -> **FP**
*   Data ke-9: Target 1, Prediksi 1 -> **TP**
*   Data ke-10: Target 0, Prediksi 0 -> **TN**

Total: **TP = 4, TN = 3, FP = 2, FN = 1**.

Berikut adalah representasi visual dari Confusion Matrix tersebut:

| | Prediksi: Negatif (0) | Prediksi: Positif (1) |
| :--- | :--- | :--- |
| **Target Aktual: Negatif (0)** | **TN = 3** | **FP = 2** |
| **Target Aktual: Positif (1)** | **FN = 1** | **TP = 4** |

**Perhitungan Metrik Kinerja:**
Dari nilai-nilai matriks di atas, kita dapat menghitung metrik kinerja model:

1.  **Precision (Presisi):** Mengukur seberapa akurat prediksi positif model.
    *   Rumus: $Precision = \frac{TP}{TP + FP}$
    *   Perhitungan: $Precision = \frac{4}{4 + 2} = \frac{4}{6} = 0.67$ (67%)
2.  **Recall (Sensitivitas):** Mengukur seberapa baik model mendeteksi kelas positif yang sebenarnya.
    *   Rumus: $Recall = \frac{TP}{TP + FN}$
    *   Perhitungan: $Recall = \frac{4}{4 + 1} = \frac{4}{5} = 0.80$ (80%)

### 5.4. Klasifikasi Multikelas (Multiclass Classification)
Meskipun Regresi Logistik pada dasarnya dirancang untuk klasifikasi biner, algoritma ini dapat diperluas untuk menangani masalah klasifikasi multikelas (lebih dari dua kelas). Dalam Scikit-Learn, hal ini diatur melalui parameter `multi_class`. Terdapat dua pendekatan utama:

1.  **'OvR' (One vs Rest):**
    *   Pendekatan ini memecah masalah multikelas menjadi beberapa masalah klasifikasi biner.
    *   Untuk setiap kelas, model akan dilatih untuk membedakan kelas tersebut dari *semua kelas lainnya* (digabungkan menjadi satu kelas "rest").
    *   **Contoh Kasus:** Misalkan kita memiliki 4 kelas: A, B, C, dan D. Pendekatan OvR akan membuat 4 model Regresi Logistik (LR) terpisah:
        *   LR 1: Memprediksi Kelas A vs (B, C, D) -> A / non-A
        *   LR 2: Memprediksi Kelas B vs (A, C, D) -> B / non-B
        *   LR 3: Memprediksi Kelas C vs (A, B, D) -> C / non-C
        *   LR 4: Memprediksi Kelas D vs (A, B, C) -> D / non-D
2.  **'multinomial':**
    *   Pendekatan ini menggunakan fungsi aktivasi **Softmax** (sebagai generalisasi dari fungsi sigmoid) pada lapisan *output*.
    *   Softmax akan menghitung probabilitas untuk setiap kelas secara bersamaan, dan memastikan total probabilitas dari semua kelas berjumlah 1. Kelas dengan probabilitas tertinggi akan dipilih sebagai prediksi akhir.

### 5.5. Implementasi Praktis dengan Scikit-Learn (Python)
Untuk mengaplikasikan teori Regresi Logistik ke dalam praktik, materi ini memperkenalkan penggunaan *library* Scikit-Learn (`sklearn`) dalam bahasa pemrograman Python. Berikut adalah sintaks dasar untuk mengimplementasikan model:

1.  **Mengimpor Paket Model:**
    ```python
    from sklearn.linear_model import LogisticRegression
    ```
2.  **Membuat Instansiasi Model:**
    ```python
    modelName = LogisticRegression()
    ```
3.  **Melatih Model (Training):**
    ```python
    modelName.fit(features, target)
    ```
    *Fungsi `fit` digunakan untuk melatih model dengan data fitur (`features`) dan label target (`target`).*
4.  **Mengekstrak Bobot Model yang Telah Dilatih:**
    ```python
    modelName.intercept_, modelName.coef_
    ```
    *`intercept_` mengembalikan nilai bias ($w_0$), sedangkan `coef_` mengembalikan nilai bobot fitur ($w_1, w_2, ...$).*
5.  **Melakukan Prediksi Kelas (Testing):**
    ```python
    modelName.predict(features)
    ```
    *Fungsi `predict` mengembalikan label kelas hasil prediksi (misalnya, 0 atau 1).*
6.  **Melakukan Prediksi Probabilitas (Testing):**
    ```python
    modelName.predict_proba(features)
    ```
    *Fungsi `predict_proba` mengembalikan nilai probabilitas untuk setiap kelas.*

## 6. Pengenalan CART (Classification and Regression Trees)
Selain Regresi Logistik, materi ini juga memperkenalkan algoritma **CART**. CART adalah algoritma *Supervised Learning* yang membangun model prediktif dalam bentuk struktur pohon (*tree*).

**Karakteristik Utama CART:**
1.  **Supervised Learning:** Membutuhkan data latih yang memiliki label target.
2.  **Multiclass Classification:** Secara alami mampu menangani klasifikasi dengan lebih dari dua kelas tanpa memerlukan modifikasi seperti OvR.

### 6.1. Konsep Inti: Gini Impurity dan Gini Split
Dalam membangun pohon keputusan, CART harus memutuskan fitur mana dan nilai berapa yang paling baik untuk memisahkan (*split*) data pada setiap *node* (simpul). Untuk mengukur kualitas pemisahan ini, CART menggunakan metrik yang disebut **Gini Impurity**.

**Formulasi Matematis Gini Impurity:**
Berdasarkan materi presentasi, Gini Impurity untuk suatu *node* $t$ dirumuskan sebagai:

$$Gini_t = \sum_{k=1}^{n} P_{t,k}(1 - P_{t,k})$$

Atau dalam bentuk yang lebih umum dan disederhanakan:

$$Gini_t = 1 - \sum_{k=1}^{n} (P_{t,k})^2$$

Di mana:
*   **$n$**: Jumlah total kelas (kategori) yang ada pada *node* tersebut.
*   **$P_{t,k}$**: Proporsi (probabilitas) sampel yang termasuk dalam kelas $k$ pada *node* $t$.

**Interpretasi Gini Impurity:**
*   Mengukur seberapa sering elemen yang dipilih secara acak dari himpunan akan salah dilabeli jika dilabeli secara acak sesuai dengan distribusi label dalam himpunan tersebut.
*   Nilai Gini Impurity berkisar dari **0** (murni sempurna, semua sampel di *node* tersebut berasal dari kelas yang sama) hingga **0.5** (ketidakmurnian maksimal untuk klasifikasi biner, di mana proporsi kelas seimbang 50:50).

**Formulasi Matematis Gini Split:**
Setelah mengetahui Gini Impurity dari *node* induk (sebelum dipisah) dan *node* anak (setelah dipisah), algoritma akan menghitung **Gini Split** untuk mengevaluasi kualitas pemisahan tersebut. Rumusnya adalah:

$$Gini(s, t) = Gini(t) - P_L Gini(t_L) - P_R Gini(t_R)$$

Di mana:
*   **$Gini(s, t)$**: Nilai Gini Split (penurunan ketidakmurnian) dari pemisahan $s$ pada *node* $t$.
*   **$Gini(t)$**: Gini Impurity dari *node* induk (sebelum dipisah).
*   **$P_L$**: Proporsi sampel yang masuk ke *node* anak kiri ($t_L$).
*   **$Gini(t_L)$**: Gini Impurity dari *node* anak kiri.
*   **$P_R$**: Proporsi sampel yang masuk ke *node* anak kanan ($t_R$).
*   **$Gini(t_R)$**: Gini Impurity dari *node* anak kanan.

Algoritma CART akan mengevaluasi berbagai kemungkinan pemisahan dan memilih pemisahan yang menghasilkan nilai **Gini Split terbesar** (penurunan ketidakmurnian paling signifikan).

### 6.2. Studi Kasus Perhitungan Gini Impurity

> **[PLACEHOLDER GAMBAR: Masukkan Gambar Slide Gini Impurity Box A & Box B di sini]**

Untuk memahami cara kerja rumus Gini Impurity, mari kita analisis dua skenario (Box a dan Box b) yang merepresentasikan dua *node* yang berbeda:

**Skenario 1: Box a (Node Campuran)**
Misalkan sebuah *node* (Box a) berisi 4 item: 3 Segitiga Biru dan 1 Lingkaran Ungu.
*   Probabilitas Segitiga ($P_{segitiga}$) = 3/4 = 0.75
*   Probabilitas Lingkaran ($P_{lingkaran}$) = 1/4 = 0.25
*   Perhitungan Gini:
    $$Gini_a = 1 - ((0.75)^2 + (0.25)^2)$$
    $$Gini_a = 1 - (0.5625 + 0.0625)$$
    $$Gini_a = 1 - 0.625 = \mathbf{0.375}$$
*   *Interpretasi:* Nilai 0.375 menunjukkan bahwa *node* ini tidak murni (campur aduk).

**Skenario 2: Box b (Node Murni)**
Misalkan sebuah *node* (Box b) berisi 5 item, dan semuanya adalah Lingkaran Ungu.
*   Probabilitas Lingkaran ($P_{lingkaran}$) = 5/5 = 1.0
*   Perhitungan Gini:
    $$Gini_b = 1 - (1.0)^2$$
    $$Gini_b = 1 - 1 = \mathbf{0}$$
*   *Interpretasi:* Nilai 0 menunjukkan bahwa *node* ini murni sempurna.

Dari perbandingan di atas, **Box a memiliki nilai Gini Impurity yang lebih besar** dibandingkan Box b.

### 6.3. Studi Kasus: Iris Classification

> **[PLACEHOLDER GAMBAR: Masukkan Gambar Slide Decision Tree Iris di sini]**

Slide presentasi menunjukkan contoh visualisasi pohon keputusan untuk dataset Iris (klasifikasi spesies bunga).
*   **Root Node:** Pemisahan pertama dilakukan berdasarkan fitur `sepal length (cm) <= 5.45`.
*   **Leaf Node (Murni):** Jika kondisi tersebut `True`, data masuk ke *node* anak sebelah kiri. Pada *node* ini, nilai `gini = 0.0`, yang berarti *node* ini murni sempurna. Terdapat 2 sampel (`samples = 2`), dan keduanya berasal dari kelas `setosa` (`value = [2, 0, 0]`).
*   **Node Lanjutan:** Jika kondisi `False`, data masuk ke *node* kanan yang masih memiliki ketidakmurnian (`gini = 0.5`). *Node* ini kemudian akan dipisahkan lagi berdasarkan fitur lain (misalnya `sepal length (cm) <= 6.35`) hingga mencapai *leaf node* yang murni atau memenuhi kriteria penghentian lainnya.

### 6.4. Latihan Perhitungan CART (Iris Dataset)
Sebagai latihan, materi ini meminta untuk menghitung *Gini Split*, *Gini Impurity Left*, dan *Gini Impurity Right* untuk algoritma CART dengan kedalaman (*depth*) = 2. Data yang digunakan adalah 6 data pertama (dua data pertama dari masing-masing kelas) dari dataset Iris, dengan fokus pada fitur `petal width`.

*(Catatan: Perhitungan detail untuk latihan ini memerlukan data aktual dari dataset Iris yang disebutkan).*

## 7. Kesimpulan
Materi ke-4 memberikan landasan yang kuat mengenai dua algoritma klasifikasi esensial. Regresi Logistik menawarkan pendekatan probabilistik linier yang sangat efisien untuk klasifikasi biner, didukung oleh metrik evaluasi komprehensif seperti *Confusion Matrix*, *Precision*, dan *Recall*. Di sisi lain, pengenalan CART membuka wawasan terhadap model non-parametrik berbasis pohon yang intuitif dan secara alami mendukung klasifikasi multikelas. Pemahaman terhadap kriteria pemisahan seperti *Gini Impurity* dan *Gini Split* (beserta formulasi matematisnya) pada CART sangat penting untuk menginterpretasikan bagaimana model mengambil keputusan. Penguasaan kedua algoritma ini, beserta implementasinya menggunakan Scikit-Learn, merupakan kompetensi wajib bagi praktisi *data science*.

## 8. Daftar Pustaka
1. Bishop, C. M. (2006). *Pattern Recognition and Machine Learning*. Springer.
2. Hastie, T., Tibshirani, R., & Friedman, J. (2009). *The Elements of Statistical Learning: Data Mining, Inference, and Prediction*. Springer Science & Business Media.
3. Goodfellow, I., Bengio, Y., & Courville, A. (2016). *Deep Learning*. MIT Press.
4. Breiman, L., Friedman, J., Stone, C. J., & Olshen, R. A. (1984). *Classification and Regression Trees*. CRC press.