# Laporan Analisis Statistik Fitur Data
**Pemrosesan Data Time Series Polutan menggunakan KNIME dan PostgreSQL**

---

## Bab 1: Pendahuluan
Laporan ini disusun untuk memenuhi tugas mata kuliah terkait pemrosesan data dan analisis statistik menggunakan platform KNIME Analytics dan basis data PostgreSQL (Aiven). Alur kerja (*workflow*) yang dibangun mencakup proses migrasi data *time series* polutan dari format CSV ke dalam basis data PostgreSQL, dilanjutkan dengan penarikan kembali data (*data retrieval*) ke dalam KNIME untuk dilakukan komputasi statistik deskriptif.

Fokus utama dari dokumen ini adalah menjabarkan secara matematis dan konseptual setiap fitur yang dihasilkan oleh node **Statistics** pada KNIME. Pemahaman mendalam terhadap metrik statistik ini sangat krusial dalam menganalisis karakteristik, sebaran, dan anomali pada data *time series* polutan.

---

## Bab 2: Arsitektur Aliran Data (Data Pipeline)
Berdasarkan gambar arsitektur KNIME yang Anda berikan, proses saat ini baru menyelesaikan tahap **Push Data** (memasukkan data ke database melalui `DB Row Inserter`). 

Untuk memenuhi instruksi tugas *"Tarik data ke KNIME"* dan *"Jadikan Statistic"*, Anda **wajib menambahkan tiga node esensial berikut** setelah node `PostgreSQL Connector`:

1. **DB Table Selector:** Node ini dihubungkan ke `PostgreSQL Connector` untuk memilih tabel spesifik di dalam database Aiven yang menyimpan data polutan Anda.
2. **DB Reader:** Node ini mengeksekusi *query* dari `Table Selector` dan menarik (*pull*) data dari server PostgreSQL kembali ke memori lokal KNIME dalam bentuk *Data Table*.
3. **Statistics:** Node ini dihubungkan ke *output* `DB Reader` untuk menghitung seluruh metrik statistik deskriptif dari setiap kolom fitur polutan.

---

## Bab 3: Penjelasan Fitur Statistik, Rumus, dan Contoh Perhitungan
Node **Statistics** pada KNIME menghasilkan berbagai metrik deskriptif. Berikut adalah penjelasan, rumus matematis, dan contoh perhitungan untuk setiap fitur. 

Untuk mempermudah pemahaman contoh perhitungan, kita akan menggunakan sampel data (X) konsentrasi polutan PM2.5 harian (dalam µg/m³) selama 5 hari: 
**X = [10, 12, 15, 15, 18]**
Jumlah data (n) = 5.

### 3.1 Minimum (Min) & Maximum (Max)
**Penjelasan:** Nilai terkecil (Minimum) dan terbesar (Maximum) dalam suatu himpunan data. Metrik ini berguna untuk mengetahui rentang (*range*) ekstrem dari data polutan.

**Rumus:**
*   Min = min(x₁, x₂, ..., xₙ)
*   Max = max(x₁, x₂, ..., xₙ)

**Contoh Perhitungan:**
Dari data X = [10, 12, 15, 15, 18]
*   Min = 10
*   Max = 18

### 3.2 Mean (Rata-rata)
**Penjelasan:** Rata-rata aritmatika dari seluruh nilai dalam himpunan data. Mean menunjukkan titik pusat gravitasi dari distribusi data.

**Rumus:**
μ = (Σ xᵢ) / n
*(Dimana Σ xᵢ adalah total jumlah data, dan n adalah banyaknya data)*

**Contoh Perhitungan:**
μ = (10 + 12 + 15 + 15 + 18) / 5
μ = 70 / 5 = 14
Jadi, rata-rata konsentrasi PM2.5 adalah **14 µg/m³**.

### 3.3 Median (Nilai Tengah)
**Penjelasan:** Nilai tengah dari himpunan data yang telah diurutkan dari terkecil hingga terbesar. Median lebih kebal terhadap nilai ekstrem (*outlier*) dibandingkan Mean.

**Rumus:**
*   Jika n ganjil: Nilai pada posisi ke-(n+1)/2
*   Jika n genap: Rata-rata dari dua nilai di tengah.

**Contoh Perhitungan:**
Data terurut: 10, 12, 15, 15, 18 (n=5, ganjil)
Posisi median = (5+1)/2 = 3.
Nilai pada posisi ke-3 adalah 15.
Jadi, Median = **15**.

### 3.4 Variance (Varians)
**Penjelasan:** Varians mengukur seberapa jauh data tersebar dari nilai rata-ratanya. KNIME menggunakan rumus Varians Sampel (*Sample Variance*).

**Rumus:**
s² = Σ (xᵢ - μ)² / (n - 1)

**Contoh Perhitungan:**
s² = [ (10-14)² + (12-14)² + (15-14)² + (15-14)² + (18-14)² ] / (5 - 1)
s² = [ (-4)² + (-2)² + (1)² + (1)² + (4)² ] / 4
s² = [ 16 + 4 + 1 + 1 + 16 ] / 4
s² = 38 / 4 = **9.5**

### 3.5 Standard Deviation (Standar Deviasi)
**Penjelasan:** Akar kuadrat dari varians. Standar deviasi menunjukkan rata-rata penyimpangan setiap titik data dari nilai Mean. Semakin besar nilainya, semakin fluktuatif data polutan tersebut.

**Rumus:**
s = √(s²)

**Contoh Perhitungan:**
s = √(9.5) ≈ **3.08**
Jadi, standar deviasi data adalah 3.08.

### 3.6 Skewness (Kemencengan)
**Penjelasan:** Skewness mengukur tingkat ketidaksimetrisan (kemencengan) distribusi data terhadap rata-ratanya. 
*   Nilai = 0: Distribusi simetris sempurna (Normal).
*   Nilai > 0: Menceng ke kanan (*Right-skewed* / ekor panjang di kanan).
*   Nilai < 0: Menceng ke kiri (*Left-skewed* / ekor panjang di kiri).

**Rumus (Sample Skewness):**
Skewness = [ n / ((n-1)(n-2)) ] * Σ [ (xᵢ - μ) / s ]³

**Contoh Perhitungan Konseptual:**
Karena data kita memiliki Mean (14) yang lebih kecil dari Median (15), ekor distribusi sedikit memanjang ke kiri (nilai 10 dan 12 menarik rata-rata ke bawah). Hasil perhitungan matematis akan menghasilkan nilai Skewness negatif yang kecil (mendekati 0), menunjukkan data sedikit menceng ke kiri namun hampir simetris.

### 3.7 Kurtosis (Keruncingan)
**Penjelasan:** Kurtosis mengukur 'keruncingan' distribusi data, atau seberapa banyak data yang berada di bagian ekor (*outliers*) dibandingkan dengan distribusi normal. KNIME menggunakan *Excess Kurtosis*.
*   Kurtosis = 0: Distribusi normal (*Mesokurtik*).
*   Kurtosis > 0: Puncak tajam, banyak outlier (*Leptokurtik*).
*   Kurtosis < 0: Puncak datar, sedikit outlier (*Platikurtik*).

**Rumus (Sample Excess Kurtosis):**
Kurtosis = { [ n(n+1) / ((n-1)(n-2)(n-3)) ] * Σ [ (xᵢ - μ) / s ]⁴ } - [ 3(n-1)² / ((n-2)(n-3)) ]

**Contoh Perhitungan Konseptual:**
Jika data polutan memiliki lonjakan ekstrem yang tiba-tiba (misalnya tiba-tiba bernilai 150 µg/m³ karena kebakaran), nilai Kurtosis akan bernilai positif tinggi. Pada sampel data kita yang stabil, nilai kurtosis akan cenderung negatif (*Platikurtik*).