# Laporan Komprehensif Pembelajaran Mesin: Analisis Mendalam Algoritma Regresi Linear Univariat

**Disusun oleh:** Cellya Claire

---

## Abstrak
Laporan ini menyajikan analisis komprehensif mengenai algoritma Regresi Linear Univariat, sebuah fondasi utama dalam ranah *supervised learning*. Pembahasan mencakup transisi konseptual dari representasi data dasar hingga formulasi matematis yang mendasarinya, termasuk pendekatan analitik (*Direct Equation*) dan pendekatan optimasi iteratif (*Stochastic Gradient Descent*). Selain itu, laporan ini mengevaluasi metrik kinerja model, khususnya *Mean Squared Error* (MSE) dan *R-Squared*, serta menguraikan alur kerja implementasi praktis menggunakan pustaka `scikit-learn` pada bahasa pemrograman Python. Tujuan utama dari dokumen ini adalah untuk memberikan pemahaman teoritis yang mendalam sekaligus panduan praktis yang dapat diaplikasikan secara langsung dalam pemodelan prediktif.

---

## 1. Pendahuluan
Pembelajaran Mesin (*Machine Learning*) telah menjadi pilar utama dalam analisis data modern, memungkinkan sistem komputasi untuk mengenali pola dan membuat keputusan berdasarkan data historis tanpa diprogram secara eksplisit. Dalam paradigma *supervised learning*, algoritma dilatih menggunakan dataset yang telah memiliki label kebenaran (*ground truth*). Salah satu algoritma paling fundamental dan banyak digunakan dalam kategori ini adalah Regresi Linear. Berbeda dengan algoritma klasifikasi yang memprediksi kategori diskrit, regresi dirancang khusus untuk memprediksi nilai kontinu, menjadikannya instrumen yang ideal untuk peramalan ekonomi, analisis tren, dan estimasi nilai.

Dalam laporan ini, studi kasus yang diangkat sebagai jangkar pemahaman adalah prediksi harga rumah (*House Price Prediction*). Kasus ini merepresentasikan masalah regresi univariat klasik di mana kita berusaha memahami hubungan antara satu variabel independen (fitur), seperti luas bangunan, terhadap satu variabel dependen (target), yaitu harga rumah. Pemahaman yang solid terhadap model univariat ini sangat krusial, karena prinsip-prinsip matematis dan optimasi yang mendasarinya akan terus digunakan dan diskalakan pada model regresi multivariat maupun arsitektur jaringan saraf tiruan (*neural networks*) yang lebih kompleks.

Tujuan utama dari pemodelan Regresi Linear adalah untuk menemukan sebuah garis lurus imajiner—sering disebut sebagai *Line of Best Fit*—yang paling optimal dalam merepresentasikan sebaran titik-titik data observasi. Garis ini tidak ditarik secara acak, melainkan dihitung secara presisi menggunakan landasan kalkulus dan statistika untuk memastikan bahwa jarak antara prediksi model dan kenyataan (*error*) berada pada titik seminimal mungkin. Laporan ini akan membedah secara rinci bagaimana garis tersebut ditemukan, dievaluasi, dan diimplementasikan.

---

## 2. Tinjauan Pustaka dan Terminologi
Dalam menjembatani teori statistika klasik dengan praktik *Machine Learning* modern, pemahaman terminologi yang tepat sangatlah esensial. Model Regresi Linear direpresentasikan oleh persamaan matematis $y = w_0 + w_1x$. Dalam konteks *Machine Learning*, variabel-variabel ini memiliki makna spesifik yang membedakannya dari sekadar variabel aljabar biasa. Variabel $x$ merepresentasikan Fitur (*Feature*), yaitu atribut input yang digunakan model untuk belajar, sementara $y$ adalah Target (*Label*), yaitu nilai kontinu yang ingin diprediksi.

Parameter internal yang mendefinisikan karakteristik model disebut sebagai Bobot (*Weights*). Parameter $w_0$ dikenal sebagai Bias (atau *Intercept* dalam statistika), yang menentukan nilai dasar prediksi ketika semua fitur bernilai nol. Sementara itu, $w_1$ adalah Koefisien (*Coefficient*), yang menentukan tingkat kemiringan garis dan seberapa besar pengaruh fitur terhadap target. Proses penyesuaian nilai $w_0$ dan $w_1$ inilah yang secara esensial disebut sebagai proses "belajar" (*training*) pada mesin.

Lebih lanjut, siklus hidup pengembangan model dibagi menjadi dua fase utama: Fase *Training* dan Fase *Testing*. Pada Fase *Training*, model diberikan akses ke data historis di mana nilai fitur ($x$) dan target aktual ($y$) sudah diketahui. Model menggunakan data ini untuk menyesuaikan bobotnya. Sebaliknya, pada Fase *Testing* (atau *Inference*), model dihadapkan pada data fitur ($x$) baru yang belum pernah dilihat sebelumnya. Pada fase ini, nilai target aktual disembunyikan, dan model harus menghasilkan nilai prediksi ($\hat{y}$) berdasarkan bobot yang telah dipelajarinya. Pemisahan fase ini sangat penting untuk menguji kemampuan generalisasi model terhadap data dunia nyata.

---

## 3. Metodologi Pemodelan dan Optimasi
Untuk menemukan *Line of Best Fit*, terdapat dua metodologi utama yang dapat digunakan: Pendekatan Analitik dan Pendekatan Iteratif. Pendekatan Analitik, atau yang sering disebut sebagai *Direct Equation* (*Closed-form solution*), menggunakan rumus statistika deskriptif untuk menghitung parameter secara langsung. Nilai koefisien ($w_1$) didapatkan dengan membagi Kovariansi antara fitur dan target dengan Variansi dari fitur tersebut. Setelah $w_1$ ditemukan, nilai Bias ($w_0$) dapat dihitung dengan mensubstitusikan nilai rata-rata fitur dan target. Pendekatan ini sangat efisien dan memberikan hasil yang pasti (*exact*) untuk dataset berdimensi kecil, namun komputasinya menjadi sangat berat dan tidak efisien ketika dihadapkan pada dataset berukuran masif dengan jutaan fitur.

Oleh karena itu, untuk skala industri, digunakan Pendekatan Iteratif melalui algoritma optimasi seperti *Stochastic Gradient Descent* (SGD). SGD tidak mencari jawaban pasti secara langsung, melainkan memulai dengan tebakan acak (biasanya $w_0$ dan $w_1$ diinisialisasi dengan nilai nol) dan secara bertahap memperbaiki tebakan tersebut. Algoritma ini memanfaatkan prinsip Kalkulus, khususnya Turunan Parsial (*Partial Derivatives*), untuk menghitung gradien dari fungsi kesalahan (*Cost Function*). Gradien ini bertindak sebagai "kompas" yang menunjukkan arah di mana kesalahan model akan menurun.

Aturan pembaruan bobot pada SGD dirumuskan sebagai $w_{baru} = w_{lama} - (\eta \times \text{Gradien})$. *Learning Rate* ($\eta$) adalah *hyperparameter* krusial yang menentukan seberapa besar langkah yang diambil model pada setiap iterasi (*epoch*). Jika *Learning Rate* terlalu besar, model mungkin melompati titik minimum yang optimal; sebaliknya, jika terlalu kecil, proses konvergensi akan memakan waktu komputasi yang sangat lama. Sifat "Stochastic" pada SGD berarti pembaruan bobot dilakukan satu per satu untuk setiap titik data, membuat pergerakannya sedikit fluktuatif namun secara komputasional jauh lebih cepat dan hemat memori dibandingkan memproses seluruh dataset sekaligus (*Batch Gradient Descent*).

---

## 4. Pembahasan Detail: Evaluasi dan Implementasi
Setelah model menghasilkan prediksi, langkah krusial berikutnya adalah mengevaluasi seberapa akurat prediksi tersebut. Menjumlahkan selisih mentah (*residual*) antara nilai prediksi dan aktual bukanlah metode yang valid, karena *error* positif (prediksi terlalu tinggi) dan *error* negatif (prediksi terlalu rendah) akan saling meniadakan, memberikan ilusi bahwa model berkinerja sempurna. Untuk mengatasi hal ini, standar industri menggunakan *Mean Squared Error* (MSE). MSE mengkuadratkan setiap nilai *error* sebelum merata-ratakannya, sehingga memberikan penalti yang jauh lebih besar pada kesalahan prediksi yang ekstrem dan memastikan semua nilai *error* terakumulasi secara positif. Tujuan utama dari algoritma seperti SGD adalah meminimalkan nilai MSE ini hingga mendekati nol.

Selain MSE yang memberikan nilai absolut, evaluasi juga membutuhkan metrik relatif seperti *R-Squared* (Koefisien Determinasi). *R-Squared* membandingkan variansi residual model dengan variansi total data. Nilai *R-Squared* berkisar antara 0 hingga 1, di mana nilai yang mendekati 1 mengindikasikan bahwa model sangat cocok dengan data dan variasi pada target dapat dijelaskan dengan sangat baik oleh fitur yang ada. Kombinasi MSE dan *R-Squared* memberikan gambaran komprehensif mengenai kinerja model dari segi presisi absolut dan kecocokan relatif.

Dalam ranah implementasi praktis, kerumitan kalkulus dan iterasi matematis ini telah diabstraksi dengan sangat elegan oleh pustaka Python seperti `scikit-learn`. Alur kerja implementasi direduksi menjadi proses yang sangat terstruktur:

| Tahapan Implementasi | Perintah Python (`scikit-learn`) | Deskripsi Proses |
| :--- | :--- | :--- |
| **1. Inisialisasi** | `model = LinearRegression()` | Membuat instansiasi objek model regresi yang masih kosong. |
| **2. Pelatihan (Training)** | `model.fit(X_train, y_train)` | Model mempelajari pola data dan mencari bobot optimal ($w_0, w_1$) untuk meminimalkan MSE. |
| **3. Pengujian (Inference)** | `prediksi = model.predict(X_test)` | Model menggunakan bobot yang telah dipelajari untuk menebak target dari data baru. |

Abstraksi ini memungkinkan para insinyur data dan ilmuwan data untuk fokus pada rekayasa fitur (*feature engineering*) dan analisis bisnis, alih-alih menulis ulang algoritma optimasi dari awal.

---

## 5. Kesimpulan
Regresi Linear Univariat, meskipun sederhana secara konseptual, merupakan fondasi matematis yang sangat kuat dalam *Machine Learning*. Melalui analisis yang mendalam, dapat disimpulkan bahwa efektivitas model ini tidak hanya bergantung pada ketersediaan data yang berkualitas, tetapi juga pada pemahaman yang tepat mengenai fungsi optimasi (seperti minimasi MSE melalui *Stochastic Gradient Descent*) dan metrik evaluasi yang digunakan. Transisi dari perhitungan analitik manual menuju implementasi komputasional menggunakan pustaka modern seperti `scikit-learn` membuktikan bahwa kompleksitas matematis dapat diabstraksi menjadi alur kerja yang efisien, terukur, dan siap digunakan untuk memecahkan masalah prediktif di dunia nyata. Pemahaman yang kokoh pada model univariat ini adalah prasyarat mutlak sebelum melangkah ke arsitektur pemodelan data yang lebih kompleks.

---

## Daftar Pustaka
1. Hastie, T., Tibshirani, R., & Friedman, J. (2009). *The Elements of Statistical Learning: Data Mining, Inference, and Prediction*. Springer Science & Business Media.
2. Pedregosa, F., et al. (2011). *Scikit-learn: Machine Learning in Python*. Journal of Machine Learning Research, 12, 2825-2830.
3. Goodfellow, I., Bengio, Y., & Courville, A. (2016). *Deep Learning*. MIT Press. (Bab 5: Machine Learning Basics).