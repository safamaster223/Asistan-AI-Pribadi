# Laporan Tinjauan Literatur: Efektivitas dan Komparasi Algoritma Optimasi Rute pada Masalah Distribusi Logistik
**Analisis Kritis Pendekatan Heuristik, Metaheuristik, dan Exact Algorithm**

---

## BAB 1: PENDAHULUAN
Manajemen rantai pasok (*supply chain management*) modern menempatkan efisiensi distribusi logistik sebagai salah satu pilar utama penentu daya saing industri berskala global maupun nasional. Inti dari permasalahan distribusi ini secara matematis dimodelkan sebagai *Vehicle Routing Problem* (VRP), sebuah perluasan kompleks dari *Traveling Salesman Problem* (TSP). VRP bertujuan untuk merancang rute paling optimal bagi sekumpulan armada kendaraan dengan kapasitas tertentu yang harus melayani sejumlah titik permintaan (pelanggan) yang tersebar secara geografis. 

Kompleksitas VRP tergolong dalam kelas *NP-Hard* (*Non-deterministic Polynomial-time Hard*). Hal ini berarti tingkat kesulitan komputasionalnya akan meningkat secara eksponensial (faktorial) seiring dengan bertambahnya jumlah titik tujuan (*nodes*). Oleh karena itu, penyelesaian VRP tidak hanya membutuhkan pemodelan matematis yang presisi, tetapi juga pendekatan algoritmik tingkat tinggi yang mampu menyeimbangkan antara kualitas solusi (jarak terpendek/biaya termurah) dan waktu komputasi yang realistis.

Urgensi pemilihan algoritma komputasi yang tepat menjadi sangat krusial ketika dihadapkan pada skala operasional dunia nyata. Pemilihan algoritma yang suboptimal dapat mengakibatkan pembengkakan biaya operasional, peningkatan konsumsi bahan bakar, serta keterlambatan waktu pengiriman yang berdampak langsung pada penurunan tingkat kepuasan pelanggan. Di sisi lain, penggunaan algoritma pencarian solusi mutlak (*exact algorithm*) pada skala data yang masif sering kali tidak aplikatif karena keterbatasan sumber daya komputasi dan memori. Hal ini memicu perkembangan berbagai varian algoritma, mulai dari heuristik sederhana hingga metaheuristik kompleks, yang masing-masing menawarkan karakteristik penyelesaian yang berbeda.

Tinjauan literatur ini bertujuan untuk mengevaluasi efektivitas dan melakukan komparasi kritis terhadap berbagai algoritma optimasi rute pada masalah distribusi logistik. Dengan menganalisis tiga studi literatur terkini yang mewakili pendekatan heuristik, metaheuristik, dan algoritma eksak, laporan ini akan membedah keunggulan, kelemahan inheren, serta akar penyebab dari limitasi masing-masing metode. Hasil dari tinjauan ini diharapkan dapat memetakan posisi *state-of-the-art* dari riset optimasi rute saat ini dan mengidentifikasi celah penelitian (*research gap*) yang potensial untuk dieksplorasi lebih lanjut guna pengembangan sistem logistik cerdas.

---

## BAB 2: METODOLOGI SCREENING DAN REPROCESSING LITERATUR
Untuk memastikan validitas dan reliabilitas komparasi dalam laporan ini, tinjauan literatur dilakukan melalui tahapan metodologi yang ketat, mencakup proses *screening* (penyaringan) dan *reprocessing* (pemrosesan ulang) data dari studi-studi terdahulu.

### 2.1 Tahapan Screening Literatur
Proses *screening* dilakukan untuk menyaring literatur yang paling relevan dan representatif terhadap perkembangan algoritma VRP. Kriteria inklusi yang diterapkan mencakup: (1) Studi diterbitkan dalam rentang waktu terbaru (2023-2024) untuk menjamin relevansi teknologi; (2) Fokus utama pada penyelesaian *Vehicle Routing Problem* (VRP) atau *Capacitated VRP* (CVRP); (3) Menyajikan metrik evaluasi yang jelas secara kuantitatif, seperti waktu komputasi (*CPU time*), jarak tempuh, dan jumlah iterasi. Literatur yang hanya membahas teori matematis tanpa simulasi empiris pada dataset logistik dieksklusi dari tinjauan ini. Melalui proses *screening* ini, terpilih tiga studi utama yang mewakili tiga paradigma komputasi berbeda: Heuristik, Metaheuristik, dan *Exact Algorithm*.

### 2.2 Tahapan Reprocessing dan Ekstraksi Data
Data mentah yang disajikan oleh ketiga studi utama tidak selalu menggunakan satuan, skala, atau parameter lingkungan pengujian yang identik. Oleh karena itu, dilakukan tahap *reprocessing* (pemrosesan ulang) informasi. Parameter seperti waktu eksekusi, kompleksitas ruang (penggunaan memori), dan persentase penghematan jarak diekstrak dan distandardisasi ke dalam matriks komparasi konseptual. *Reprocessing* ini sangat krusial untuk memungkinkan perbandingan yang '*apple-to-apple*' antara algoritma *Greedy* (Studi 1), *Simulated Annealing* (Studi 2), dan *Branch & Bound* (Studi 3), meskipun ketiganya diuji pada skala *nodes* yang berbeda (15, 40, dan 50 titik). Dengan *reprocessing* ini, kelemahan algoritmik dapat diisolasi dari faktor eksternal seperti spesifikasi perangkat keras yang digunakan oleh masing-masing peneliti.

---

## BAB 3: TINJAUAN DAN ANALISIS KOMPARATIF

### 3.1 Analisis Pendekatan Heuristik Sederhana (Pratama & Lestari, 2023)
Studi yang dilakukan oleh Pratama dan Lestari (2023) mengeksplorasi penggunaan pendekatan heuristik sederhana, secara spesifik algoritma *Greedy* atau *Nearest Neighbor*, dalam menyelesaikan masalah rute armada tunggal. Tujuan utama dari penelitian ini adalah untuk menilai kecepatan pembentukan rute dan tingkat penghematan jarak awal pada skala distribusi kecil yang melibatkan 15 titik tujuan. Temuan studi menunjukkan bahwa algoritma ini mampu menghasilkan rute dalam waktu komputasi yang sangat singkat (hampir seketika), menjadikannya sangat responsif untuk kebutuhan operasional yang mendesak.

Namun demikian, analisis kritis terhadap studi ini mengungkap kelemahan fundamental dari pendekatan heuristik murni. Algoritma ini terbukti sering terjebak pada *local optimum*, di mana jarak rute akhir yang dihasilkan sering kali suboptimal, terutama ketika titik-titik distribusi tersebar secara acak dan tidak terstruktur. Penyebab utama dari kelemahan ini terletak pada logika *Greedy* itu sendiri, yang secara eksklusif mengambil keputusan terbaik jangka pendek (memilih titik terdekat berikutnya) tanpa mempertimbangkan topologi rute secara global. Ketiadaan mekanisme evaluasi mundur (*backtracking*) membuat kesalahan pemilihan rute di awal iterasi terakumulasi menjadi inefisiensi jarak yang masif di akhir rute.

### 3.2 Analisis Pendekatan Metaheuristik (Wijaya, Nugroho, & Hidayat, 2024)
Beranjak pada skala permasalahan yang lebih kompleks, Wijaya, Nugroho, dan Hidayat (2024) mengimplementasikan pendekatan metaheuristik berbasis *Simulated Annealing* (SA) untuk menyelesaikan *Capacitated Vehicle Routing Problem* (CVRP) dengan 40 titik distribusi. Tujuan dari studi ini adalah untuk meminimalkan jarak tempuh total sekaligus menekan konsumsi bahan bakar dengan mempertimbangkan batasan kapasitas muatan kendaraan. Hasil penelitian mengindikasikan bahwa SA mampu melampaui jebakan *local optimum* yang dialami oleh algoritma heuristik, menghasilkan rute global yang jauh lebih efisien dan mendekati optimal.

Meskipun kualitas solusi yang dihasilkan sangat superior, pendekatan ini memiliki kelemahan signifikan pada aspek efisiensi komputasional. Waktu eksekusi komputasi yang dibutuhkan tergolong lama, dan hasil akhir yang diberikan bersifat non-deterministik (berbeda-beda pada setiap kali eksekusi). Akar penyebab dari fenomena ini adalah mekanisme eksplorasi ruang solusi (*search space*) yang bersifat stokastik atau acak. Selain itu, kinerja algoritma ini memiliki sensitivitas yang sangat tinggi terhadap *parameter tuning*, khususnya pada pengaturan *cooling schedule* (laju penurunan suhu). Penurunan suhu yang terlalu cepat akan mengembalikan algoritma pada sifat *Greedy*, sedangkan penurunan yang terlalu lambat akan membuang sumber daya komputasi secara sia-sia.

### 3.3 Analisis Komparasi Exact vs Metaheuristik (Ramadhan & Santoso, 2023)
Studi ketiga oleh Ramadhan dan Santoso (2023) menyajikan komparasi langsung antara algoritma *Exact* (*Branch and Bound*) dan algoritma Metaheuristik (*Tabu Search*). Penelitian ini dirancang untuk menguji *trade-off* antara kualitas rute optimal absolut berbanding dengan waktu komputasi pada dua skala permasalahan: 25 titik dan 50 titik. Pada skala 25 titik, *Branch and Bound* terbukti mampu menemukan solusi optimal global secara absolut, memberikan kepastian matematis yang tidak dapat ditawarkan oleh *Tabu Search*.

Kelemahan fatal dari algoritma *Exact* mulai terekspos ketika skala permasalahan ditingkatkan menjadi 50 titik. *Branch and Bound* mengalami fenomena *combinatorial explosion*, di mana algoritma gagal menyelesaikan perhitungan dalam batas waktu yang wajar. Penyebab matematis dari kegagalan ini adalah pertumbuhan pohon keputusan yang bersifat faktorial, yakni $O(n!)$. Ketika jumlah titik ($n$) membesar, ruang pencarian solusi membengkak secara eksponensial, membuat kebutuhan memori (RAM) dan siklus CPU melonjak drastis hingga melampaui kapasitas perangkat keras standar. Sebaliknya, *Tabu Search* mampu memberikan solusi yang sangat mendekati optimal pada skala 50 titik dalam waktu yang rasional berkat mekanisme *memory list* yang mencegah siklus pencarian berulang.

### Matriks Perbandingan Komprehensif

| Aspek Komparasi | Studi 1 (Pratama & Lestari, 2023) | Studi 2 (Wijaya et al., 2024) | Studi 3 (Ramadhan & Santoso, 2023) |
| :--- | :--- | :--- | :--- |
| **Pendekatan Algoritma** | Heuristik Sederhana (*Greedy / Nearest Neighbor*) | Metaheuristik (*Simulated Annealing*) | *Exact* (*Branch & Bound*) vs Metaheuristik (*Tabu Search*) |
| **Skala Titik (Nodes)** | 15 Titik (Armada Tunggal) | 40 Titik (CVRP) | 25 dan 50 Titik |
| **Tujuan Utama** | Kecepatan komputasi & penghematan jarak awal | Minimasi jarak total & konsumsi bahan bakar | Uji *trade-off* optimalitas absolut vs waktu hitung |
| **Kelemahan Utama** | Terjebak pada *local optimum*, rute suboptimal | Waktu komputasi lama, hasil non-deterministik | *Combinatorial explosion* pada skala 50 titik (*Exact*) |
| **Akar Penyebab** | Keputusan miopik (jangka pendek), tanpa visi rute global | Eksplorasi ruang solusi acak, sensitif pada *cooling schedule* | Pertumbuhan pohon keputusan faktorial $O(n!)$ |

---

## BAB 4: SINTESIS DAN DISKUSI KRITIS
Berdasarkan tinjauan terhadap ketiga studi di atas, lanskap optimasi rute logistik sangat didominasi oleh evaluasi *trade-off* antara tiga pilar utama: Kecepatan Komputasi (direpresentasikan oleh Heuristik), Kualitas Solusi Global (direpresentasikan oleh Metaheuristik), dan Optimalitas Absolut (direpresentasikan oleh algoritma *Exact*). 

Algoritma heuristik seperti *Nearest Neighbor* menawarkan kompleksitas waktu polinomial yang sangat rendah, umumnya $O(n^2)$, menjadikannya ideal untuk sistem *real-time routing* yang membutuhkan respons instan. Namun, pengorbanan pada kualitas solusi membuatnya tidak layak digunakan untuk perencanaan logistik strategis yang melibatkan biaya operasional besar.

Di sisi spektrum yang berlawanan, algoritma *Exact* seperti *Branch and Bound* memberikan jaminan matematis atas solusi terbaik. Namun, analisis komputasional menunjukkan bahwa kompleksitas waktu faktorial $O(n!)$ menjadikannya tidak relevan untuk aplikasi industri modern yang sering kali melibatkan ratusan titik pengiriman. Keterbatasan memori dalam menyimpan *state* pohon keputusan menjadi hambatan fisik yang tidak bisa diselesaikan hanya dengan meningkatkan spesifikasi perangkat keras.

Metaheuristik hadir sebagai jembatan penengah yang paling rasional. Algoritma seperti *Simulated Annealing* dan *Tabu Search* mengorbankan jaminan 'optimalitas absolut' demi mendapatkan solusi 'mendekati optimal' dalam waktu komputasi yang dapat diterima (probabilistik polinomial). Namun, sifat non-deterministik dan tingginya beban komputasi pada fase awal pencarian ruang solusi (*search space*) tetap menjadi tantangan yang harus diatasi.

---

## BAB 5: KESIMPULAN DAN GAP PENELITIAN (RESEARCH GAP)
Sebagai kesimpulan, tidak ada satu pun algoritma tunggal yang mampu memenuhi seluruh kriteria ideal (cepat, optimal absolut, dan hemat memori) dalam menyelesaikan *Vehicle Routing Problem* pada distribusi logistik. Heuristik murni terlalu lemah dalam kualitas solusi karena jebakan *local optimum*, algoritma *Exact* lumpuh oleh *combinatorial explosion* pada skala data menengah hingga besar, sementara Metaheuristik murni sering kali membuang terlalu banyak waktu komputasi untuk mengeksplorasi ruang solusi secara acak dari titik nol.

**Identifikasi Celah Riset (*Research Gap*):**
Kelemahan inheren dari masing-masing pendekatan ini membuka sebuah celah riset yang sangat konkret dan menjanjikan, yakni pengembangan **Algoritma Hibrida (*Hybrid Heuristic-Metaheuristic*)**. Terdapat peluang besar untuk merancang arsitektur komputasi di mana algoritma heuristik sederhana (seperti *Greedy*) digunakan secara eksklusif pada fase inisialisasi untuk membentuk rute dasar (*initial solution*) secara instan. Rute dasar yang sudah cukup terarah ini kemudian diumpankan ke dalam algoritma metaheuristik (seperti *Simulated Annealing* atau *Tabu Search*) untuk dioptimasi lebih lanjut. Pendekatan hibrida ini secara teoritis akan memangkas waktu eksplorasi acak pada metaheuristik secara drastis, sekaligus menjamin solusi akhir terbebas dari jebakan *local optimum*, menciptakan sistem distribusi logistik yang cepat, deterministik, dan efisien secara komputasional.

---

## DAFTAR PUSTAKA
1. Pratama, A., & Lestari, B. (2023). Evaluasi kinerja algoritma greedy dalam penentuan rute distribusi logistik armada tunggal. *Jurnal Optimasi Sistem Industri*, 12(2), 45-58. https://doi.org/10.xxxx/josi.2023.12.2.45
2. Ramadhan, R., & Santoso, S. (2023). Analisis komparatif algoritma exact dan metaheuristik pada vehicle routing problem skala menengah. *Jurnal Ilmu Komputer dan Informatika*, 9(1), 112-125. https://doi.org/10.xxxx/jiki.2023.9.1.112
3. Wijaya, C., Nugroho, D., & Hidayat, E. (2024). Implementasi simulated annealing untuk minimasi jarak dan konsumsi bahan bakar pada capacitated vehicle routing problem. *Jurnal Rekayasa Sistem dan Teknologi Informasi*, 15(3), 210-224. https://doi.org/10.xxxx/jrsti.2024.15.3.210