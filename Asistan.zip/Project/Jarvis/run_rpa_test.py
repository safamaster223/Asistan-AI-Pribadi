import asyncio
import csv
import json
import os
from playwright.async_api import async_playwright

def validate_and_parse_input(file_path):
    """Membaca dan memvalidasi data CSV sebelum eksekusi."""
    records = []
    if not os.path.exists(file_path):
        print(f"Error: File {file_path} tidak ditemukan.")
        return records
        
    with open(file_path, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Validasi dasar (Data Integrity First)
            if not row.get('nama') or not row.get('email'):
                print(f"Skipping invalid row: {row}")
                continue
            records.append(row)
    return records

async def fill_single_record(page, record):
    """Mengisi satu baris data ke dalam form secara defensif."""
    try:
        # Clear before fill & Defensive Interaction
        await page.locator('#nama').fill('')
        await page.locator('#nama').fill(record['nama'])
        
        await page.locator('#email').fill('')
        await page.locator('#email').fill(record['email'])
        
        await page.locator('#no_hp').fill('')
        await page.locator('#no_hp').fill(record['no_hp'])
        
        # Dropdown Handling
        await page.locator('#posisi').select_option(value=record['posisi'])
        
        # Radio Button Handling
        if record['gender'] == 'L':
            await page.locator('#gender_l').check()
        elif record['gender'] == 'P':
            await page.locator('#gender_p').check()
            
        # Submit
        await page.locator('#submit-btn').click()
        
        # Post-Submit Verification (Dynamic Wait)
        # Tunggu elemen status-message muncul dan terlihat
        await page.locator('#status-message').wait_for(state='visible', timeout=5000)
        
        # Tunggu elemen status-message hilang (form siap untuk entri berikutnya)
        await page.locator('#status-message').wait_for(state='hidden', timeout=5000)
        
        return {"status": "SUCCESS", "record": record['nama'], "error": None}
        
    except Exception as e:
        # Error Handling & Recovery
        error_msg = str(e).split('\\n')[0]
        print(f"Failed to process {record['nama']}: {error_msg}")
        
        # Ambil screenshot bukti kegagalan
        safe_name = record['nama'].replace(' ', '_')
        await page.screenshot(path=f"error_{safe_name}.png")
        
        return {"status": "FAILED", "record": record['nama'], "error": error_msg}

async def run_batch_rpa(records, target_url):
    """Menjalankan proses RPA secara batch dan menghasilkan Audit Trail."""
    audit_log = []
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()
        
        try:
            print(f"Navigating to {target_url}...")
            await page.goto(target_url, wait_until='networkidle')
            
            for i, record in enumerate(records):
                print(f"Processing record {i+1}/{len(records)}: {record['nama']}")
                
                # Retry logic (maksimal 2 kali)
                max_retries = 2
                for attempt in range(max_retries):
                    result = await fill_single_record(page, record)
                    if result['status'] == 'SUCCESS':
                        audit_log.append(result)
                        break
                    else:
                        print(f"Attempt {attempt+1} failed. Retrying...")
                        if attempt == max_retries - 1:
                            audit_log.append(result)
                            
                # Throttling wajar antar pengiriman
                await asyncio.sleep(1)
                
        finally:
            await browser.close()
            
    # Simpan Audit Trail
    with open('audit_log.json', 'w', encoding='utf-8') as f:
        json.dump(audit_log, f, indent=4)
        
    print("Batch RPA selesai. Audit log disimpan ke audit_log.json")

if __name__ == "__main__":
    # Gunakan absolute path untuk file HTML lokal
    current_dir = os.path.abspath(os.path.dirname(__file__))
    target_url = f"file:///{current_dir}/form_test.html".replace('\\\\', '/')
    
    records = validate_and_parse_input('data_test.csv')
    if records:
        asyncio.run(run_batch_rpa(records, target_url))
    else:
        print("Tidak ada data valid untuk diproses.")
