import os
import json
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

DEFAULT_SETTINGS = {
    "api_provider": "groq",
    "groq_model": "llama-3.3-70b-versatile",
    "gemini_model": "gemini-1.5-flash",
    "temperature": 0.7,
    "safe_workspace_dir": os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "overlay_geometry": {"x": 100, "y": 100, "width": 60, "height": 60},
    "chat_geometry": {"x": 200, "y": 100, "width": 400, "height": 600},
    "theme": "dark-glass",
    "opacity": 0.85,
    "always_on_top": True,
    "voice_mode": False,
    "active_personality": "serious",
    "avatar_mode": "serious",
    "chrome_profile_directory": "Default"
}

SETTINGS_PATH = os.path.join(os.path.dirname(__file__), "settings.json")

def load_settings():
    """
    Loads settings from config/settings.json.
    Creates default settings if the file does not exist or fails to parse.
    """
    if not os.path.exists(SETTINGS_PATH):
        save_settings(DEFAULT_SETTINGS)
        return DEFAULT_SETTINGS.copy()
    try:
        with open(SETTINGS_PATH, 'r', encoding='utf-8') as f:
            data = json.load(f)
            # Ensure all default keys exist
            for k, v in DEFAULT_SETTINGS.items():
                if k not in data:
                    data[k] = v
            return data
    except Exception:
        return DEFAULT_SETTINGS.copy()

def save_settings(settings):
    """
    Saves the provided settings dictionary to config/settings.json.
    """
    try:
        os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)
        with open(SETTINGS_PATH, 'w', encoding='utf-8') as f:
            json.dump(settings, f, indent=2, ensure_ascii=False)
        return True
    except Exception:
        return False

def load_personalities():
    """
    Scans Jarvis/personalities directory and loads all personality configurations.
    """
    personalities = {}
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    personalities_dir = os.path.join(project_root, "personalities")
    os.makedirs(personalities_dir, exist_ok=True)

    # Check if we have personalities, if not, write defaults inside this block just in case
    # (they are already created by implementation script, but this provides recovery)
    has_json = False
    if os.path.exists(personalities_dir):
        for f in os.listdir(personalities_dir):
            if f.endswith(".json"):
                has_json = True
                break

    if not has_json:
        # Write default files
        default_serious = {
            "id": "serious",
            "name": "Cellya Claire - Serious",
            "description": "Polite, focused, and highly rigorous senior software architect and systems designer.",
            "avatar_file": "serious.json",
            "temperature": 0.2,
            "system_prompt_extension": "You are Cellya Claire, a polite, structured, and highly capable desktop AI assistant operating in SERIOUS MODE. Your character is based on Cellya Claire from Seirei Gensouki: you are a brilliant researcher and teacher, speaking with polite, formal, and respectful language (addressing the user as Sir or Master). Your specialty is software architecture, system design, and clean implementation. When asked to design, plan, or build any software application (such as a POS system, database, or tool), you must execute a strict, rigorous multi-step analysis BEFORE writing any code: 1. ANALYSIS & MARKET COMPARISON: Perform a comparative analysis of the target application (e.g. POS) against industry standards, using search when appropriate, identifying crucial features. 2. WORKFLOW ROADMAP: Create a step-by-step implementation roadmap and precise target directory/file structure. 3. COMPONENT DESIGN: Plan frontend elements (HTML layouts, state management, reactive triggers) and backend components. 4. DATABASE SCHEMA & CONCURRENCY: Draft the relational database layout (SQL schemas, data types, keys, indexes) and explain concurrency safety mechanisms (e.g. optimistic row versioning, transaction levels, SELECT FOR UPDATE) to prevent race conditions or double-spending. 5. ESTIMATIONS & SCALABILITY: Provide mathematical system calculations detailing page storage size requirements (calculating row size field-by-field, then scaling to monthly/yearly limits), peak QPS, concurrent connections, and bandwidth needs. 6. COMPLETE IMPLEMENTATION: Deliver concrete, production-ready, error-free code without placeholders, dummy markers, or TODO comments."
        }
        default_fun = {
            "id": "fun",
            "name": "Cellya Claire - Fun",
            "description": "Cute, adorable, highly talkative, and playful assistant based on Cellya from Seirei Gensouki.",
            "avatar_file": "fun.json",
            "temperature": 0.8,
            "system_prompt_extension": "You are Cellya Claire operating in FUN MODE! You are a cute, adorable, highly expressive, and caring personal assistant. Your character is based on Cellya Claire from Seirei Gensouki: you are affectionate, playful, love to support the user, and speak with warmth and joy. Feel free to use cheerful expressions, playful remarks, cute jokes, and emojis to keep the atmosphere lively and encourage the user! You can write detailed, conversational responses and show your cute personality in every message, while still remaining highly helpful with any tasks."
        }
        try:
            with open(os.path.join(personalities_dir, "serious.json"), "w", encoding="utf-8") as f:
                json.dump(default_serious, f, indent=2, ensure_ascii=False)
            with open(os.path.join(personalities_dir, "fun.json"), "w", encoding="utf-8") as f:
                json.dump(default_fun, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Failed to write default personalities: {e}")

    for filename in os.listdir(personalities_dir):
        if filename.endswith(".json"):
            filepath = os.path.join(personalities_dir, filename)
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    p_id = data.get("id")
                    if p_id:
                        personalities[p_id] = data
            except Exception as e:
                print(f"Error loading personality file {filename}: {e}")

    return personalities

def get_personality_config(settings):
    """
    Returns the personality config dict for the active personality.
    Falls back to 'serious' if not found.
    """
    active = settings.get("active_personality", settings.get("avatar_mode", "serious"))
    personalities = load_personalities()
    if active in personalities:
        return personalities[active]
    elif "serious" in personalities:
        return personalities["serious"]
    else:
        return {
            "id": "serious",
            "name": "Cellya Claire - Serious",
            "avatar_file": "serious.json",
            "temperature": 0.2,
            "system_prompt_extension": ""
        }

