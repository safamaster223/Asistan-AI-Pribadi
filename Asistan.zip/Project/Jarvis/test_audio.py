import sys
import os

print("=== DIAGNOSTIK AUDIO CELLYA ===")
print(f"Python Bitness: {'64-bit' if sys.maxsize > 2**32 else '32-bit'}")

try:
    import vlc
    try:
        vlc_version = vlc.libvlc_get_version()
        print(f"VLC Terdeteksi! Versi: {vlc_version}")
    except Exception as e:
        print(f"VLC Module terinstal, tapi gagal memuat libvlc.dll: {e}")
except ImportError:
    print("VLC Module (python-vlc) BELUM terinstal.")
except Exception as e:
    print(f"Error VLC tidak terduga: {e}")

try:
    import yt_dlp
    print(f"yt-dlp Terdeteksi! Versi: {yt_dlp.version.__version__}")
except ImportError:
    print("yt-dlp BELUM terinstal.")
except Exception as e:
    print(f"Error yt-dlp: {e}")
