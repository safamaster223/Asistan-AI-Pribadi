import yt_dlp
import threading
import time
import sqlite3
import os

try:
    import vlc
    VLC_AVAILABLE = True
except (ImportError, OSError, FileNotFoundError) as e:
    vlc = None
    VLC_AVAILABLE = False
    print(f"[MusicPlayer] VLC not available: {e}. Falling back to Pygame mixer.")

class CellyaAudioEngine:
    def __init__(self, db_path="music_data.db"):
        self.current_track_info = None
        self.is_playing = False
        self.volume = 50
        self.instance = None
        self.player = None
        self.pygame_initialized = False

        if VLC_AVAILABLE and vlc:
            try:
                self.instance = vlc.Instance('--no-video')
                self.player = self.instance.media_player_new()
                self.player.audio_set_volume(self.volume)
                print("[MusicPlayer] VLC player initialized successfully.")
            except Exception as e:
                print(f"[MusicPlayer] Failed to initialize VLC: {e}. Falling back to Pygame.")
                self.instance = None
                self.player = None

        if not self.player:
            try:
                import pygame
                if not pygame.mixer.get_init():
                    pygame.mixer.init()
                self.pygame_initialized = True
                pygame.mixer.music.set_volume(self.volume / 100.0)
                print("[MusicPlayer] Pygame mixer initialized as fallback.")
            except Exception as e:
                print(f"[MusicPlayer] Failed to initialize Pygame mixer: {e}")

        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS tracks (
                    track_id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    channel_name TEXT,
                    duration_seconds INTEGER,
                    thumbnail_url TEXT
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS playlists (
                    playlist_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL UNIQUE,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS playlist_tracks (
                    playlist_id INTEGER,
                    track_id TEXT,
                    position INTEGER,
                    added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (playlist_id, track_id),
                    FOREIGN KEY (playlist_id) REFERENCES playlists(playlist_id) ON DELETE CASCADE,
                    FOREIGN KEY (track_id) REFERENCES tracks(track_id)
                )
            ''')
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"[MusicPlayer] DB init error: {e}")

    def search_and_extract(self, query: str, limit: int = 5) -> list:
        """Mencari lagu di YouTube dan mengembalikan metadata."""
        ydl_opts = {
            'format': 'bestaudio/best',
            'noplaylist': True,
            'extract_flat': 'in_playlist',
            'default_search': 'ytsearch',
            'quiet': True
        }

        results = []
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(f"ytsearch{limit}:{query}", download=False)
                if 'entries' in info:
                    for entry in info['entries']:
                        results.append({
                            'id': entry.get('id'),
                            'title': entry.get('title'),
                            'channel': entry.get('uploader'),
                            'duration': entry.get('duration'),
                            'url': entry.get('url'),
                            'thumbnail': entry.get('thumbnail')
                        })
        except Exception as e:
            print(f"[MusicPlayer] Search error: {e}")
        return results

    def get_direct_stream_url(self, video_url: str) -> str:
        """Mengekstrak URL streaming audio murni untuk diputar."""
        ydl_opts = {
            'format': 'bestaudio/best',
            'quiet': True
        }
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(video_url, download=False)
                return info['url']
        except Exception as e:
            print(f"[MusicPlayer] Extract error: {e}")
            return None

    def play_track(self, track_info: dict):
        """Memutar lagu di thread terpisah agar UI tidak freeze."""
        self.current_track_info = track_info

        def _play():
            video_url = track_info.get('url')
            if not video_url and track_info.get('id'):
                video_url = f"https://www.youtube.com/watch?v={track_info['id']}"

            stream_url = self.get_direct_stream_url(video_url)
            if not stream_url:
                print("[MusicPlayer] Failed to get stream URL.")
                return

            if self.player:
                try:
                    media = self.instance.media_new(stream_url)
                    self.player.set_media(media)
                    self.player.play()
                    self.is_playing = True
                    self._save_track_to_db(track_info)
                except Exception as e:
                    print(f"[MusicPlayer] VLC play failed: {e}")
            elif self.pygame_initialized:
                try:
                    import pygame
                    import tempfile
                    import urllib.request

                    try:
                        pygame.mixer.music.load(stream_url)
                        pygame.mixer.music.play()
                        self.is_playing = True
                    except Exception as direct_ex:
                        print(f"[MusicPlayer] Pygame direct load failed ({direct_ex}). Downloading...")

                        if pygame.mixer.music.get_busy():
                            pygame.mixer.music.stop()
                        pygame.mixer.music.unload()

                        temp_dir = tempfile.gettempdir()
                        temp_file_path = os.path.join(temp_dir, "cellya_music_temp.mp3")

                        if os.path.exists(temp_file_path):
                            try:
                                os.remove(temp_file_path)
                            except:
                                pass

                        urllib.request.urlretrieve(stream_url, temp_file_path)
                        pygame.mixer.music.load(temp_file_path)
                        pygame.mixer.music.play()
                        self.is_playing = True

                    self._save_track_to_db(track_info)
                except Exception as e:
                    print(f"[MusicPlayer] Pygame play failed: {e}")

        threading.Thread(target=_play, daemon=True).start()

    def _save_track_to_db(self, track_info):
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT OR IGNORE INTO tracks (track_id, title, channel_name, duration_seconds, thumbnail_url)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                track_info.get('id'),
                track_info.get('title'),
                track_info.get('channel'),
                track_info.get('duration'),
                track_info.get('thumbnail')
            ))
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"[MusicPlayer] Error saving track to DB: {e}")

    def pause(self):
        if self.player:
            self.player.pause()
            self.is_playing = False
        elif self.pygame_initialized:
            import pygame
            pygame.mixer.music.pause()
            self.is_playing = False

    def resume(self):
        if self.player:
            self.player.play()
            self.is_playing = True
        elif self.pygame_initialized:
            import pygame
            pygame.mixer.music.unpause()
            self.is_playing = True

    def stop(self):
        if self.player:
            self.player.stop()
        elif self.pygame_initialized:
            import pygame
            pygame.mixer.music.stop()
            try:
                pygame.mixer.music.unload()
            except:
                pass
        self.is_playing = False
        self.current_track_info = None

    def set_volume(self, level: int):
        self.volume = max(0, min(100, level))
        if self.player:
            self.player.audio_set_volume(self.volume)
        elif self.pygame_initialized:
            import pygame
            pygame.mixer.music.set_volume(self.volume / 100.0)

    def get_position(self):
        """Returns current position in seconds."""
        if self.player:
            return self.player.get_time() // 1000
        elif self.pygame_initialized and self.current_track_info:
            import pygame
            played_ms = pygame.mixer.music.get_pos()
            if played_ms < 0:
                played_ms = 0
            return played_ms // 1000
        return 0

    def set_position(self, seconds: int):
        if self.player:
            self.player.set_time(seconds * 1000)
        elif self.pygame_initialized:
            import pygame
            try:
                pygame.mixer.music.set_pos(seconds)
            except Exception as e:
                print(f"[MusicPlayer] Failed to set Pygame position: {e}")
