import os
import time
import json
import uuid
import requests
from playwright.sync_api import sync_playwright

class ClaudeWebHTTPClient:
    def __init__(self, session_key):
        self.session_key = session_key
        self.org_id = None
        self.headers = {
            "Cookie": f"sessionKey={self.session_key}",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "application/json",
            "Content-Type": "application/json"
        }

    def _ensure_org(self):
        if self.org_id:
            return True
        try:
            r = requests.get("https://claude.ai/api/organizations", headers=self.headers, timeout=10)
            if r.status_code == 200:
                orgs = r.json()
                if orgs and isinstance(orgs, list):
                    self.org_id = orgs[0]["uuid"]
                    return True
            print(f"Claude HTTP: Failed to get organization. Status: {r.status_code}, Body: {r.text}")
        except Exception as e:
            print(f"Claude HTTP Org Error: {e}")
        return False

    def stream_chat(self, prompt):
        if not self._ensure_org():
            raise RuntimeError("Unauthorized or unable to fetch organization. Session key might be invalid.")

        conv_uuid = str(uuid.uuid4())
        # Create conversation
        r = requests.post(
            f"https://claude.ai/api/organizations/{self.org_id}/chat_conversations",
            headers=self.headers,
            json={"uuid": conv_uuid, "name": ""},
            timeout=10
        )
        if r.status_code != 201 and r.status_code != 200:
            raise RuntimeError(f"Failed to create conversation: {r.status_code} - {r.text}")

        # Send completion request (stream)
        payload = {
            "attachments": [],
            "files": [],
            "model": "claude-3-5-sonnet",
            "prompt": prompt,
            "timezone": "America/New_York",
            "rendering_mode": "raw"
        }

        url = f"https://claude.ai/api/organizations/{self.org_id}/chat_conversations/{conv_uuid}/completion"
        stream_headers = {
            **self.headers,
            "Accept": "text/event-stream"
        }

        response = requests.post(url, headers=stream_headers, json=payload, stream=True, timeout=30)
        if response.status_code != 200:
            raise RuntimeError(f"Completion failed: {response.status_code} - {response.text}")

        for line in response.iter_lines():
            if line:
                decoded = line.decode('utf-8')
                if decoded.startswith("data: "):
                    try:
                        data = json.loads(decoded[6:])
                        if "completion" in data:
                            yield data["completion"]
                    except Exception:
                        pass


class WebProxy:
    def __init__(self, browser_manager=None):
        self.browser_manager = browser_manager

    def stream_claude_web(self, prompt):
        """
        Attempts Claude Web Chat. Uses lightweight HTTP Client first.
        Falls back to Playwright browser automation if HTTP fails.
        """
        session_key = os.getenv("CLAUDE_SESSION_KEY", "").strip()
        if session_key and not session_key.startswith("your_"):
            try:
                print("Claude Web: Attempting via raw HTTP Client...")
                client = ClaudeWebHTTPClient(session_key)
                yield from client.stream_chat(prompt)
                return
            except Exception as e:
                print(f"Claude Web HTTP failed: {e}. Falling back to Playwright automation...")

        # Fallback to Playwright Automation
        yield from self._stream_claude_playwright(prompt, session_key)

    def _stream_claude_playwright(self, prompt, session_key=None):
        if not self.browser_manager:
            yield "Error: Browser manager is not initialized for Playwright fallback."
            return

        try:
            print("Claude Web: Starting Playwright browser session...")
            self.browser_manager.start_session(headless=True)
            page = self.browser_manager.get_active_page()
            page.goto("https://claude.ai/new")

            # Check if login required
            if "login" in page.url or page.locator("text=Sign in").count() > 0:
                if session_key:
                    self.browser_manager.context.add_cookies([{
                        "name": "sessionKey",
                        "value": session_key,
                        "domain": ".claude.ai",
                        "path": "/"
                    }])
                    page.goto("https://claude.ai/new")
                    page.wait_for_load_state("networkidle")
                else:
                    yield "Error: Claude Web requires sessionKey. Please configure CLAUDE_SESSION_KEY in your .env file."
                    return

            # Wait for message input area
            input_selector = 'div[contenteditable="true"], textarea[placeholder*="Claude"], textarea'
            page.wait_for_selector(input_selector, timeout=15000)

            # Fill prompt
            page.fill(input_selector, prompt)

            # Press enter to send
            page.press(input_selector, "Enter")

            # Wait for response container
            response_selector = 'div[data-testid="assistant-message"], .font-claude-message, div.chat-message.assistant'
            page.wait_for_selector(response_selector, timeout=15000)

            # Stream response
            last_text = ""
            no_change_count = 0
            while no_change_count < 30:  # 3 seconds with no change = finished
                elements = page.locator(response_selector).all()
                if elements:
                    current_text = elements[-1].inner_text()
                    if current_text != last_text:
                        new_chunk = current_text[len(last_text):]
                        last_text = current_text
                        yield new_chunk
                        no_change_count = 0
                    else:
                        no_change_count += 1
                time.sleep(0.1)

        except Exception as e:
            yield f"\n[Claude Web Proxy Error: {str(e)}]"

    def stream_gemini_web(self, prompt):
        """
        Gemini Web Chat via Playwright automation.
        """
        if not self.browser_manager:
            yield "Error: Browser manager is not initialized for Playwright."
            return

        try:
            print("Gemini Web: Starting Playwright browser session...")
            self.browser_manager.start_session(headless=True)
            page = self.browser_manager.get_active_page()
            page.goto("https://gemini.google.com/app")

            # Check if login required & check if cookie is in .env
            gemini_cookie = os.getenv("GEMINI_COOKIE", "").strip()
            # If not logged in and cookie exists, inject it
            if "login" in page.url or page.locator("text=Sign in").count() > 0 or page.locator("a[href*='accounts.google.com']").count() > 0:
                if gemini_cookie and not gemini_cookie.startswith("your_"):
                    cookies = []
                    for part in gemini_cookie.split(";"):
                        part = part.strip()
                        if "=" in part:
                            name, val = part.split("=", 1)
                            cookies.append({
                                "name": name,
                                "value": val,
                                "domain": ".google.com",
                                "path": "/"
                            })
                    self.browser_manager.context.add_cookies(cookies)
                    page.goto("https://gemini.google.com/app")
                    page.wait_for_load_state("networkidle")
                else:
                    yield "Error: Gemini Web requires session cookies. Please configure GEMINI_COOKIE in your .env file."
                    return

            # Wait for text input area
            input_selector = 'div[contenteditable="true"], textarea, gux-text-field textarea'
            page.wait_for_selector(input_selector, timeout=15000)

            # Fill prompt
            page.fill(input_selector, prompt)

            # Press enter to send
            page.press(input_selector, "Enter")

            # Wait for response container
            response_selector = '.message-content, message-content, .model-response, model-response'
            page.wait_for_selector(response_selector, timeout=15000)

            # Stream response
            last_text = ""
            no_change_count = 0
            while no_change_count < 30:  # 3 seconds with no change = finished
                elements = page.locator(response_selector).all()
                if elements:
                    current_text = elements[-1].inner_text()
                    if current_text != last_text:
                        new_chunk = current_text[len(last_text):]
                        last_text = current_text
                        yield new_chunk
                        no_change_count = 0
                    else:
                        no_change_count += 1
                time.sleep(0.1)

        except Exception as e:
            yield f"\n[Gemini Web Proxy Error: {str(e)}]"
