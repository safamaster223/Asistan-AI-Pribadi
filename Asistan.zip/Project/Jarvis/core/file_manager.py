import os
import shutil

def get_safe_roots(settings):
    """
    Retrieves a list of allowed safe workspace directories.
    Includes:
    1. Workspace dir (from config or environment override)
    2. Downloads directory
    3. Program Files directory
    """
    roots = []

    # 1. Primary workspace
    env_dir = os.getenv("JARVIS_WORKSPACE_DIR")
    if env_dir:
        roots.append(os.path.abspath(os.path.realpath(env_dir)))
    else:
        settings_dir = settings.get("safe_workspace_dir")
        if settings_dir:
            roots.append(os.path.abspath(os.path.realpath(settings_dir)))
        else:
            # Fallback to project root directory
            fallback = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            roots.append(os.path.abspath(os.path.realpath(fallback)))

    # 2. Downloads directory
    downloads_path = os.path.join(os.path.expanduser("~"), "Downloads")
    if os.path.exists(downloads_path):
        roots.append(os.path.abspath(os.path.realpath(downloads_path)))

    # 3. Program Files directory
    program_files = os.environ.get("ProgramFiles", "C:\\Program Files")
    if os.path.exists(program_files):
        roots.append(os.path.abspath(os.path.realpath(program_files)))

    # 4. Program Files (x86) directory (optional but useful)
    program_files_x86 = os.environ.get("ProgramFiles(x86)", "C:\\Program Files (x86)")
    if os.path.exists(program_files_x86):
        roots.append(os.path.abspath(os.path.realpath(program_files_x86)))

    # Remove duplicates while preserving order
    unique_roots = []
    for r in roots:
        if r not in unique_roots:
            unique_roots.append(r)

    return unique_roots

def is_path_safe(path, safe_roots):
    """
    Checks if a target path lies within any of the resolved safe_roots.
    Prevents path traversal outside the allowed directories.
    Handles case-insensitivity on Windows (using os.path.normcase).
    """
    try:
        resolved_path = os.path.normcase(os.path.abspath(os.path.realpath(path)))
        for root in safe_roots:
            resolved_root = os.path.normcase(os.path.abspath(os.path.realpath(root)))
            # Check if resolved path starts with the resolved root plus a separator,
            # or matches it exactly.
            if resolved_path == resolved_root or resolved_path.startswith(resolved_root + os.sep):
                return True
        return False
    except Exception:
        return False

def get_project_tree(safe_root):
    """
    Returns a dictionary tree structure of the primary safe_root workspace.
    Excludes .git, node_modules, venv, and __pycache__.
    """
    tree = {}
    ignore_dirs = {'.git', 'venv', '__pycache__', 'node_modules', '.claude'}
    ignore_files = {'.env', 'settings.json'}

    for dirpath, dirnames, filenames in os.walk(safe_root):
        # Modify dirnames in-place to avoid walking into ignored directories
        dirnames[:] = [d for d in dirnames if d not in ignore_dirs]

        # Calculate relative path from safe root
        rel_dir = os.path.relpath(dirpath, safe_root)
        if rel_dir == ".":
            current_level = tree
        else:
            parts = rel_dir.split(os.sep)
            current_level = tree
            for part in parts:
                current_level = current_level.setdefault(part, {})

        for name in filenames:
            if name not in ignore_files:
                current_level[name] = None

    return tree

def read_file(file_path, safe_roots):
    """
    Safely reads file content inside allowed safe_roots.
    """
    if not is_path_safe(file_path, safe_roots):
        return "Error: Path traversal or unauthorized access blocked. Access denied."

    if not os.path.exists(file_path):
        return f"Error: File '{os.path.basename(file_path)}' not found."

    if os.path.isdir(file_path):
        return f"Error: Path '{os.path.basename(file_path)}' is a directory, not a file."

    # Intercept PDF files to extract their text content
    if file_path.lower().endswith('.pdf'):
        try:
            import pypdf
        except ImportError:
            return (
                "Error: The 'pypdf' library is required to read PDF files. "
                "Please make sure it is installed, or update requirements.txt."
            )
        try:
            reader = pypdf.PdfReader(file_path)
            text_parts = []
            for i, page in enumerate(reader.pages):
                page_text = page.extract_text()
                if page_text:
                    text_parts.append(f"--- Page {i + 1} ---\n{page_text}")
            if not text_parts:
                return "Warning: No text could be extracted from this PDF. It might consist of scanned images or be empty."
            return "\n\n".join(text_parts)
        except Exception as e:
            return f"Error reading PDF file: {str(e)}"

    try:
        with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
            return f.read()
    except Exception as e:
        return f"Error reading file: {str(e)}"

def write_file(file_path, content, safe_roots):
    """
    Safely writes content to a file inside allowed safe_roots.
    Creates parent directories dynamically if safe.
    """
    if not is_path_safe(file_path, safe_roots):
        return "Error: Path traversal or unauthorized access blocked. Access denied."

    try:
        parent_dir = os.path.dirname(file_path)
        if parent_dir and not os.path.exists(parent_dir):
            if is_path_safe(parent_dir, safe_roots):
                os.makedirs(parent_dir, exist_ok=True)
            else:
                return "Error: Unauthorized creation of directories outside allowed roots."

        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        return f"Success: File written successfully."
    except Exception as e:
        return f"Error writing file: {str(e)}"

def delete_file(file_path, safe_roots):
    """
    Safely deletes a file or directory inside allowed safe_roots.
    """
    if not is_path_safe(file_path, safe_roots):
        return "Error: Path traversal or unauthorized access blocked. Access denied."

    if not os.path.exists(file_path):
        return f"Error: File or directory '{os.path.basename(file_path)}' not found."

    try:
        if os.path.isdir(file_path):
            shutil.rmtree(file_path)
            return f"Success: Directory deleted successfully."
        else:
            os.remove(file_path)
            return f"Success: File deleted successfully."
    except Exception as e:
        return f"Error deleting: {str(e)}"

def list_directory_contents(dir_path, safe_roots):
    """
    Lists files in directory dir_path inside allowed safe_roots.
    """
    if not is_path_safe(dir_path, safe_roots):
        return "Error: Path traversal or unauthorized access blocked. Access denied."

    if not os.path.exists(dir_path):
        return "Error: Directory not found."

    if not os.path.isdir(dir_path):
        return "Error: Path is a file, not a directory."

    try:
        items = []
        for name in os.listdir(dir_path):
            full_path = os.path.join(dir_path, name)
            is_dir = os.path.isdir(full_path)
            size = os.path.getsize(full_path) if not is_dir else 0
            mtime = os.path.getmtime(full_path)
            items.append({
                "name": name,
                "type": "directory" if is_dir else "file",
                "size": size,
                "modified": mtime
            })
        return items
    except Exception as e:
        return f"Error listing directory: {str(e)}"
