import os
import json
import traceback
from html.parser import HTMLParser
from groq import Groq
from openai import OpenAI
from google import genai
from google.genai import types
from core.prompts import SYSTEM_PROMPT, TOOLS_SCHEMA
from core import file_manager
from core.usage_tracker import UsageTracker
from config import get_personality_config
from core.learning_tracker import load_learnings_prompt, add_learning_point
from core.automator.browser import BrowserManager
from core.automator.classroom import ClassroomScraper
from core.automator.forms import FormsParser
from core.automator.docgen import DocumentGenerator
from core.web_proxy import WebProxy

def estimate_tokens(text):
    if not text:
        return 0
    return (len(str(text)) // 4) + 1

def estimate_messages_tokens(messages):
    total = 0
    for m in messages:
        if isinstance(m, dict):
            content = m.get("content")
            if content:
                if isinstance(content, str):
                    total += estimate_tokens(content)
                elif isinstance(content, list):
                    for part in content:
                        if isinstance(part, dict):
                            if part.get("type") == "text":
                                total += estimate_tokens(part.get("text", ""))
                            elif part.get("type") == "image_url":
                                total += 500  # Vision model token overhead
            if "tool_calls" in m and m["tool_calls"]:
                for tc in m["tool_calls"]:
                    if "function" in tc:
                        total += estimate_tokens(tc["function"].get("arguments", ""))
    return total

class AIEngine:
    def __init__(self, settings):
        self.settings = settings
        self.groq_client = None
        self.gravity_client = None
        self.gravity_configured = False
        self.gemini_client = None
        self.gemini_configured = False
        self.permission_callback = None
        self.initialize_clients()
        profile_dir = self.settings.get("chrome_profile_directory", "Default")
        self.browser_manager = BrowserManager(profile_directory=profile_dir)
        self.document_generator = DocumentGenerator()
        self.web_proxy = WebProxy(self.browser_manager)

    def initialize_clients(self):
        """
        Initializes Groq, Gravity, and Gemini clients from environment variables.
        """
        groq_api_key = os.getenv("GROQ_API_KEY", "").strip()
        if groq_api_key and not groq_api_key.startswith("your_"):
            try:
                self.groq_client = Groq(api_key=groq_api_key)
            except Exception as e:
                print(f"Failed to initialize Groq client: {e}")

        gravity_api_key = os.getenv("GRAVITY_API_KEY", "").strip()
        gravity_base = os.getenv("GRAVITY_API_BASE", "http://localhost:20128/api/v1").strip()
        if gravity_api_key and not gravity_api_key.startswith("your_"):
            try:
                self.gravity_client = OpenAI(api_key=gravity_api_key, base_url=gravity_base)
                self.gravity_configured = True
            except Exception as e:
                print(f"Failed to initialize Gravity client: {e}")

        gemini_api_key = os.getenv("GEMINI_API_KEY", "").strip()
        if gemini_api_key and not gemini_api_key.startswith("your_"):
            try:
                self.gemini_client = genai.Client(api_key=gemini_api_key)
                self.gemini_configured = True
            except Exception as e:
                print(f"Failed to configure Gemini: {e}")

    def resolve_path(self, path):
        """
        Resolves relative paths to the safe workspace. Absolute paths remain absolute.
        """
        safe_roots = file_manager.get_safe_roots(self.settings)
        primary_root = safe_roots[0] if safe_roots else os.getcwd()
        if os.path.isabs(path):
            return path
        return os.path.join(primary_root, path)

    def execute_tool(self, name, args):
        """
        Orchestrates tool execution inside core/file_manager.py.
        """
        safe_roots = file_manager.get_safe_roots(self.settings)
        primary_root = safe_roots[0] if safe_roots else os.getcwd()
        try:
            if name == "get_project_tree":
                tree = file_manager.get_project_tree(primary_root)
                return json.dumps(tree, indent=2)

            elif name == "read_file":
                file_path = self.resolve_path(args.get("file_path", ""))
                return file_manager.read_file(file_path, safe_roots)

            elif name == "write_file":
                file_path = self.resolve_path(args.get("file_path", ""))
                content = args.get("content", "")
                return file_manager.write_file(file_path, content, safe_roots)

            elif name == "delete_file":
                file_path = self.resolve_path(args.get("file_path", ""))
                return file_manager.delete_file(file_path, safe_roots)

            elif name == "list_directory_contents":
                dir_path = self.resolve_path(args.get("dir_path", ""))
                contents = file_manager.list_directory_contents(dir_path, safe_roots)
                return json.dumps(contents, indent=2)

            elif name == "execute_terminal_command":
                command = args.get("command", "")
                shell = args.get("shell", "powershell")
                background = args.get("background", None)

                if not command:
                    return "Error: Command parameter is empty."

                # Smart auto-detection for GUI application launches or background tasks
                # if background is not explicitly specified (None).
                if background is None:
                    cmd_lower = command.lower()
                    gui_keywords = ["chrome", "notepad", "spotify", "start ", "start-process", "explorer", "code", "pythonw"]
                    if any(kw in cmd_lower for kw in gui_keywords):
                        background = True
                    else:
                        background = False

                if self.permission_callback:
                    approved = self.permission_callback(command)
                    if not approved:
                        return "Error: Command execution permission denied by the user."
                else:
                    return "Error: User permission confirmation bridge is not set up."

                import subprocess
                try:
                    cwd = primary_root
                    if shell == "cmd":
                        shell_cmd = ["cmd.exe", "/c", command]
                    else:
                        shell_cmd = ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", command]

                    if background:
                        # Spawn the process asynchronously
                        subprocess.Popen(
                            shell_cmd,
                            cwd=cwd,
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL,
                            stdin=subprocess.DEVNULL,
                            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
                        )
                        return f"Success: Command initiated in the background: {command}"

                    res = subprocess.run(
                        shell_cmd,
                        cwd=cwd,
                        capture_output=True,
                        text=True,
                        timeout=30,
                        errors='replace'
                    )

                    output = f"Exit Code: {res.returncode}\n"
                    if res.stdout:
                        output += f"Standard Output:\n{res.stdout}\n"
                    if res.stderr:
                        output += f"Standard Error:\n{res.stderr}\n"
                    return output

                except subprocess.TimeoutExpired:
                    return "Error: Command execution timed out (limit: 30 seconds)."
                except Exception as e:
                    return f"Error executing command: {str(e)}"

            elif name == "open_resource":
                target = args.get("target", "")
                autosave = args.get("autosave", False)
                commit_message = args.get("commit_message", None)
                return self.execute_open_resource(target, autosave, commit_message, primary_root, safe_roots)

            elif name == "search_youtube":
                query = args.get("query", "")
                limit = args.get("limit", 5)
                return self.execute_youtube_search(query, limit)

            elif name == "control_media":
                action = args.get("action", "")
                return self.execute_media_control(action)

            elif name == "get_active_browser_info":
                return self.execute_get_active_browser_info()

            elif name == "read_webpage_summary":
                url = args.get("url", "")
                return self.execute_read_webpage_summary(url)

            elif name == "add_learning_point":
                category = args.get("category", "")
                insight = args.get("insight", "")
                if not category or not insight:
                    return "Error: Both 'category' and 'insight' are required."
                success = add_learning_point(category, insight)
                if success:
                    return f"Success: Saved learning point: [{category}] {insight}"
                else:
                    return "Error: Failed to save learning point."

            elif name == "browser_launch":
                try:
                    # Allow headless execution if specified by settings or defaults
                    headless = args.get("headless", False)
                    res = self.browser_manager.start_session(headless=headless)
                    url = args.get("url")
                    if url:
                        if not url.startswith("http://") and not url.startswith("https://"):
                            url = "https://" + url
                        page = self.browser_manager.get_active_page()
                        page.goto(url)
                        res += f" Navigated browser to {url}."
                    return res
                except Exception as ex:
                    return f"Error launching browser: {str(ex)}"

            elif name == "classroom_scrape":
                try:
                    # Try to start browser session if not already active
                    headless = args.get("headless", True)  # Default to headless for automated classroom scraping
                    self.browser_manager.start_session(headless=headless)
                    page = self.browser_manager.get_active_page()
                    scraper = ClassroomScraper(page)
                    action = args.get("action")
                    course_id = args.get("course_id")
                    assignment_id = args.get("assignment_id")

                    if action == "get_courses":
                        courses = scraper.get_courses()
                        return json.dumps(courses, indent=2, ensure_ascii=False) if isinstance(courses, list) else courses

                    elif action == "get_assignments":
                        if not course_id:
                            return "Error: 'course_id' parameter is required to retrieve assignments."
                        assignments = scraper.get_assignments(course_id)
                        return json.dumps(assignments, indent=2, ensure_ascii=False) if isinstance(assignments, list) else assignments

                    elif action == "get_assignment_detail":
                        if not course_id or not assignment_id:
                            return "Error: Both 'course_id' and 'assignment_id' parameters are required."
                        detail = scraper.get_assignment_detail(course_id, assignment_id)
                        return json.dumps(detail, indent=2, ensure_ascii=False) if isinstance(detail, dict) else detail

                    elif action == "download_attachments":
                        if not course_id or not assignment_id:
                            return "Error: Both 'course_id' and 'assignment_id' parameters are required."
                        downloads_root = os.path.join(os.path.expanduser("~"), "Downloads", "Jarvis_Classroom", f"Course_{course_id}", f"Task_{assignment_id}")
                        res = scraper.download_attachments(course_id, assignment_id, downloads_root)
                        return json.dumps(res, indent=2, ensure_ascii=False) if isinstance(res, list) else res

                    else:
                        return f"Error: Unknown classroom scrape action '{action}'."
                except Exception as ex:
                    return f"Error during Classroom scraping: {str(ex)}"

            elif name == "forms_parse":
                try:
                    url = args.get("url")
                    if not url:
                        return "Error: 'url' parameter is required."
                    page = self.browser_manager.get_active_page()
                    parser = FormsParser(page)
                    res = parser.parse_form(url)
                    return json.dumps(res, indent=2, ensure_ascii=False) if isinstance(res, dict) else res
                except Exception as ex:
                    return f"Error during Google Forms parsing: {str(ex)}"

            elif name == "document_generate":
                try:
                    fmt = args.get("format")
                    file_name = args.get("file_name")
                    data = args.get("data")
                    if not fmt or not file_name or not data:
                        return "Error: 'format', 'file_name', and 'data' are required."

                    file_path = self.resolve_path(file_name)
                    if not file_manager.is_path_safe(file_path, safe_roots):
                        return f"Error: Access Denied. Cannot write file outside authorized workspace: {file_path}"

                    res = self.document_generator.write(fmt, file_path, data)
                    return res
                except Exception as ex:
                    return f"Error during document generation: {str(ex)}"

            else:
                return f"Error: Tool '{name}' not recognized."
        except Exception as e:
            return f"Error executing tool '{name}': {str(e)}"

    def _is_agentic(self, messages):
        """
        Checks if the conversation requires official API (agentic or vision task).
        """
        if not messages:
            return False

        last_msg = messages[-1]
        content = last_msg.get("content", "")

        # Check for image attachments
        if isinstance(content, list):
            for part in content:
                if part.get("type") == "image_url" or part.get("type") == "image":
                    return True
                if part.get("type") == "text":
                    if self._has_agentic_keywords(part.get("text", "")):
                        return True
        elif isinstance(content, str):
            if self._has_agentic_keywords(content):
                return True
        return False

    def _has_agentic_keywords(self, text):
        keywords = [
            "write file", "create file", "delete file", "edit file", "open file",
            "run command", "execute terminal", "powershell", "cmd", "pip install",
            "google classroom", "gcr", "forms_parse", "document_generate",
            "classroom_scrape", "youtube", "media_control", "browser_launch"
        ]
        text_lower = text.lower()
        return any(kw in text_lower for kw in keywords)

    def run_chat_stream(self, messages, model_name, provider, status_callback, tool_callback, permission_callback=None):
        """
        Executes streaming completions and loops recursively to execute function calling.
        Yields text chunks.
        """
        self.permission_callback = permission_callback
        safe_roots = file_manager.get_safe_roots(self.settings)
        primary_root = safe_roots[0] if safe_roots else os.getcwd()

        # Load active personality configuration and learnings
        p_config = get_personality_config(self.settings)
        p_prompt = p_config.get("system_prompt_extension", "")
        learnings_prompt = load_learnings_prompt()

        # Invalidate/override temperature dynamically
        self.current_temperature = p_config.get("temperature", self.settings.get("temperature", 0.7))

        system_msg = SYSTEM_PROMPT.format(safe_root=primary_root)
        if p_prompt:
            system_msg += f"\n\n{p_prompt}"
        if learnings_prompt:
            system_msg += f"\n\n{learnings_prompt}"

        # Web proxy routing integration
        if provider == "web_proxy":
            last_msg = messages[-1]
            content = last_msg.get("content", "")
            if isinstance(content, list):
                prompt = " ".join([part["text"] for part in content if part.get("type") == "text"])
            else:
                prompt = str(content)

            if self._is_agentic(messages):
                if model_name == "claude_web":
                    provider = "gravity"
                    model_name = "ag/gemini-pro-agent"
                    status_callback("Switching to Official API (Agentic Mode) for tool execution...")
                else:
                    provider = "gemini"
                    model_name = "gemini-2.5-pro"
                    status_callback("Switching to Official API (Agentic Mode) for tool execution...")
            else:
                status_callback("Routing through Web Proxy...")
                if model_name == "claude_web":
                    yield from self.web_proxy.stream_claude_web(prompt)
                else:
                    yield from self.web_proxy.stream_gemini_web(prompt)
                return

        # Build api_messages by prepending the system prompt to the user history
        # We DO NOT modify the main chat_history (messages) with the system message
        api_messages = [{"role": "system", "content": system_msg}]
        for m in messages:
            api_messages.append(m)

        if provider == "groq":
            if not self.groq_client:
                # Fallback to check if env key changed
                self.initialize_clients()
                if not self.groq_client:
                    yield "Error: Groq API Key is not set or invalid. Please check your .env file."
                    return
            yield from self._run_groq_stream(messages, api_messages, model_name, status_callback, tool_callback)
        elif provider == "gravity":
            if not self.gravity_configured:
                # Fallback to check if env key changed
                self.initialize_clients()
                if not self.gravity_configured:
                    yield "Error: Gravity API Key is not set or invalid. Please check your .env file."
                    return
            yield from self._run_gravity_stream(messages, api_messages, model_name, status_callback, tool_callback)
        elif provider == "gemini":
            if not self.gemini_configured:
                # Fallback to check if env key changed
                self.initialize_clients()
                if not self.gemini_configured:
                    yield "Error: Gemini API Key is not set or invalid. Please check your .env file."
                    return
            yield from self._run_gemini_stream(messages, api_messages, model_name, status_callback, tool_callback)
        else:
            yield f"Error: Unknown provider '{provider}'."

    def _run_groq_stream(self, chat_history, api_messages, model_name, status_callback, tool_callback):
        groq_tools = []
        for tool in TOOLS_SCHEMA:
            groq_tools.append({
                "type": "function",
                "function": {
                    "name": tool["name"],
                    "description": tool["description"],
                    "parameters": tool["parameters"]
                }
            })

        try:
            iteration = 0
            max_iterations = 10
            while True:
                iteration += 1
                if iteration > max_iterations:
                    yield "\n\nWarning: Tool execution limit reached (max 10 iterations) to prevent infinite loops."
                    status_callback("Loop limit reached.")
                    break
                groq_messages = []
                for m in api_messages:
                    if isinstance(m.get("content"), list):
                        text_parts = [part["text"] for part in m["content"] if part.get("type") == "text"]
                        groq_messages.append({**m, "content": " ".join(text_parts)})
                    else:
                        groq_messages.append(m)

                response = self.groq_client.chat.completions.create(
                    model=model_name,
                    messages=groq_messages,
                    tools=groq_tools,
                    tool_choice="auto",
                    temperature=self.current_temperature,
                    stream=True
                )

                current_tool_calls = {}
                text_generated = ""
                for chunk in response:
                    if not chunk.choices:
                        continue

                    delta = chunk.choices[0].delta
                    if delta.tool_calls:
                        for tc in delta.tool_calls:
                            idx = tc.index
                            if idx not in current_tool_calls:
                                current_tool_calls[idx] = {
                                    "id": tc.id or "",
                                    "name": tc.function.name or "",
                                    "arguments": tc.function.arguments or ""
                                }
                            else:
                                if tc.id:
                                    current_tool_calls[idx]["id"] = tc.id
                                if tc.function and tc.function.name:
                                    current_tool_calls[idx]["name"] += tc.function.name
                                if tc.function and tc.function.arguments:
                                    current_tool_calls[idx]["arguments"] += tc.function.arguments
                            if tc.function and tc.function.arguments:
                                text_generated += tc.function.arguments

                    if delta.content:
                        yield delta.content
                        text_generated += delta.content

                prompt_tokens = estimate_messages_tokens(api_messages)
                completion_tokens = estimate_tokens(text_generated)
                tokens_used = prompt_tokens + completion_tokens
                UsageTracker.increment("groq", tokens_used)

                if not current_tool_calls:
                    # No tool calls generated, we have finished this turn!
                    break

                # If there are tool calls, format and execute them
                tool_call_objs = []
                for idx, tc in current_tool_calls.items():
                    tool_call_objs.append({
                        "id": tc["id"],
                        "type": "function",
                        "function": {
                            "name": tc["name"],
                            "arguments": tc["arguments"]
                        }
                    })

                # Append assistant tool call message to both list histories
                assistant_tool_msg = {
                    "role": "assistant",
                    "tool_calls": tool_call_objs
                }
                chat_history.append(assistant_tool_msg)
                api_messages.append(assistant_tool_msg)

                # Execute calls
                for tc in tool_call_objs:
                    name = tc["function"]["name"]
                    try:
                        args = json.loads(tc["function"]["arguments"])
                        if args is None or not isinstance(args, dict):
                            args = {}
                    except Exception:
                        args = {}

                    status_callback(f"Running tool: {name}...")
                    tool_callback(name, args)

                    result = self.execute_tool(name, args)

                    # Append tool result message to both histories
                    tool_result_msg = {
                        "role": "tool",
                        "tool_call_id": tc["id"],
                        "name": name,
                        "content": result
                    }
                    chat_history.append(tool_result_msg)
                    api_messages.append(tool_result_msg)

                status_callback("Analyzing tool response...")
                # Loop back to let the LLM generate the response or next tool calls

        except Exception as e:
            traceback.print_exc()
            yield f"\n[Groq Error: {str(e)}]"

    def _run_gravity_stream(self, chat_history, api_messages, model_name, status_callback, tool_callback):
        gravity_tools = []
        for tool in TOOLS_SCHEMA:
            gravity_tools.append({
                "type": "function",
                "function": {
                    "name": tool["name"],
                    "description": tool["description"],
                    "parameters": tool["parameters"]
                }
            })

        try:
            iteration = 0
            max_iterations = 10
            while True:
                iteration += 1
                if iteration > max_iterations:
                    yield "\n\nWarning: Tool execution limit reached (max 10 iterations) to prevent infinite loops."
                    status_callback("Loop limit reached.")
                    break
                response = self.gravity_client.chat.completions.create(
                    model=model_name,
                    messages=api_messages,
                    tools=gravity_tools,
                    tool_choice="auto",
                    temperature=self.current_temperature,
                    stream=True
                )

                current_tool_calls = {}
                text_generated = ""
                for chunk in response:
                    if not chunk.choices:
                        continue

                    delta = chunk.choices[0].delta
                    if delta.tool_calls:
                        for tc in delta.tool_calls:
                            idx = tc.index
                            if idx not in current_tool_calls:
                                current_tool_calls[idx] = {
                                    "id": tc.id or "",
                                    "name": tc.function.name or "",
                                    "arguments": tc.function.arguments or ""
                                }
                            else:
                                if tc.id:
                                    current_tool_calls[idx]["id"] = tc.id
                                if tc.function and tc.function.name:
                                    current_tool_calls[idx]["name"] += tc.function.name
                                if tc.function and tc.function.arguments:
                                    current_tool_calls[idx]["arguments"] += tc.function.arguments
                            if tc.function and tc.function.arguments:
                                text_generated += tc.function.arguments

                    if delta.content:
                        yield delta.content
                        text_generated += delta.content

                prompt_tokens = estimate_messages_tokens(api_messages)
                completion_tokens = estimate_tokens(text_generated)
                tokens_used = prompt_tokens + completion_tokens
                UsageTracker.increment("gravity", tokens_used)

                if not current_tool_calls:
                    # No tool calls generated, we have finished this turn!
                    break

                # If there are tool calls, format and execute them
                tool_call_objs = []
                for idx, tc in current_tool_calls.items():
                    tool_call_objs.append({
                        "id": tc["id"],
                        "type": "function",
                        "function": {
                            "name": tc["name"],
                            "arguments": tc["arguments"]
                        }
                    })

                # Append assistant tool call message to both list histories
                assistant_tool_msg = {
                    "role": "assistant",
                    "tool_calls": tool_call_objs
                }
                chat_history.append(assistant_tool_msg)
                api_messages.append(assistant_tool_msg)

                # Execute calls
                for tc in tool_call_objs:
                    name = tc["function"]["name"]
                    try:
                        args = json.loads(tc["function"]["arguments"])
                        if args is None or not isinstance(args, dict):
                            args = {}
                    except Exception:
                        args = {}

                    status_callback(f"Running tool: {name}...")
                    tool_callback(name, args)

                    result = self.execute_tool(name, args)

                    # Append tool result message to both histories
                    tool_result_msg = {
                        "role": "tool",
                        "tool_call_id": tc["id"],
                        "name": name,
                        "content": result
                    }
                    chat_history.append(tool_result_msg)
                    api_messages.append(tool_result_msg)

                status_callback("Analyzing tool response...")
                # Loop back to let the LLM generate the response or next tool calls

        except Exception as e:
            traceback.print_exc()
            yield f"\n[Gravity Error: {str(e)}]"

    def _run_gemini_stream(self, chat_history, api_messages, model_name, status_callback, tool_callback):
        try:
            # Map system instruction
            system_instruction = api_messages[0]["content"]

            # Map the existing chat history
            gemini_history = []
            for msg in chat_history:
                role = "user" if msg["role"] in ("user", "tool") else "model"

                parts = []
                if "content" in msg and msg["content"] and msg["role"] != "tool":
                    if isinstance(msg["content"], str):
                        parts.append(types.Part(text=msg["content"]))
                    elif isinstance(msg["content"], list):
                        for part in msg["content"]:
                            if part.get("type") == "text":
                                parts.append(types.Part(text=part["text"]))
                            elif part.get("type") == "image_url":
                                url = part["image_url"]["url"]
                                if url.startswith("data:"):
                                    header, base64_str = url.split(";base64,")
                                    mime_type = header.split("data:")[1]
                                    import base64
                                    img_bytes = base64.b64decode(base64_str)
                                    parts.append(types.Part(
                                        inline_data=types.Blob(
                                            data=img_bytes,
                                            mime_type=mime_type
                                        )
                                    ))

                if "tool_calls" in msg and msg["tool_calls"]:
                    for tc in msg["tool_calls"]:
                        tc_name = tc.get("name")
                        tc_args = tc.get("args") or {}
                        if not tc_name and "function" in tc:
                            tc_name = tc["function"].get("name")
                            args_str = tc["function"].get("arguments") or "{}"
                            try:
                                tc_args = json.loads(args_str)
                            except Exception:
                                tc_args = {}

                        parts.append(types.Part(
                            function_call=types.FunctionCall(
                                name=tc_name,
                                args=tc_args
                            )
                        ))

                if msg["role"] == "tool":
                    parts.append(types.Part(
                        function_response=types.FunctionResponse(
                            name=msg.get("name"),
                            response={"result": msg.get("content")}
                        )
                    ))

                if parts:
                    gemini_history.append(types.Content(role=role, parts=parts))

            # Map Tools
            gemini_tools = []
            for tool in TOOLS_SCHEMA:
                gemini_tools.append(types.FunctionDeclaration(
                    name=tool["name"],
                    description=tool["description"],
                    parameters=tool["parameters"]
                ))

            # Configure the GenerateContentConfig
            safety_settings = [
                {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
                {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
                {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
                {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"}
            ]

            config = types.GenerateContentConfig(
                system_instruction=system_instruction,
                temperature=self.current_temperature,
                safety_settings=safety_settings,
                tools=[types.Tool(function_declarations=gemini_tools)] if gemini_tools else None
            )

            # Start chat session
            if gemini_history:
                chat = self.gemini_client.chats.create(
                    model=model_name,
                    history=gemini_history[:-1],
                    config=config
                )
                last_msg = gemini_history[-1]
                next_input = last_msg.parts if len(last_msg.parts) > 1 or not last_msg.parts[0].text else last_msg.parts[0].text
            else:
                chat = self.gemini_client.chats.create(
                    model=model_name,
                    config=config
                )
                next_input = "Hello"

            iteration = 0
            max_iterations = 10
            while True:
                iteration += 1
                if iteration > max_iterations:
                    yield "\n\nWarning: Tool execution limit reached (max 10 iterations) to prevent infinite loops."
                    status_callback("Loop limit reached.")
                    break
                # Send the message and stream the response
                response = chat.send_message_stream(next_input)

                tool_calls = []
                tokens_used = 0
                for chunk in response:
                    if chunk.usage_metadata:
                        tokens_used = chunk.usage_metadata.total_token_count

                    if chunk.candidates and chunk.candidates[0].content and chunk.candidates[0].content.parts:
                        for part in chunk.candidates[0].content.parts:
                            if part.function_call:
                                tool_calls.append(part.function_call)
                            elif part.text:
                                yield part.text

                UsageTracker.increment("gemini", tokens_used)

                if not tool_calls:
                    # No tool calls generated, we are done!
                    break

                # Process tool calls
                tool_call_objs = [{"name": call.name, "args": dict(call.args) if call.args else {}} for call in tool_calls]
                chat_history.append({
                    "role": "assistant",
                    "tool_calls": tool_call_objs
                })

                function_responses = []
                for call in tool_calls:
                    name = call.name
                    try:
                        args = dict(call.args) if call.args else {}
                    except Exception:
                        args = {}

                    status_callback(f"Running tool: {name}...")
                    tool_callback(name, args)

                    result = self.execute_tool(name, args)

                    # Append tool result to chat history
                    chat_history.append({
                        "role": "tool",
                        "name": name,
                        "content": result
                    })

                    # Construct function response part for the next turn
                    function_responses.append(
                        types.Part(
                            function_response=types.FunctionResponse(
                                name=name,
                                response={'result': result}
                            )
                        )
                    )

                status_callback("Analyzing tool response...")
                next_input = function_responses

        except Exception as e:
            traceback.print_exc()
            yield f"\n[Gemini Error: {str(e)}]"

    def execute_open_resource(self, target, autosave, commit_message, primary_root, safe_roots):
        """
        Executes the open_resource tool.
        """
        output_logs = []

        # Sanitize target parameter
        import urllib.parse
        import re

        # Decode percent-encoding first (e.g. %22 -> ")
        try:
            target = urllib.parse.unquote(target).strip()
        except Exception:
            pass

        # Strip surrounding quotes and extra whitespace
        target = target.strip("'\"").strip()

        # Correct protocol typos (e.g. https//, https:/, http//, http:/, https \, etc.)
        # This regex matches http or https followed by any combination of :, /, \, or spaces,
        # ensuring we don't accidentally match local files (like https_server.py)
        proto_match = re.match(r'^(https?)(?:\s*[:/\\\s]+\s*)(.*)', target, re.IGNORECASE)
        if proto_match:
            target = f"{proto_match.group(1)}://{proto_match.group(2)}"

        if autosave:
            # Stage and Commit changes if Git repo
            import subprocess
            try:
                # 1. Check if git repository
                chk_repo = subprocess.run(
                    ["git", "rev-parse", "--is-inside-work-tree"],
                    cwd=primary_root,
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if chk_repo.returncode == 0 and chk_repo.stdout.strip() == "true":
                    # 2. Check for modified / untracked files
                    status_chk = subprocess.run(
                        ["git", "status", "--porcelain"],
                        cwd=primary_root,
                        capture_output=True,
                        text=True,
                        timeout=5
                    )
                    if status_chk.returncode == 0 and status_chk.stdout.strip():
                        # There are changes, let's stage and commit
                        # Add files
                        subprocess.run(["git", "add", "-A"], cwd=primary_root, timeout=10)

                        # Generate commit message
                        import datetime
                        msg = commit_message or f"Jarvis Auto-save check-in: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"

                        # Commit
                        commit_run = subprocess.run(
                            ["git", "commit", "-m", msg],
                            cwd=primary_root,
                            capture_output=True,
                            text=True,
                            timeout=10
                        )
                        if commit_run.returncode == 0:
                            output_logs.append(f"Success: Active project modifications automatically saved (Committed as: '{msg}').")
                        else:
                            output_logs.append(f"Warning: Auto-save stage succeeded but commit failed:\n{commit_run.stderr}")
                    else:
                        output_logs.append("Info: Git workspace is clean. No auto-save commit needed.")
                else:
                    output_logs.append("Warning: Active workspace is not a git repository. Skipping git auto-save.")
            except FileNotFoundError:
                output_logs.append("Warning: Git command not found in the system. Skipping git auto-save.")
            except Exception as e:
                output_logs.append(f"Warning: Git auto-save operation failed: {str(e)}")

        # Now launch the target
        import webbrowser
        import shutil
        import subprocess

        target_lower = target.lower().strip()

        # 1. Check if Whitelisted Apps
        if target_lower in ["chrome", "google chrome"]:
            try:
                subprocess.Popen(["chrome"], start_new_session=True)
                output_logs.append("Success: Google Chrome opened.")
                return "\n".join(output_logs)
            except Exception:
                # Fallback on Windows
                try:
                    os.startfile("chrome.exe")
                    output_logs.append("Success: Google Chrome opened.")
                    return "\n".join(output_logs)
                except Exception as ex:
                    return "\n".join(output_logs + [f"Error opening Chrome: {str(ex)}"])

        elif target_lower in ["spotify"]:
            try:
                os.startfile("spotify:")
                output_logs.append("Success: Spotify opened.")
                return "\n".join(output_logs)
            except Exception as ex:
                return "\n".join(output_logs + [f"Error opening Spotify: {str(ex)}"])

        elif target_lower in ["roblox", "roblox-player"]:
            try:
                os.startfile("roblox-player:")
                output_logs.append("Success: Roblox opened.")
                return "\n".join(output_logs)
            except Exception as ex:
                return "\n".join(output_logs + [f"Error opening Roblox: {str(ex)}"])

        elif target_lower in ["code", "vs code", "vscode"]:
            # Open current project in VS Code
            code_cmd = shutil.which("code") or "code"
            try:
                subprocess.Popen([code_cmd, primary_root], shell=True, start_new_session=True)
                output_logs.append("Success: Opened current project in VS Code.")
                return "\n".join(output_logs)
            except Exception as ex:
                return "\n".join(output_logs + [f"Error launching VS Code: {str(ex)}"])

        # 2. Check if Web URL (Whitelist: http, https, and www.)
        if target_lower.startswith("http://") or target_lower.startswith("https://") or target_lower.startswith("www."):
            url = target
            if target_lower.startswith("www."):
                url = "https://" + target
            try:
                webbrowser.open(url)
                output_logs.append(f"Success: Web resource '{url}' opened in browser.")
                return "\n".join(output_logs)
            except Exception as ex:
                return "\n".join(output_logs + [f"Error opening web URL: {str(ex)}"])

        # 3. Check if Custom Whitelisted App Scheme (spotify:, roblox-player:, vscode:, mailto:, slack:, zoommtg:)
        allowed_protocols = ["spotify:", "roblox-player:", "vscode:", "vscode-insiders:", "mailto:", "slack:", "zoommtg:"]
        if any(target_lower.startswith(p) for p in allowed_protocols):
            try:
                os.startfile(target)
                output_logs.append(f"Success: Resource handler for '{target}' initiated.")
                return "\n".join(output_logs)
            except Exception as ex:
                return "\n".join(output_logs + [f"Error opening custom protocol handler: {str(ex)}"])

        # 4. Check if Target is a Directory Path (Open in VS Code if it exists and is safe)
        resolved_path = self.resolve_path(target)
        if os.path.isdir(resolved_path):
            if file_manager.is_path_safe(resolved_path, safe_roots):
                code_cmd = shutil.which("code") or "code"
                try:
                    subprocess.Popen([code_cmd, resolved_path], shell=True, start_new_session=True)
                    output_logs.append(f"Success: Opened directory '{resolved_path}' in VS Code.")
                    return "\n".join(output_logs)
                except Exception as ex:
                    return "\n".join(output_logs + [f"Error launching VS Code on path: {str(ex)}"])
            else:
                return "\n".join(output_logs + [f"Error: The folder path '{resolved_path}' is outside your authorized workspace directories."])

        # 5. Fallback/Block
        return "\n".join(output_logs + [f"Error: Target '{target}' is not a whitelisted application, safe URL, or valid directory path."])

    def execute_youtube_search(self, query, limit):
        import urllib.request
        import urllib.parse
        import re
        import json

        if not query:
            return "Error: Query parameter is empty."

        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept-Language': 'en-US,en;q=0.9'
        }
        url = f"https://www.youtube.com/results?search_query={urllib.parse.quote(query)}"
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=10) as response:
                html = response.read().decode('utf-8')

            # Find the embedded JSON object containing search results
            # YouTube might serialize this differently, so we use multiple regex options
            data_json = None
            patterns = [
                r'var ytInitialData\s*=\s*({.*?});',
                r'window\["ytInitialData"\]\s*=\s*({.*?});',
                r'ytInitialData\s*=\s*({.*?});',
                r'ytInitialData\s*=\s*({.*?\n*.*?});'
            ]
            for pattern in patterns:
                match = re.search(pattern, html)
                if match:
                    try:
                        data_json = json.loads(match.group(1))
                        break
                    except Exception:
                        continue

            if not data_json:
                # If regex fails, let's try a broader matching approach to extract the JSON block
                start_str = 'ytInitialData = '
                start_idx = html.find(start_str)
                if start_idx != -1:
                    start_idx += len(start_str)
                    # Find matching braces
                    brace_count = 0
                    json_str = ""
                    for i in range(start_idx, len(html)):
                        char = html[i]
                        if char == '{':
                            brace_count += 1
                        elif char == '}':
                            brace_count -= 1
                        json_str += char
                        if brace_count == 0 and json_str.strip().startswith('{'):
                            break
                    try:
                        # Strip trailing semicolon if present
                        if json_str.endswith(';'):
                            json_str = json_str[:-1]
                        data_json = json.loads(json_str)
                    except Exception:
                        pass

            if not data_json:
                return "Error: Could not extract search results JSON from the YouTube page."

            # A recursive function to search for all 'videoRenderer' occurrences inside the JSON structure
            # This makes the parsing immune to changes in YouTube's top-level layout hierarchies!
            def find_video_renderers(node, collected):
                if isinstance(node, dict):
                    if 'videoRenderer' in node:
                        collected.append(node['videoRenderer'])
                    else:
                        for val in node.values():
                            find_video_renderers(val, collected)
                elif isinstance(node, list):
                    for item in node:
                        find_video_renderers(item, collected)

            video_renderers = []
            find_video_renderers(data_json, video_renderers)

            if not video_renderers:
                return "Error: No video results found in the YouTube page data structure."

            videos = []
            for vr in video_renderers:
                video_id = vr.get('videoId')
                if not video_id:
                    continue
                video_url = f"https://www.youtube.com/watch?v={video_id}"

                title = "N/A"
                if 'title' in vr:
                    if 'runs' in vr['title'] and vr['title']['runs']:
                        title = vr['title']['runs'][0]['text']
                    elif 'simpleText' in vr['title']:
                        title = vr['title']['simpleText']

                channel = "N/A"
                if 'ownerText' in vr and 'runs' in vr['ownerText'] and vr['ownerText']['runs']:
                    channel = vr['ownerText']['runs'][0]['text']
                elif 'shortBylineText' in vr and 'runs' in vr['shortBylineText'] and vr['shortBylineText']['runs']:
                    channel = vr['shortBylineText']['runs'][0]['text']

                duration = "N/A"
                if 'lengthText' in vr:
                    if 'simpleText' in vr['lengthText']:
                        duration = vr['lengthText']['simpleText']
                    elif 'runs' in vr['lengthText'] and vr['lengthText']['runs']:
                        duration = vr['lengthText']['runs'][0]['text']

                videos.append({
                    "title": title,
                    "channel": channel,
                    "video_url": video_url,
                    "duration": duration
                })
                if len(videos) >= limit:
                    break

            return json.dumps(videos, indent=2, ensure_ascii=False)
        except Exception as e:
            return f"Error executing YouTube search: {str(e)}"

    def execute_media_control(self, action):
        import sys
        if sys.platform != "win32":
            return "Error: Media controls are only supported on Windows."

        import ctypes

        VK_MEDIA_NEXT_TRACK = 0xB0
        VK_MEDIA_PREV_TRACK = 0xB1
        VK_MEDIA_PLAY_PAUSE = 0xCD
        VK_VOLUME_MUTE = 0xAD
        VK_VOLUME_DOWN = 0xAE
        VK_VOLUME_UP = 0xAF

        action_map = {
            "play_pause": VK_MEDIA_PLAY_PAUSE,
            "next": VK_MEDIA_NEXT_TRACK,
            "prev": VK_MEDIA_PREV_TRACK,
            "volume_mute": VK_VOLUME_MUTE,
            "volume_down": VK_VOLUME_DOWN,
            "volume_up": VK_VOLUME_UP
        }

        vk_code = action_map.get(action)
        if not vk_code:
            return f"Error: Invalid action '{action}'."

        KEYEVENTF_EXTENDEDKEY = 0x0001
        KEYEVENTF_KEYUP = 0x0002

        try:
            scan_code = ctypes.windll.user32.MapVirtualKeyW(vk_code, 0)
            # Press key down
            ctypes.windll.user32.keybd_event(vk_code, scan_code, KEYEVENTF_EXTENDEDKEY, 0)
            # Release key up
            ctypes.windll.user32.keybd_event(vk_code, scan_code, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0)
            return f"Success: Triggered media action '{action}'."
        except Exception as e:
            return f"Error triggering media action: {str(e)}"

# A parser to strip HTML tags and extract clean textual content from webpages
class CleanTextHTMLParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.reset()
        self.fed = []
        self.in_ignored_tag = False
        self.ignored_tags = {'script', 'style', 'head', 'noscript', 'iframe', 'svg', 'link', 'meta'}

    def handle_starttag(self, tag, attrs):
        if tag in self.ignored_tags:
            self.in_ignored_tag = True

    def handle_endtag(self, tag):
        if tag in self.ignored_tags:
            self.in_ignored_tag = False

    def handle_data(self, data):
        if not self.in_ignored_tag:
            self.fed.append(data)

    def get_clean_text(self):
        raw_text = "".join(self.fed)
        lines = []
        for line in raw_text.splitlines():
            cleaned = line.strip()
            if cleaned:
                # Normalize spaces inside line
                cleaned = " ".join(cleaned.split())
                lines.append(cleaned)
        return "\n".join(lines)

    def execute_get_active_browser_info(self):
        import sys
        import time
        import ctypes
        from ctypes import wintypes

        if sys.platform != "win32":
            return json.dumps({
                "error": "This tool is only supported on Windows.",
                "active_window_title": "Unsupported Platform",
                "url": ""
            })

        # Windows ctypes structures
        GetForegroundWindow = ctypes.windll.user32.GetForegroundWindow
        GetForegroundWindow.argtypes = []
        GetForegroundWindow.restype = wintypes.HWND

        GetWindowTextLengthW = ctypes.windll.user32.GetWindowTextLengthW
        GetWindowTextLengthW.argtypes = [wintypes.HWND]
        GetWindowTextLengthW.restype = ctypes.c_int

        GetWindowTextW = ctypes.windll.user32.GetWindowTextW
        GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        GetWindowTextW.restype = ctypes.c_int

        VK_CONTROL = 0x11
        VK_L = 0x4C
        VK_C = 0x43
        VK_ESCAPE = 0x1B
        KEYEVENTF_KEYUP = 0x0002

        def press_key(vk_code):
            ctypes.windll.user32.keybd_event(vk_code, 0, 0, 0)

        def release_key(vk_code):
            ctypes.windll.user32.keybd_event(vk_code, 0, KEYEVENTF_KEYUP, 0)

        OpenClipboard = ctypes.windll.user32.OpenClipboard
        OpenClipboard.argtypes = [wintypes.HWND]
        OpenClipboard.restype = wintypes.BOOL

        CloseClipboard = ctypes.windll.user32.CloseClipboard
        CloseClipboard.argtypes = []
        CloseClipboard.restype = wintypes.BOOL

        EmptyClipboard = ctypes.windll.user32.EmptyClipboard
        EmptyClipboard.argtypes = []
        EmptyClipboard.restype = wintypes.BOOL

        GetClipboardData = ctypes.windll.user32.GetClipboardData
        GetClipboardData.argtypes = [wintypes.UINT]
        GetClipboardData.restype = wintypes.HANDLE

        GlobalLock = ctypes.windll.kernel32.GlobalLock
        GlobalLock.argtypes = [wintypes.HGLOBAL]
        GlobalLock.restype = ctypes.c_void_p

        GlobalUnlock = ctypes.windll.kernel32.GlobalUnlock
        GlobalUnlock.argtypes = [wintypes.HGLOBAL]
        GlobalUnlock.restype = wintypes.BOOL

        CF_UNICODETEXT = 13

        def get_active_window_title():
            hwnd = GetForegroundWindow()
            if not hwnd:
                return "Unknown"
            length = GetWindowTextLengthW(hwnd)
            if length == 0:
                return ""
            buf = ctypes.create_unicode_buffer(length + 1)
            GetWindowTextW(hwnd, buf, length + 1)
            return buf.value

        def get_clipboard_text():
            if not OpenClipboard(None):
                return ""
            try:
                handle = GetClipboardData(CF_UNICODETEXT)
                if not handle:
                    return ""
                ptr = GlobalLock(handle)
                if not ptr:
                    return ""
                text = ctypes.c_wchar_p(ptr).value
                GlobalUnlock(handle)
                return text or ""
            except Exception:
                return ""
            finally:
                CloseClipboard()

        def clear_clipboard():
            if OpenClipboard(None):
                try:
                    EmptyClipboard()
                except Exception:
                    pass
                finally:
                    CloseClipboard()

        try:
            title = get_active_window_title()
            title_lower = title.lower()
            browsers = ["chrome", "edge", "firefox", "brave", "opera", "browser", "safari", "vivaldi", "arc"]
            is_browser = any(b in title_lower for b in browsers)

            if not is_browser:
                return json.dumps({
                    "active_window_title": title,
                    "url": "",
                    "is_browser": False,
                    "message": "Active window is not identified as a browser."
                }, ensure_ascii=False)

            # Clear clipboard to avoid capturing old clipboard data
            clear_clipboard()

            # Simulate Ctrl+L to focus address bar
            press_key(VK_CONTROL)
            time.sleep(0.05)
            press_key(VK_L)
            time.sleep(0.05)
            release_key(VK_L)
            time.sleep(0.05)
            release_key(VK_CONTROL)
            time.sleep(0.15)  # Wait for address bar focus

            # Simulate Ctrl+C to copy
            press_key(VK_CONTROL)
            time.sleep(0.05)
            press_key(VK_C)
            time.sleep(0.05)
            release_key(VK_C)
            time.sleep(0.05)
            release_key(VK_CONTROL)

            # Poll clipboard for updates (up to 0.3s)
            url = ""
            for _ in range(6):
                time.sleep(0.05)
                val = get_clipboard_text().strip()
                if val:
                    url = val
                    break

            # Simulate Esc to unfocus address bar
            press_key(VK_ESCAPE)
            time.sleep(0.05)
            release_key(VK_ESCAPE)

            is_valid_url = url.startswith(("http://", "https://", "ftp://", "file://")) or ("." in url and "/" in url and " " not in url)

            return json.dumps({
                "active_window_title": title,
                "url": url if is_valid_url else "",
                "is_browser": True,
                "raw_copied_text": url if not is_valid_url else None
            }, ensure_ascii=False)

        except Exception as e:
            return json.dumps({
                "error": f"Failed to retrieve browser info: {str(e)}",
                "active_window_title": "Error",
                "url": ""
            })

    def execute_read_webpage_summary(self, url):
        if not url.startswith(("http://", "https://")):
            url = "https://" + url

        # Google Docs specific bypass using browser automation
        if "docs.google.com/document" in url:
            try:
                # Start browser session in headless mode
                self.browser_manager.start_session(headless=True)
                page = self.browser_manager.get_active_page()
                page.goto(url)

                # Wait for Google Docs to render contents
                try:
                    page.wait_for_selector(".kix-paragraph-renderer", timeout=12000)
                except Exception:
                    # Fallback to waiting for body if it is in view-only mode or slow
                    page.wait_for_selector("body", timeout=5000)

                # Extract text using DOM elements
                text = page.evaluate("""() => {
                    const paragraphs = Array.from(document.querySelectorAll('.kix-paragraph-renderer'));
                    if (paragraphs.length > 0) {
                        return paragraphs.map(p => p.innerText).join('\\n');
                    }
                    const editor = document.querySelector('.kix-app-view-web') || document.querySelector('#docs-editor');
                    if (editor) return editor.innerText;
                    return document.body.innerText;
                }""")

                if not text.strip():
                    return "Error: Document content is empty or could not be retrieved."

                return text
            except Exception as e:
                return f"Error reading Google Doc via browser automation: {str(e)}"

        try:
            import requests
            has_requests = True
        except ImportError:
            has_requests = False

        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,application/pdf;q=0.8,*/*;q=0.8'
        }

        is_pdf = url.lower().split('?')[0].endswith('.pdf')
        content_bytes = None
        html_content = ""

        try:
            if has_requests:
                response = requests.get(url, headers=headers, timeout=15)
                response.raise_for_status()
                content_type = response.headers.get('Content-Type', '').lower()
                if 'application/pdf' in content_type or is_pdf:
                    is_pdf = True
                    content_bytes = response.content
                else:
                    if response.encoding is None or response.encoding == 'ISO-8859-1':
                        response.encoding = response.apparent_encoding
                    html_content = response.text
            else:
                import urllib.request
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=15) as response:
                    content_type = response.info().get_content_type().lower()
                    if 'application/pdf' in content_type or is_pdf:
                        is_pdf = True
                        content_bytes = response.read()
                    else:
                        charset = response.info().get_content_charset() or 'utf-8'
                        html_content = response.read().decode(charset, errors='replace')
        except Exception as e:
            return f"Error downloading webpage: {str(e)}"

        # If it is a PDF file, parse it using pypdf directly from memory
        if is_pdf:
            try:
                import pypdf
                import io
            except ImportError:
                return (
                    "Error: The 'pypdf' library is required to read PDF files. "
                    "Please make sure it is installed, or update requirements.txt."
                )
            try:
                stream = io.BytesIO(content_bytes)
                reader = pypdf.PdfReader(stream)
                text_parts = []
                for i, page in enumerate(reader.pages):
                    page_text = page.extract_text()
                    if page_text:
                        text_parts.append(f"--- Page {i + 1} ---\n{page_text}")
                if not text_parts:
                    return "Warning: No text could be extracted from this PDF. It might consist of scanned images or be empty."
                return "\n\n".join(text_parts)
            except Exception as e:
                return f"Error reading PDF file from URL: {str(e)}"

        try:
            parser = CleanTextHTMLParser()
            parser.feed(html_content)
            cleaned_text = parser.get_clean_text()

            if not cleaned_text.strip():
                return "Error: Webpage content is empty after stripping HTML tags."

            return cleaned_text
        except Exception as e:
            return f"Error parsing webpage: {str(e)}"

