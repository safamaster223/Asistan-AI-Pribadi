import sys
import threading
import queue
import re
import os
import asyncio

class TTSWorker(threading.Thread):
    def __init__(self, tts_queue):
        super().__init__()
        self.tts_queue = tts_queue
        self.daemon = True
        self._voice_engine = None
        self._com_initialized = False
        self._edge_tts_available = False
        self._check_edge_tts()

    def _check_edge_tts(self):
        try:
            import edge_tts
            import pygame
            self._edge_tts_available = True
            pygame.mixer.init()
            print("TTS Worker: edge-tts and pygame are available for Neural Voice.")
        except ImportError:
            print("TTS Worker: edge-tts or pygame not installed. Falling back to SAPI5.")
            self._edge_tts_available = False

    async def _generate_and_play_edge(self, text):
        import edge_tts
        import pygame
        import tempfile
        
        # Use Indonesian female neural voice
        voice = "id-ID-GadisNeural"
        
        # Create a temporary file for the audio
        temp_dir = tempfile.gettempdir()
        output_file = os.path.join(temp_dir, "cellya_tts_temp.mp3")
        
        communicate = edge_tts.Communicate(text, voice)
        await communicate.save(output_file)
        
        # Play the audio using pygame
        try:
            if pygame.mixer.music.get_busy():
                pygame.mixer.music.stop()
            pygame.mixer.music.load(output_file)
            pygame.mixer.music.play()
            
            # Wait for playback to finish
            while pygame.mixer.music.get_busy():
                await asyncio.sleep(0.1)
                
            # Unload music so file can be overwritten next time
            pygame.mixer.music.unload()
        except Exception as e:
            print(f"Error playing Edge TTS audio: {e}")

    def run(self):
        while True:
            try:
                task = self.tts_queue.get()
                if task is None:
                    try:
                        self.tts_queue.task_done()
                    except ValueError:
                        pass
                    break

                action, text = task

                if action == "speak":
                    if self._edge_tts_available:
                        # Run Edge TTS via asyncio event loop
                        asyncio.run(self._generate_and_play_edge(text))
                    else:
                        # Fallback to SAPI5 logic
                        if not self._com_initialized:
                            if sys.platform == "win32":
                                try:
                                    import win32com.client
                                    import pythoncom

                                    try:
                                        pythoncom.CoInitializeEx(pythoncom.COINIT_MULTITHREADED)
                                    except Exception:
                                        pythoncom.CoInitialize()

                                    self._voice_engine = win32com.client.Dispatch("SAPI.SpVoice")
                                    self._com_initialized = True
                                except Exception as e:
                                    print(f"TTS Worker failed to initialize SAPI5: {e}")

                        if self._com_initialized and self._voice_engine:
                            try:
                                self._voice_engine.Speak(text, 1 | 2)
                            except Exception as e:
                                print(f"TTS speak exception: {e}")

                elif action == "stop":
                    if self._edge_tts_available:
                        try:
                            import pygame
                            if pygame.mixer.music.get_busy():
                                pygame.mixer.music.stop()
                        except Exception as e:
                            print(f"Error stopping Edge TTS: {e}")
                    else:
                        if self._com_initialized and self._voice_engine:
                            try:
                                self._voice_engine.Speak("", 2)
                            except Exception as e:
                                print(f"TTS stop exception: {e}")

                self.tts_queue.task_done()
            except Exception as e:
                print(f"TTS Worker loop error: {e}")
                try:
                    self.tts_queue.task_done()
                except ValueError:
                    pass

class TTSManager:
    def __init__(self):
        self.tts_queue = queue.Queue()
        self.worker = None
        if sys.platform == "win32":
            self.worker = TTSWorker(self.tts_queue)
            self.worker.start()

    def speak(self, text):
        if sys.platform != "win32":
            return

        clean_text = self.clean_markdown(text)
        if not clean_text:
            return

        self.tts_queue.put(("speak", clean_text))

    def stop(self):
        if sys.platform != "win32":
            return
        self.tts_queue.put(("stop", ""))

    def clean_markdown(self, text):
        if not text:
            return ""
        text = re.sub(r'[*_`]', '', text)
        text = re.sub(r'```.*?```', '[code block]', text, flags=re.DOTALL)
        text = re.sub(r'\[(.*?)\]\(.*?\)', r'\1', text)
        text = re.sub(r'https?://\S+', '', text)
        text = re.sub(r'<[^>]*>', '', text)
        return text.strip()
