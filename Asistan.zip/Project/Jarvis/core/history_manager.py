import os
import json
import datetime

HISTORY_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.dirname(__file__)), "history"))
MAX_HISTORY_SIZE = 5 * 1024 * 1024 * 1024  # 5 GB in bytes

def ensure_history_dir():
    os.makedirs(HISTORY_DIR, exist_ok=True)

def load_sessions():
    """
    Loads all saved session metadata sorted by modification time (newest first).
    """
    ensure_history_dir()
    sessions = []
    for filename in os.listdir(HISTORY_DIR):
        if filename.startswith("session_") and filename.endswith(".json"):
            filepath = os.path.join(HISTORY_DIR, filename)
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    sessions.append({
                        "session_id": data.get("session_id"),
                        "title": data.get("title", "Untitled Chat"),
                        "created_at": data.get("created_at"),
                        "filepath": filepath,
                        "modified_time": os.path.getmtime(filepath)
                    })
            except Exception as e:
                print(f"Error loading session file {filename}: {e}")

    # Sort by modified_time descending (newest first)
    sessions.sort(key=lambda x: x["modified_time"], reverse=True)
    return sessions

def load_session_messages(session_id):
    """
    Loads the messages of a specific session.
    """
    ensure_history_dir()
    filepath = os.path.join(HISTORY_DIR, f"session_{session_id}.json")
    if os.path.exists(filepath):
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data.get("messages", [])
        except Exception as e:
            print(f"Error reading session {session_id}: {e}")
    return []

def save_session(session_id, title, messages, files=None):
    """
    Saves or updates a chat session JSON.
    Then prunes the history folder if it exceeds 5GB.
    """
    ensure_history_dir()
    filepath = os.path.join(HISTORY_DIR, f"session_{session_id}.json")

    # Create or load existing to preserve creation time if updating
    if os.path.exists(filepath):
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception:
            data = {}
    else:
        data = {}

    data["session_id"] = session_id
    # Default title to first user message if title is not specified or generic
    if not title or title == "Untitled Chat":
        for msg in messages:
            if msg.get("role") == "user":
                content = msg.get("content", "")
                if isinstance(content, list):
                    text_parts = [part["text"] for part in content if part.get("type") == "text"]
                    title = " ".join(text_parts)[:40]
                else:
                    title = str(content)[:40]
                break
        if not title:
            title = "Untitled Chat"

    data["title"] = title
    if "created_at" not in data:
        data["created_at"] = datetime.datetime.now().isoformat()
    data["messages"] = messages
    if files is not None:
        data["files"] = files

    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        # Enforce history limit size after writing
        prune_history()
        return True
    except Exception as e:
        print(f"Failed to save session {session_id}: {e}")
        return False

def delete_session(session_id):
    """
    Deletes the session JSON file.
    """
    filepath = os.path.join(HISTORY_DIR, f"session_{session_id}.json")
    if os.path.exists(filepath):
        try:
            os.remove(filepath)
            return True
        except Exception as e:
            print(f"Error deleting session {session_id}: {e}")
    return False

def get_history_folder_size():
    """
    Calculates the total size of files inside the history directory.
    """
    total_size = 0
    if not os.path.exists(HISTORY_DIR):
        return 0
    for filename in os.listdir(HISTORY_DIR):
        fp = os.path.join(HISTORY_DIR, filename)
        if os.path.isfile(fp):
            total_size += os.path.getsize(fp)
    return total_size

def prune_history():
    """
    Auto-deletes the oldest session files if the history directory exceeds 5GB.
    """
    if get_history_folder_size() <= MAX_HISTORY_SIZE:
        return

    sessions = load_sessions()
    # Sort by modified_time ascending (oldest first)
    sessions.sort(key=lambda x: x["modified_time"])

    for s in sessions:
        if get_history_folder_size() <= MAX_HISTORY_SIZE:
            break
        print(f"Pruning oldest session file: {s['filepath']}")
        try:
            os.remove(s["filepath"])
        except Exception as e:
            print(f"Error pruning session: {e}")
