import os
import json
from datetime import datetime

USAGE_FILE = os.path.abspath(os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "usage_stats.json"))

class UsageTracker:
    @staticmethod
    def load_stats():
        """
        Loads stats from config/usage_stats.json. Resets stats if the date has changed.
        """
        today_str = datetime.now().strftime("%Y-%m-%d")
        default_stats = {
            "date": today_str,
            "groq": {
                "requests": 0,
                "tokens": 0
            },
            "gemini": {
                "requests": 0,
                "tokens": 0
            },
            "gravity": {
                "requests": 0,
                "tokens": 0
            }
        }

        if not os.path.exists(USAGE_FILE):
            os.makedirs(os.path.dirname(USAGE_FILE), exist_ok=True)
            UsageTracker.save_stats(default_stats)
            return default_stats

        try:
            with open(USAGE_FILE, "r") as f:
                stats = json.load(f)
        except Exception:
            stats = default_stats

        # Check if new day
        if stats.get("date") != today_str:
            stats = default_stats
            UsageTracker.save_stats(stats)

        return stats

    @staticmethod
    def save_stats(stats):
        try:
            with open(USAGE_FILE, "w") as f:
                json.dump(stats, f, indent=2)
        except Exception as e:
            print(f"Failed to save usage stats: {e}")

    @staticmethod
    def increment(provider, tokens=0):
        stats = UsageTracker.load_stats()

        if provider in stats:
            stats[provider]["requests"] += 1
            stats[provider]["tokens"] += tokens
            UsageTracker.save_stats(stats)
