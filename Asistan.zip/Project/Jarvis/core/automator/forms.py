import re

class FormsParser:
    def __init__(self, page):
        self.page = page

    def parse_form(self, url):
        """
        Navigates to the Google Forms URL, extracts questions, choices,
        inputs, and required states, and formats them into a clean JSON structure.
        """
        if not url.startswith("http"):
            url = "https://" + url

        try:
            self.page.goto(url)
            # Wait for form container to load
            self.page.wait_for_selector("form", timeout=12000)
        except Exception:
            return "Error: Timed out waiting for Google Form to load. Verify the link is valid."

        # Parse Form Title
        title_element = self.page.query_selector("div[role='heading']")
        if not title_element:
            title_element = self.page.query_selector(".F9yp7") # Common class for forms header title
        form_title = title_element.inner_text().strip() if title_element else "Google Form Quiz"

        # Parse Question Cards
        # GCR Forms wrap questions inside div[role="listitem"]
        cards = self.page.query_selector_all("div[role='listitem']")
        if not cards:
            # Fallback selector
            cards = self.page.query_selector_all(".geS5ne")

        questions = []
        for index, card in enumerate(cards):
            # Parse Question text
            heading_elem = card.query_selector("div[role='heading']")
            if not heading_elem:
                heading_elem = card.query_selector(".M7eMe")

            if not heading_elem:
                continue

            question_text = heading_elem.inner_text().strip()

            # Check if required
            # GCR shows an asterisk * for required questions, or checks aria-required
            required_indicator = card.query_selector(".d7EDFe") # required star class
            is_required = required_indicator is not None

            # Clean asterisk from question text if present
            if question_text.endswith("*"):
                question_text = question_text[:-1].strip()

            # Determine Question Type and Options
            options = []
            q_type = "short_answer"

            # 1. Multiple Choice (Radio Buttons)
            radio_buttons = card.query_selector_all("div[role='radio']")
            if radio_buttons:
                q_type = "multiple_choice"
                for rb in radio_buttons:
                    opt_text = rb.get_attribute("aria-label") or rb.inner_text().strip()
                    if opt_text:
                        options.append(opt_text)

            # 2. Checkboxes
            elif card.query_selector_all("div[role='checkbox']"):
                q_type = "checkboxes"
                checkbox_elements = card.query_selector_all("div[role='checkbox']")
                for cb in checkbox_elements:
                    opt_text = cb.get_attribute("aria-label") or cb.inner_text().strip()
                    if opt_text:
                        options.append(opt_text)

            # 3. Dropdown Selector
            elif card.query_selector("div[role='listbox']"):
                q_type = "dropdown"
                # Click dropdown to load options
                try:
                    dropdown = card.query_selector("div[role='listbox']")
                    dropdown.click()
                    self.page.wait_for_timeout(300)
                    option_elements = self.page.query_selector_all("div[role='option']")
                    for opt in option_elements:
                        opt_text = opt.inner_text().strip()
                        # Skip placeholder instructions like "Choose"
                        if opt_text and opt_text.lower() not in ["choose", "pilih"]:
                            options.append(opt_text)
                    # Close dropdown
                    dropdown.click()
                except Exception:
                    options = []

            # 4. Long Answer / Paragraph
            elif card.query_selector("textarea"):
                q_type = "paragraph"

            # 5. Short Answer
            elif card.query_selector("input[type='text']"):
                q_type = "short_answer"

            questions.append({
                "number": len(questions) + 1,
                "text": question_text,
                "type": q_type,
                "required": is_required,
                "options": options if options else None
            })

        return {
            "title": form_title,
            "url": url,
            "total_questions": len(questions),
            "questions": questions
        }
