import os
import socket
import subprocess
import time
import winreg
from playwright.sync_api import sync_playwright

class BrowserManager:
    def __init__(self, port=9222, profile_directory="Default"):
        self.port = port
        self.user_data_dir = self._get_user_data_path()
        self.chrome_path = self._get_chrome_path()
        self.profile_directory = self._resolve_profile_directory(profile_directory)
        self.playwright = None
        self.browser = None
        self.context = None
        self.chrome_process = None  # Tracks the spawned Chrome subprocess

    def _resolve_profile_directory(self, input_profile):
        """
        Resolves an input profile name (which can be a folder name like 'Profile 3'
        or a human-readable display name like 'Your Chrome') to the actual folder name on disk.
        """
        if not input_profile:
            return "Default"

        # 1. If it already exists as a physical directory containing Preferences, use it directly.
        direct_path = os.path.join(self.user_data_dir, input_profile)
        if os.path.isdir(direct_path) and os.path.exists(os.path.join(direct_path, "Preferences")):
            return input_profile

        # 2. Otherwise, scan all folders to find a profile name match
        import json
        if not os.path.exists(self.user_data_dir):
            return "Default"

        try:
            target_lower = input_profile.lower().strip()
            for item in os.listdir(self.user_data_dir):
                item_path = os.path.join(self.user_data_dir, item)
                if os.path.isdir(item_path):
                    pref_path = os.path.join(item_path, "Preferences")
                    if os.path.exists(pref_path):
                        try:
                            with open(pref_path, "r", encoding="utf-8") as f:
                                pref_data = json.load(f)
                                profile_name = pref_data.get("profile", {}).get("name")
                                if profile_name:
                                    profile_name_clean = profile_name.strip().lower()
                                    # Exact match or substring match
                                    if target_lower == profile_name_clean or target_lower in profile_name_clean:
                                        print(f"Profile Resolution: Resolved '{input_profile}' to folder '{item}' ('{profile_name}')")
                                        return item
                        except Exception:
                            pass
        except Exception as e:
            print(f"Error during profile resolution: {e}")

        print(f"Profile Resolution Warning: Could not resolve profile '{input_profile}'. Defaulting to 'Default'.")
        return "Default"

    def _get_user_data_path(self):
        """
        Resolves Windows Chrome User Data directory.
        """
        local_app_data = os.environ.get("LOCALAPPDATA")
        if not local_app_data:
            # Fallback if env var missing
            local_app_data = os.path.join(os.path.expanduser("~"), "AppData", "Local")
        return os.path.join(local_app_data, "Google", "Chrome", "User Data")

    def _get_chrome_path(self):
        """
        Scans Windows registry or program folders to locate the chrome.exe path.
        """
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe")
            path, _ = winreg.QueryValueEx(key, "")
            winreg.CloseKey(key)
            if os.path.exists(path):
                return path
        except Exception:
            pass

        # Fallback common installations paths
        common_paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe")
        ]
        for p in common_paths:
            if os.path.exists(p):
                return p
        return None

    def get_available_profiles(self):
        """
        Lists all valid Chrome profile directories in the User Data directory.
        A directory is considered a profile if it contains a 'Preferences' file.
        """
        import json
        if not os.path.exists(self.user_data_dir):
            return []

        profiles = []
        try:
            for item in os.listdir(self.user_data_dir):
                item_path = os.path.join(self.user_data_dir, item)
                if os.path.isdir(item_path):
                    pref_path = os.path.join(item_path, "Preferences")
                    if os.path.exists(pref_path):
                        display_name = item
                        try:
                            # Try to extract the human-readable profile name from Preferences JSON
                            with open(pref_path, "r", encoding="utf-8") as f:
                                pref_data = json.load(f)
                                profile_name = pref_data.get("profile", {}).get("name")
                                if profile_name:
                                    display_name = f"{item} ('{profile_name}')"
                        except Exception:
                            pass
                        profiles.append(display_name)
        except Exception as e:
            print(f"Diagnostics: Error scanning Chrome User Data directory for profiles: {e}")

        return sorted(profiles)

    def is_debug_port_open(self):
        """
        Checks if remote debugging port is open.
        """
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            return s.connect_ex(("127.0.0.1", self.port)) == 0

    def is_chrome_process_running(self):
        """
        Detects if chrome.exe is active in system processes.
        """
        try:
            import psutil
            for proc in psutil.process_iter(['name']):
                if proc.info['name'] and proc.info['name'].lower() == 'chrome.exe':
                    return True
            return False
        except ImportError:
            # Fallback using tasklist
            try:
                res = subprocess.run(
                    ["tasklist", "/FI", "IMAGENAME eq chrome.exe"],
                    capture_output=True,
                    text=True,
                    shell=True,
                    timeout=5
                )
                return "chrome.exe" in res.stdout
            except Exception:
                return False

    def _cleanup_zombie_processes(self, target_dir_substring):
        """
        Finds and terminates any orphaned/zombie Chrome processes that were launched
        with the specified target user data directory to release directory locks.
        """
        try:
            import psutil
            target_substring_lower = target_dir_substring.lower().replace("/", "\\")
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if proc.info['name'] and proc.info['name'].lower() == 'chrome.exe':
                        cmdline = proc.info['cmdline']
                        if cmdline:
                            cmdline_str = " ".join(cmdline).lower().replace("/", "\\")
                            if target_substring_lower in cmdline_str:
                                print(f"Terminating zombie Chrome process (PID: {proc.info['pid']}) holding '{target_dir_substring}'...")
                                proc.terminate()
                                try:
                                    proc.wait(timeout=1.0)
                                except psutil.TimeoutExpired:
                                    proc.kill()
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    pass
        except Exception as e:
            print(f"Error during zombie process cleanup: {e}")

    def start_session(self, headless=False):
        """
        Orchestrates session login sharing. Connects via CDP if open,
        launches instance if closed, or falls back to an isolated profile if blocked.
        """
        if self.context:
            return "Browser context is already active."

        # Detect active user data directory and profile
        active_user_data_dir = self.user_data_dir
        active_profile = self.profile_directory

        if self.is_chrome_process_running():
            fallback_user_data_dir = os.path.join(os.path.dirname(self.user_data_dir), "User Data Jarvis")
            print(f"Google Chrome is running. Falling back from '{active_profile}' to isolated user data directory '{fallback_user_data_dir}' to avoid lock.")
            active_user_data_dir = fallback_user_data_dir
            active_profile = "Default"

            # Clean up any zombie processes holding this fallback user data directory
            self._cleanup_zombie_processes("User Data Jarvis")
            time.sleep(0.5)  # Give Windows filesystem locks a brief moment to completely release
            os.makedirs(active_user_data_dir, exist_ok=True)
        else:
            # 0. Check User Data directory existence and profile folder existence
            if not os.path.exists(self.user_data_dir):
                raise FileNotFoundError(
                    f"Chrome User Data directory does not exist at expected path:\n"
                    f" '{self.user_data_dir}'\n\n"
                    f"Please ensure Google Chrome is installed and has been run at least once."
                )

            if active_profile:
                profile_path = os.path.join(self.user_data_dir, active_profile)
                if not os.path.exists(profile_path):
                    # Gather details of existing profiles for diagnosis
                    available_profiles = self.get_available_profiles()
                    available_str = "\n".join([f" - {p}" for p in available_profiles]) if available_profiles else " None found."
                    raise FileNotFoundError(
                        f"Configured Chrome profile directory '{active_profile}' does not exist "
                        f"under user data directory:\n '{self.user_data_dir}'\n\n"
                        f"Available Chrome profiles found:\n{available_str}\n\n"
                        f"Please update 'chrome_profile_directory' in your settings.json or config."
                    )

        # 1. Connect via CDP if debugging port is already open
        if self.is_debug_port_open():
            try:
                self.playwright = sync_playwright().start()
                self.browser = self.playwright.chromium.connect_over_cdp(f"http://127.0.0.1:{self.port}")
                if self.browser.contexts:
                    self.context = self.browser.contexts[0]
                else:
                    self.context = self.browser.new_context()
                return f"Connected to active Google Chrome session via CDP (Port {self.port})."
            except Exception as e:
                # If CDP fails to connect, fallback to relaunching
                print(f"CDP connection failed: {e}")
                if self.playwright:
                    self.playwright.stop()
                    self.playwright = None

        self.playwright = sync_playwright().start()

        # 3. Launch Chrome via subprocess.Popen and connect Playwright via connect_over_cdp
        if not self.chrome_path or not os.path.exists(self.chrome_path):
            self.playwright.stop()
            self.playwright = None
            raise FileNotFoundError("Google Chrome executable (chrome.exe) could not be located on this machine.")

        try:
            launch_args = [
                self.chrome_path,
                f"--remote-debugging-port={self.port}",
                f"--user-data-dir={active_user_data_dir}"
            ]
            if active_profile:
                launch_args.append(f"--profile-directory={active_profile}")
            if headless:
                # Add headless, performance, and stability flags for Windows to prevent startup hangs
                launch_args.extend([
                    "--headless=new",
                    "--disable-gpu",
                    "--disable-software-rasterizer",
                    "--disable-extensions",
                    "--no-first-run",
                    "--no-default-browser-check"
                ])

            # Spawn Chrome via Popen without blocking or hiding the window
            self.chrome_process = subprocess.Popen(
                launch_args,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0
            )
        except Exception as e:
            if self.playwright:
                self.playwright.stop()
                self.playwright = None
            raise RuntimeError(f"Failed to spawn Chrome subprocess: {str(e)}")

        # Poll the debugging port to verify it has opened successfully
        # Increased to 15 seconds to allow headless Chrome to generate profile assets on Windows safely
        port_ready = False
        for _ in range(150):  # Wait up to 15 seconds
            if self.is_debug_port_open():
                port_ready = True
                break
            time.sleep(0.1)

        if not port_ready:
            # Clean up the process if the port failed to open
            try:
                self.chrome_process.terminate()
            except Exception:
                pass
            self.chrome_process = None
            if self.playwright:
                self.playwright.stop()
                self.playwright = None
            raise RuntimeError(f"Chrome spawned but remote debugging port {self.port} did not open within 15 seconds.")

        # Connect Playwright to the newly opened port
        try:
            self.browser = self.playwright.chromium.connect_over_cdp(f"http://127.0.0.1:{self.port}")
            if self.browser.contexts:
                self.context = self.browser.contexts[0]
            else:
                self.context = self.browser.new_context()
            return f"Successfully launched new Chrome session and connected via CDP with profile '{active_profile}'."
        except Exception as e:
            # Clean up the process if connection failed
            try:
                self.chrome_process.terminate()
            except Exception:
                pass
            self.chrome_process = None
            if self.playwright:
                self.playwright.stop()
                self.playwright = None
            raise RuntimeError(f"Failed to connect to the spawned Chrome instance over CDP: {str(e)}")

    def get_active_page(self):
        """
        Retrieves the foremost active page or creates a new one in the context.
        """
        if not self.context:
            self.start_session()
        pages = self.context.pages
        if pages:
            return pages[0]
        return self.context.new_page()

    def close(self):
        """
        Terminates the Playwright session and closes pages safely.
        """
        if self.context:
            try:
                self.context.close()
            except Exception:
                pass
            self.context = None

        if self.browser:
            try:
                self.browser.close()
            except Exception:
                pass
            self.browser = None

        if self.playwright:
            try:
                self.playwright.stop()
            except Exception:
                pass
            self.playwright = None

        # Terminate Chrome subprocess if we started it
        if hasattr(self, "chrome_process") and self.chrome_process:
            try:
                self.chrome_process.terminate()
                self.chrome_process.wait(timeout=2)
            except Exception:
                try:
                    self.chrome_process.kill()
                except Exception:
                    pass
            self.chrome_process = None
