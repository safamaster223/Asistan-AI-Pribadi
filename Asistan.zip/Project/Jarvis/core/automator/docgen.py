import csv
import os

class DocumentGenerator:
    def write(self, fmt, path, data):
        """
        Routes the document generation requests based on the selected format (docx, pdf, csv, xlsx, pptx).
        """
        fmt = fmt.lower().strip()
        os.makedirs(os.path.dirname(path), exist_ok=True)

        if fmt == "docx":
            return self._write_docx(path, data)
        elif fmt == "csv":
            return self._write_csv(path, data)
        elif fmt == "xlsx":
            return self._write_xlsx(path, data)
        elif fmt == "pptx":
            return self._write_pptx(path, data)
        elif fmt == "pdf":
            return self._write_pdf(path, data)
        else:
            return f"Error: Unknown document format '{fmt}'."

    def _write_docx(self, path, data):
        """
        Writes structured sections, text, and tables to a Microsoft Word .docx file with professional styling.
        """
        try:
            from docx import Document
            from docx.shared import Pt, Inches, RGBColor
            from docx.enum.text import WD_ALIGN_PARAGRAPH
            from docx.oxml import OxmlElement, parse_xml
            from docx.oxml.ns import nsdecls, qn
        except ImportError:
            fallback_path = path.replace(".docx", ".txt")
            try:
                with open(fallback_path, 'w', encoding='utf-8') as f:
                    f.write(f"=== {data.get('title', 'Document Title')} ===\n\n")
                    sections = data.get("sections", {})
                    if isinstance(sections, dict):
                        for heading, content in sections.items():
                            f.write(f"[{heading}]\n")
                            if isinstance(content, dict) and content.get("type") == "table":
                                headers = content.get("headers", [])
                                rows = content.get("rows", [])
                                f.write(" | ".join(map(str, headers)) + "\n")
                                f.write("-" * 30 + "\n")
                                for r in rows:
                                    f.write(" | ".join(map(str, r)) + "\n")
                            else:
                                f.write(f"{content}\n")
                            f.write("\n")
                return f"Warning: 'python-docx' library is not installed. Saved as clean text to: {fallback_path}"
            except Exception as ex:
                return f"Error creating fallback text document: {str(ex)}"

        try:
            doc = Document()

            # 1. Set Page Margins to standard academic margins (Left: 4cm, Top: 3cm, Right: 3cm, Bottom: 3cm)
            # Standard: Left 1.57 inches (~4cm), Top 1.18 inches (~3cm), Right 1.18 inches (~3cm), Bottom 1.18 inches (~3cm)
            sections_list = doc.sections
            for section in sections_list:
                section.top_margin = Inches(1.18)
                section.bottom_margin = Inches(1.18)
                section.left_margin = Inches(1.57)
                section.right_margin = Inches(1.18)

            # Helper to style a run to Times New Roman
            def set_run_font(run, name="Times New Roman", size=12, bold=False, italic=False, color_rgb=None):
                run.font.name = name
                run.font.size = Pt(size)
                run.bold = bold
                run.italic = italic
                if color_rgb:
                    run.font.color.rgb = color_rgb
                # Ensure compatibility for Windows/Word rendering
                rPr = run._r.get_or_add_rPr()
                rFonts = OxmlElement('w:rFonts')
                rFonts.set(qn('w:ascii'), name)
                rFonts.set(qn('w:hAnsi'), name)
                rFonts.set(qn('w:cs'), name)
                rPr.append(rFonts)

            # Helper to add a paragraph with standard line spacing and spacing after
            def add_styled_paragraph(doc, text="", style='Normal', space_after=6, line_spacing=1.5, align=WD_ALIGN_PARAGRAPH.LEFT):
                p = doc.add_paragraph(style=style)
                p.alignment = align
                p.paragraph_format.space_after = Pt(space_after)
                p.paragraph_format.line_spacing = line_spacing
                if text:
                    run = p.add_run(text)
                    set_run_font(run)
                return p

            # 2. Document Title
            title_text = data.get("title", "Cellya Claire Output Report")
            p_title = doc.add_paragraph()
            p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p_title.paragraph_format.space_after = Pt(18)
            r_title = p_title.add_run(title_text)
            set_run_font(r_title, size=16, bold=True, color_rgb=RGBColor(15, 23, 42))

            # 3. Subtitle / Metadata
            subtitle_text = data.get("subtitle")
            if subtitle_text:
                p_sub = doc.add_paragraph()
                p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
                p_sub.paragraph_format.space_after = Pt(24)
                r_sub = p_sub.add_run(subtitle_text)
                set_run_font(r_sub, size=11, italic=True, color_rgb=RGBColor(100, 116, 139))

            # Helper to add styled tables
            def create_styled_table(doc, headers, rows):
                cols_count = max(len(headers), max(len(r) for r in rows) if rows else 0)
                tbl = doc.add_table(rows=0, cols=cols_count)
                tbl.autofit = False

                # Center table
                tbl.alignment = WD_ALIGN_PARAGRAPH.CENTER

                # Add headers
                if headers:
                    row_cells = tbl.add_row().cells
                    for idx, text in enumerate(headers):
                        if idx < len(row_cells):
                            p = row_cells[idx].paragraphs[0]
                            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
                            p.paragraph_format.space_after = Pt(2)
                            run = p.add_run(str(text))
                            set_run_font(run, size=10.5, bold=True, color_rgb=RGBColor(255, 255, 255))
                            # Set cell shading to dark slate (#1E293B)
                            shading_elm = parse_xml(r'<w:shd {} w:fill="1E293B"/>'.format(nsdecls('w')))
                            row_cells[idx]._tc.get_or_add_tcPr().append(shading_elm)

                # Add data rows
                for r_idx, row in enumerate(rows):
                    row_cells = tbl.add_row().cells
                    bg_color = "F8FAFC" if r_idx % 2 == 0 else "FFFFFF"
                    for c_idx, val in enumerate(row):
                        if c_idx < len(row_cells):
                            p = row_cells[c_idx].paragraphs[0]
                            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
                            p.paragraph_format.space_after = Pt(2)
                            run = p.add_run(str(val))
                            set_run_font(run, size=10)
                            # Shading
                            shading_elm = parse_xml(r'<w:shd {} w:fill="{}"/>'.format(nsdecls('w'), bg_color))
                            row_cells[c_idx]._tc.get_or_add_tcPr().append(shading_elm)

                # Style borders (thin grey borders)
                tbl_pr = tbl._tbl.tblPr
                borders = parse_xml(
                    r'<w:tblBorders %s>'
                    r'  <w:top w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/>'
                    r'  <w:left w:val="none"/>'
                    r'  <w:bottom w:val="single" w:sz="6" w:space="0" w:color="94A3B8"/>'
                    r'  <w:right w:val="none"/>'
                    r'  <w:insideH w:val="single" w:sz="4" w:space="0" w:color="E2E8F0"/>'
                    r'  <w:insideV w:val="none"/>'
                    r'</w:tblBorders>' % nsdecls('w')
                )
                tbl_pr.append(borders)
                doc.add_paragraph().paragraph_format.space_after = Pt(12)

            sections = data.get("sections", {})
            if isinstance(sections, dict):
                for heading, content in sections.items():
                    # Heading 1 with style
                    p_head = doc.add_paragraph()
                    p_head.paragraph_format.space_before = Pt(16)
                    p_head.paragraph_format.space_after = Pt(8)
                    p_head.paragraph_format.keep_with_next = True
                    run_head = p_head.add_run(heading)
                    set_run_font(run_head, size=14, bold=True, color_rgb=RGBColor(15, 23, 42))

                    if isinstance(content, dict) and content.get("type") == "table":
                        create_styled_table(doc, content.get("headers", []), content.get("rows", []))
                    elif isinstance(content, list):
                        for item in content:
                            p_list = doc.add_paragraph(style='List Bullet')
                            p_list.paragraph_format.space_after = Pt(4)
                            p_list.paragraph_format.line_spacing = 1.15
                            run_item = p_list.add_run(str(item))
                            set_run_font(run_item)
                    else:
                        paragraphs = str(content).split("\n")
                        for p_text in paragraphs:
                            p_text_stripped = p_text.strip()
                            if p_text_stripped:
                                add_styled_paragraph(doc, p_text_stripped)

            elif isinstance(sections, list):
                for section in sections:
                    if isinstance(section, dict):
                        heading = section.get("heading", "")
                        content = section.get("content", "")
                        if heading:
                            p_head = doc.add_paragraph()
                            p_head.paragraph_format.space_before = Pt(16)
                            p_head.paragraph_format.space_after = Pt(8)
                            p_head.paragraph_format.keep_with_next = True
                            run_head = p_head.add_run(heading)
                            set_run_font(run_head, size=14, bold=True, color_rgb=RGBColor(15, 23, 42))

                        if isinstance(content, dict) and content.get("type") == "table":
                            create_styled_table(doc, content.get("headers", []), content.get("rows", []))
                        elif isinstance(content, list):
                            for item in content:
                                p_list = doc.add_paragraph(style='List Bullet')
                                p_list.paragraph_format.space_after = Pt(4)
                                p_list.paragraph_format.line_spacing = 1.15
                                run_item = p_list.add_run(str(item))
                                set_run_font(run_item)
                        else:
                            paragraphs = str(content).split("\n")
                            for p_text in paragraphs:
                                p_text_stripped = p_text.strip()
                                if p_text_stripped:
                                    add_styled_paragraph(doc, p_text_stripped)
                    else:
                        add_styled_paragraph(doc, str(section))

            # Add simple Page Number in Footer
            # Note: docx requires an XML field code to render dynamic page numbers
            footer = doc.sections[0].footer
            p_foot = footer.paragraphs[0]
            p_foot.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            f_run = p_foot.add_run()
            set_run_font(f_run, size=10, color_rgb=RGBColor(148, 163, 184))
            f_run._r.append(parse_xml(r'<w:fldSimple %s w:instr="PAGE"/>' % nsdecls('w')))

            doc.save(path)
            return f"Success: Word document created at: {path}"
        except Exception as e:
            import traceback
            traceback.print_exc()
            return f"Error creating Word document: {str(e)}"

    def _write_csv(self, path, data):
        """
        Writes rows of tabular data to a .csv file.
        """
        headings = data.get("headings", [])
        rows = data.get("rows", [])

        if not headings and rows:
            if isinstance(rows[0], dict):
                headings = list(rows[0].keys())

        try:
            with open(path, mode='w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                if headings:
                    writer.writerow(headings)

                for row in rows:
                    if isinstance(row, dict):
                        writer.writerow([row.get(col, '') for col in headings])
                    elif isinstance(row, list):
                        writer.writerow(row)
                    else:
                        writer.writerow([row])
            return f"Success: CSV file created at: {path}"
        except Exception as e:
            return f"Error creating CSV file: {str(e)}"

    def _write_xlsx(self, path, data):
        """
        Writes styled cells, sheets, and formulas to a Microsoft Excel .xlsx file.
        """
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment
            from openpyxl.utils import get_column_letter
        except ImportError:
            # Fallback to CSV if openpyxl not installed
            csv_path = path.replace(".xlsx", ".csv")
            self._write_csv(csv_path, data)
            return f"Warning: 'openpyxl' library is not installed. Saved as CSV at: {csv_path}"

        try:
            wb = openpyxl.Workbook()
            # Remove default active sheet
            default_sheet = wb.active
            wb.remove(default_sheet)

            # Resolve sheets data
            sheets_data = {}
            if "sheets" in data and isinstance(data["sheets"], dict):
                sheets_data = data["sheets"]
            else:
                sheets_data = {"Sheet1": {
                    "headings": data.get("headings", []),
                    "rows": data.get("rows", [])
                }}

            for sheet_name, s_data in sheets_data.items():
                ws = wb.create_sheet(title=sheet_name)
                headings = s_data.get("headings", [])
                rows = s_data.get("rows", [])

                row_idx = 1
                if headings:
                    for col_idx, heading in enumerate(headings, 1):
                        cell = ws.cell(row=row_idx, column=col_idx, value=heading)
                        # Dark slate blue header background with bold white text
                        cell.font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
                        cell.fill = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")
                        cell.alignment = Alignment(horizontal="center", vertical="center")
                    row_idx += 1

                for row in rows:
                    if isinstance(row, dict):
                        values = [row.get(col, '') for col in headings]
                    elif isinstance(row, list):
                        values = row
                    else:
                        values = [row]

                    for col_idx, val in enumerate(values, 1):
                        ws.cell(row=row_idx, column=col_idx, value=val)
                    row_idx += 1

                # Auto-adjust column widths
                for col in ws.columns:
                    max_len = 0
                    col_letter = get_column_letter(col[0].column)
                    for cell in col:
                        if cell.value is not None:
                            val_str = str(cell.value)
                            if val_str.startswith('='):
                                # Set a reasonable width for formula cells
                                max_len = max(max_len, 12)
                            else:
                                max_len = max(max_len, len(val_str))
                    ws.column_dimensions[col_letter].width = max(max_len + 3, 10)

            wb.save(path)
            return f"Success: Excel workbook created at: {path}"
        except Exception as e:
            return f"Error creating Excel workbook: {str(e)}"

    def _write_pptx(self, path, data):
        """
        Writes a styled, professional PowerPoint (.pptx) presentation.
        If python-pptx is not installed, falls back to text.
        Additionally, to support modern, visually stunning HTML presentation formats,
        if 'html_export' is requested in data, it generates a beautiful responsive 16:9 HTML slide deck.
        """
        try:
            from pptx import Presentation
            from pptx.util import Inches, Pt
            from pptx.dml.color import RGBColor
            from pptx.enum.text import PP_ALIGN
            from pptx.enum.shapes import MSO_SHAPE
        except ImportError:
            fallback_path = path.replace(".pptx", ".txt")
            try:
                with open(fallback_path, 'w', encoding='utf-8') as f:
                    f.write(f"=== Presentation: {data.get('title', 'Presentation Title')} ===\n")
                    subtitle = data.get("subtitle")
                    if subtitle:
                        f.write(f"{subtitle}\n")
                    f.write("\n")
                    slides = data.get("slides", [])
                    for idx, slide in enumerate(slides, 1):
                        f.write(f"Slide {idx}: {slide.get('title', 'Untitled Slide')}\n")
                        content = slide.get("content", [])
                        if isinstance(content, list):
                            for bullet in content:
                                f.write(f" - {bullet}\n")
                        else:
                            f.write(f" {content}\n")
                        f.write("\n")
                return f"Warning: 'python-pptx' library is not installed. Saved as clean text to: {fallback_path}"
            except Exception as ex:
                return f"Error creating fallback text presentation: {str(ex)}"

        # Double Export Trik: Jika format file target diakhiri dengan .html atau data memiliki properti html_presentation,
        # kita buat file presentasi HTML interaktif yang responsif dan sangat estetik.
        if path.lower().endswith(".html") or data.get("html_presentation"):
            html_path = path if path.lower().endswith(".html") else path.replace(".pptx", ".html")
            try:
                title = data.get("title", "Jarvis Presentation")
                subtitle = data.get("subtitle", "")
                slides = data.get("slides", [])

                html_parts = [
                    "<!DOCTYPE html>",
                    "<html lang='id'>",
                    "<head>",
                    "  <meta charset='UTF-8'>",
                    "  <meta name='viewport' content='width=device-width, initial-scale=1.0'>",
                    f"  <title>{title}</title>",
                    "  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css'>",
                    "  <link href='https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Montserrat:wght@400;700&display=swap' rel='stylesheet'>",
                    "  <style>",
                    "    * { box-sizing: border-box; margin: 0; padding: 0; }",
                    "    body { font-family: 'Poppins', sans-serif; background-color: #0f172a; color: #f8fafc; overflow-x: hidden; }",
                    "    .presentation-container { display: flex; flex-direction: column; align-items: center; gap: 30px; padding: 40px 20px; }",
                    "    .slide {",
                    "      width: 1280px; height: 720px; position: relative; overflow: hidden; background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);",
                    "      border-radius: 12px; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5), 0 8px 10px -6px rgba(0, 0, 0, 0.5);",
                    "      display: flex; flex-direction: column; justify-content: space-between; padding: 60px 80px;",
                    "      page-break-after: always; transform-origin: top center; transition: transform 0.3s ease;",
                    "    }",
                    "    .slide-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #334155; padding-bottom: 15px; }",
                    "    .slide-title { font-family: 'Montserrat', sans-serif; font-size: 36px; font-weight: 700; color: #38bdf8; }",
                    "    .slide-icon { font-size: 32px; color: #38bdf8; }",
                    "    .slide-body { flex-grow: 1; display: flex; align-items: center; margin-top: 30px; gap: 40px; }",
                    "    .slide-text { flex: 1; font-size: 20px; line-height: 1.6; color: #cbd5e1; }",
                    "    .slide-text p { margin-bottom: 15px; }",
                    "    .slide-text ul { list-style: none; }",
                    "    .slide-text li { margin-bottom: 12px; display: flex; align-items: center; gap: 15px; }",
                    "    .slide-text li i { color: #f59e0b; font-size: 18px; }",
                    "    .slide-image-container { flex: 1; height: 100%; max-height: 400px; border-radius: 8px; overflow: hidden; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.3); }",
                    "    .slide-image { width: 100%; height: 100%; object-fit: cover; }",
                    "    .slide-footer { display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #334155; padding-top: 15px; font-size: 14px; color: #64748b; }",
                    "    /* Title slide specific styling */",
                    "    .slide.title-layout { justify-content: center; align-items: center; text-align: center; background: radial-gradient(circle at center, #1e293b 0%, #090d16 100%); }",
                    "    .slide.title-layout .title-main { font-family: 'Montserrat', sans-serif; font-size: 54px; font-weight: 700; color: #f8fafc; margin-bottom: 20px; line-height: 1.2; text-shadow: 0 4px 6px rgba(0,0,0,0.3); }",
                    "    .slide.title-layout .title-sub { font-size: 24px; color: #38bdf8; font-weight: 300; margin-bottom: 40px; }",
                    "    .slide.title-layout .title-decor { width: 120px; height: 4px; background: #38bdf8; margin: 0 auto 30px; border-radius: 2px; }",
                    "    /* Grid Card Layout */",
                    "    .cards-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 25px; width: 100%; }",
                    "    .card { background: #1e293b; border: 1px solid #334155; border-radius: 8px; padding: 25px; display: flex; flex-direction: column; gap: 15px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }",
                    "    .card-icon { font-size: 28px; color: #f59e0b; }",
                    "    .card-title { font-size: 20px; font-weight: 600; color: #f8fafc; }",
                    "    .card-desc { font-size: 15px; color: #94a3b8; line-height: 1.5; }",
                    "    @media print {",
                    "      body { background-color: #ffffff; }",
                    "      .presentation-container { padding: 0; gap: 0; }",
                    "      .slide { box-shadow: none; border-radius: 0; transform: none !important; margin: 0; page-break-after: always; }",
                    "    }",
                    "  </style>",
                    "</head>",
                    "<body>",
                    "  <div class='presentation-container'>"
                ]

                # Slide 1: Title Slide
                html_parts.append(
                    f"    <div class='slide title-layout'>"
                    f"      <div class='title-main'>{title}</div>"
                    f"      <div class='title-decor'></div>"
                    f"      <div class='title-sub'>{subtitle}</div>"
                    f"      <div style='font-size: 14px; color: #64748b;'><i class='fa-regular fa-clone'></i> Gunakan Tombol Cetak / Ctrl+P untuk PDF</div>"
                    f"    </div>"
                )

                # Generate rest of the slides
                for idx, slide in enumerate(slides, 2):
                    s_title = slide.get("title", f"Slide {idx}")
                    s_content = slide.get("content", [])
                    image_query = s_title.replace(" ", ",").lower()

                    html_parts.append(f"    <div class='slide'>")
                    html_parts.append(
                        f"      <div class='slide-header'>"
                        f"        <div class='slide-title'>{s_title}</div>"
                        f"        <i class='fa-solid fa-layer-group slide-icon'></i>"
                        f"      </div>"
                    )

                    html_parts.append(f"      <div class='slide-body'>")

                    # Decide layout based on structure of content
                    # If content is a dict with cards representation or many bullets, we can render columns/grid
                    if isinstance(s_content, list) and len(s_content) >= 3 and all(isinstance(c, dict) or (isinstance(c, str) and ":" in c) for c in s_content):
                        # Cards Layout
                        html_parts.append("        <div class='cards-grid'>")
                        icons = ["fa-rocket", "fa-chart-line", "fa-shield-halved", "fa-lightbulb", "fa-gem", "fa-gear"]
                        for c_idx, item in enumerate(s_content):
                            i_class = icons[c_idx % len(icons)]
                            if isinstance(item, dict):
                                c_title = item.get("title", "Info")
                                c_desc = item.get("desc", "")
                            else:
                                parts = item.split(":", 1)
                                c_title = parts[0].strip()
                                c_desc = parts[1].strip()

                            html_parts.append(
                                f"          <div class='card'>"
                                f"            <i class='fa-solid {i_class} card-icon'></i>"
                                f"            <div class='card-title'>{c_title}</div>"
                                f"            <div class='card-desc'>{c_desc}</div>"
                                f"          </div>"
                            )
                        html_parts.append("        </div>")
                    else:
                        # Split Column Layout: Bullet points on Left, image on Right
                        html_parts.append("        <div class='slide-text'>")
                        if isinstance(s_content, list):
                            html_parts.append("          <ul>")
                            for bullet in s_content:
                                # Highlight bullet header if contains colon
                                if ":" in str(bullet):
                                    b_parts = str(bullet).split(":", 1)
                                    bullet_html = f"<strong>{b_parts[0]}:</strong> {b_parts[1]}"
                                else:
                                    bullet_html = str(bullet)
                                html_parts.append(f"            <li><i class='fa-solid fa-circle-check'></i> <div>{bullet_html}</div></li>")
                            html_parts.append("          </ul>")
                        else:
                            html_parts.append(f"          <p>{s_content}</p>")
                        html_parts.append("        </div>")

                        # Image Column
                        unsplash_url = f"https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=600&q=80"  # default high quality business photo
                        if "teknologi" in image_query or "tech" in image_query:
                            unsplash_url = "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=600&q=80"
                        elif "bisnis" in image_query or "business" in image_query:
                            unsplash_url = "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80"
                        elif "alam" in image_query or "nature" in image_query:
                            unsplash_url = "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&w=600&q=80"

                        html_parts.append(
                            f"        <div class='slide-image-container'>"
                            f"          <img class='slide-image' src='{unsplash_url}' alt='{s_title}'>"
                            f"        </div>"
                        )

                    html_parts.append(f"      </div>")

                    # Slide Footer
                    html_parts.append(
                        f"      <div class='slide-footer'>"
                        f"        <div>{title}</div>"
                        f"        <div>Slide {idx} dari {len(slides) + 1}</div>"
                        f"      </div>"
                        f"    </div>"
                    )

                html_parts.append("  </div>")
                html_parts.append("</body>")
                html_parts.append("</html>")

                with open(html_path, 'w', encoding='utf-8') as f:
                    f.write("\n".join(html_parts))
                print(f"HTML Slide Presentation successfully created at: {html_path}")
            except Exception as ex:
                print(f"Failed to generate HTML Presentation: {ex}")

        # Continue with native PowerPoint .pptx creation
        try:
            prs = Presentation()
            # Set Slide size to widescreen 16:9
            prs.slide_width = Inches(13.333)
            prs.slide_height = Inches(7.5)

            # Slide 1: Title Slide (custom styled background and fonts)
            title_layout = prs.slide_layouts[6] # Blank Layout to customize shapes manually
            slide = prs.slides.add_slide(title_layout)

            # Add Dark Radial Gradient Background style using a solid filled rectangle
            bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, Inches(13.333), Inches(7.5))
            bg.fill.solid()
            bg.fill.fore_color.rgb = RGBColor(15, 23, 42) # slate-900
            bg.line.fill.background() # No border

            # Title Text Box
            title_box = slide.shapes.add_textbox(Inches(1.0), Inches(2.2), Inches(11.333), Inches(3.5))
            tf = title_box.text_frame
            tf.word_wrap = True

            p_title = tf.paragraphs[0]
            p_title.alignment = PP_ALIGN.CENTER
            p_title.text = data.get("title", "Jarvis Presentation").upper()
            p_title.font.name = 'Arial'
            p_title.font.size = Pt(44)
            p_title.font.bold = True
            p_title.font.color.rgb = RGBColor(248, 250, 252) # Slate-50

            # Subtitle
            subtitle_text = data.get("subtitle", "")
            if subtitle_text:
                p_sub = tf.add_paragraph()
                p_sub.alignment = PP_ALIGN.CENTER
                p_sub.text = subtitle_text
                p_sub.font.name = 'Arial'
                p_sub.font.size = Pt(20)
                p_sub.font.color.rgb = RGBColor(56, 189, 248) # Sky-400
                p_sub.space_before = Pt(20)

            # Generate rest of the slides
            content_layout = prs.slide_layouts[6] # Use blank to build custom Split Column
            slides = data.get("slides", [])

            for idx, slide_data in enumerate(slides, 2):
                slide = prs.slides.add_slide(content_layout)

                # Set background
                bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, Inches(13.333), Inches(7.5))
                bg.fill.solid()
                bg.fill.fore_color.rgb = RGBColor(30, 41, 59) # Slate-800
                bg.line.fill.background()

                # Add Title block
                title_box = slide.shapes.add_textbox(Inches(1.0), Inches(0.6), Inches(11.333), Inches(1.0))
                tf_title = title_box.text_frame
                p_stitle = tf_title.paragraphs[0]
                p_stitle.text = slide_data.get("title", f"Slide {idx}").upper()
                p_stitle.font.name = 'Arial'
                p_stitle.font.size = Pt(32)
                p_stitle.font.bold = True
                p_stitle.font.color.rgb = RGBColor(56, 189, 248)

                # Add Accent line under title
                line = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(1.0), Inches(1.5), Inches(11.333), Inches(0.04))
                line.fill.solid()
                line.fill.fore_color.rgb = RGBColor(71, 85, 105) # Slate-600
                line.line.fill.background()

                # Text Content Box (Left Column)
                text_box = slide.shapes.add_textbox(Inches(1.0), Inches(2.0), Inches(6.0), Inches(4.5))
                tf_content = text_box.text_frame
                tf_content.word_wrap = True

                content = slide_data.get("content", [])
                if isinstance(content, list):
                    for i, bullet in enumerate(content):
                        p = tf_content.paragraphs[0] if i == 0 else tf_content.add_paragraph()
                        p.text = f"•  {str(bullet)}"
                        p.font.name = 'Arial'
                        p.font.size = Pt(18)
                        p.font.color.rgb = RGBColor(241, 245, 249)
                        p.space_after = Pt(14)
                else:
                    p = tf_content.paragraphs[0]
                    p.text = str(content)
                    p.font.name = 'Arial'
                    p.font.size = Pt(18)
                    p.font.color.rgb = RGBColor(241, 245, 249)

                # Right Column: Visual Accent Card
                accent_card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(7.8), Inches(2.0), Inches(4.5), Inches(4.2))
                accent_card.fill.solid()
                accent_card.fill.fore_color.rgb = RGBColor(15, 23, 42)
                accent_card.line.color.rgb = RGBColor(56, 189, 248)
                accent_card.line.width = Pt(1.5)

                tf_card = accent_card.text_frame
                tf_card.word_wrap = True
                p_card = tf_card.paragraphs[0]
                p_card.alignment = PP_ALIGN.CENTER
                p_card.text = "IKHTISAR UTAMA"
                p_card.font.name = 'Arial'
                p_card.font.size = Pt(18)
                p_card.font.bold = True
                p_card.font.color.rgb = RGBColor(245, 158, 11) # Gold
                p_card.space_after = Pt(20)

                # Grab first bullet point or summary text to put inside the accent card
                highlight_text = "Materi Pokok Pembahasan Akademik"
                if isinstance(content, list) and content:
                    highlight_text = str(content[0]).split(":", 1)[-1].strip() if ":" in str(content[0]) else str(content[0])
                elif isinstance(content, str):
                    highlight_text = content

                p_card_body = tf_card.add_paragraph()
                p_card_body.alignment = PP_ALIGN.CENTER
                p_card_body.text = highlight_text[:140] + ("..." if len(highlight_text) > 140 else "")
                p_card_body.font.name = 'Arial'
                p_card_body.font.size = Pt(14)
                p_card_body.font.color.rgb = RGBColor(148, 163, 184)
                p_card_body.space_before = Pt(10)

                # Footer
                footer_box = slide.shapes.add_textbox(Inches(1.0), Inches(6.8), Inches(11.333), Inches(0.4))
                tf_foot = footer_box.text_frame
                p_foot = tf_foot.paragraphs[0]
                p_foot.text = f"{data.get('title', 'Jarvis')}   |   Slide {idx} dari {len(slides) + 1}"
                p_foot.font.name = 'Arial'
                p_foot.font.size = Pt(10)
                p_foot.font.color.rgb = RGBColor(100, 116, 139)

            prs.save(path)
            return f"Success: PowerPoint presentation created at: {path}"
        except Exception as e:
            import traceback
            traceback.print_exc()
            return f"Error creating PowerPoint presentation: {str(e)}"

    def _write_pdf(self, path, data):
        """
        Writes a styled PDF document with professional styling (Times New Roman, margins, page numbers, header/footer).
        """
        title = data.get("title", "Cellya Claire Output Report")
        subtitle = data.get("subtitle", "")
        sections = data.get("sections", {})

        # Build clean HTML content as fallback/draft
        html_parts = [
            "<!DOCTYPE html>",
            "<html>",
            "<head>",
            "<style>",
            "body { font-family: 'Times New Roman', Times, serif; margin: 40px; color: #333; line-height: 1.6; }",
            "h1 { text-align: center; color: #0f172a; padding-bottom: 8px; font-size: 24px; }",
            "h2 { color: #1e293b; margin-top: 24px; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; font-size: 18px; }",
            "p { font-size: 14px; margin-bottom: 12px; text-align: justify; text-indent: 30px; }",
            "ul { margin-bottom: 16px; padding-left: 20px; }",
            "li { margin-bottom: 6px; font-size: 14px; }",
            ".subtitle { text-align: center; font-style: italic; color: #64748b; margin-bottom: 30px; font-size: 14px; }",
            "</style>",
            "</head>",
            "<body>",
            f"<h1>{title}</h1>"
        ]

        if subtitle:
            html_parts.append(f"<div class='subtitle'>{subtitle}</div>")

        def add_html_section(heading, content):
            if heading:
                html_parts.append(f"<h2>{heading}</h2>")
            if isinstance(content, dict) and content.get("type") == "table":
                headers = content.get("headers", [])
                rows = content.get("rows", [])
                if headers or rows:
                    html_parts.append("<table border='1' style='border-collapse: collapse; width: 100%; margin-bottom: 20px;'>")
                    if headers:
                        html_parts.append("<tr style='background-color: #1e293b; color: white;'>")
                        for h in headers:
                            html_parts.append(f"<th style='padding: 8px; text-align: left; font-size: 12px;'>{h}</th>")
                        html_parts.append("</tr>")
                    for r_idx, r in enumerate(rows):
                        bg = "#f8fafc" if r_idx % 2 == 0 else "#f1f5f9"
                        html_parts.append(f"<tr style='background-color: {bg};'>")
                        for val in r:
                            html_parts.append(f"<td style='padding: 8px; text-align: left; font-size: 11px;'>{val}</td>")
                        html_parts.append("</tr>")
                    html_parts.append("</table>")
            elif isinstance(content, list):
                html_parts.append("<ul>")
                for item in content:
                    html_parts.append(f"<li>{item}</li>")
                html_parts.append("</ul>")
            else:
                formatted_content = str(content).replace("\n", "<br/>")
                html_parts.append(f"<p>{formatted_content}</p>")

        if isinstance(sections, dict):
            for heading, content in sections.items():
                add_html_section(heading, content)
        elif isinstance(sections, list):
            for section in sections:
                if isinstance(section, dict):
                    add_html_section(section.get("heading", ""), section.get("content", ""))
                else:
                    add_html_section("", str(section))

        html_parts.append("</body>")
        html_parts.append("</html>")
        html_content = "\n".join(html_parts)

        html_filepath = path.replace(".pdf", ".html")
        try:
            with open(html_filepath, 'w', encoding='utf-8') as f:
                f.write(html_content)
        except Exception as ex:
            return f"Error creating HTML draft: {str(ex)}"

        try:
            from reportlab.lib.pagesizes import letter
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib import colors
            from reportlab.pdfgen import canvas
            has_reportlab = True
        except ImportError:
            has_reportlab = False

        if has_reportlab:
            # Custom Canvas to add Page Numbers and Running Headers
            class NumberedCanvas(canvas.Canvas):
                def __init__(self, *args, **kwargs):
                    super().__init__(*args, **kwargs)
                    self._saved_page_states = []

                def showPage(self):
                    self._saved_page_states.append(dict(self.__dict__))
                    self._startPage()

                def save(self):
                    num_pages = len(self._saved_page_states)
                    for state in self._saved_page_states:
                        self.__dict__.update(state)
                        self.draw_page_decorations(num_pages)
                        super().showPage()
                    super().save()

                def draw_page_decorations(self, page_count):
                    self.saveState()
                    self.setFont("Times-Roman", 9)
                    self.setFillColor(colors.HexColor("#64748B"))

                    # Margin guidelines (Letter width: 612pt, height: 792pt)
                    # Running Header (top margin: 3cm / ~85pt -> y around 740pt)
                    self.drawString(54, 750, title[:60] + ("..." if len(title) > 60 else ""))
                    self.setStrokeColor(colors.HexColor("#E2E8F0"))
                    self.setLineWidth(0.5)
                    self.line(54, 742, 558, 742)

                    # Running Footer (bottom margin: 3cm -> y around 50pt)
                    page_text = f"Halaman {self._pageNumber} dari {page_count}"
                    self.drawRightString(558, 45, page_text)
                    self.drawString(54, 45, "Asisten Virtual Jarvis - Dokumen Resmi")
                    self.line(54, 55, 558, 55)

                    self.restoreState()

            try:
                # Page setup: Left margin 4cm (~113pt), Top/Right/Bottom 3cm (~85pt)
                doc = SimpleDocTemplate(
                    path,
                    pagesize=letter,
                    leftMargin=113,
                    rightMargin=85,
                    topMargin=95,  # Slightly extra spacing to clear the running header line
                    bottomMargin=95
                )

                # Setup typography
                styles = getSampleStyleSheet()

                # Base body text style: Times New Roman, size 12, line spacing 1.5 (~18pt leading)
                body_style = ParagraphStyle(
                    'AcademicBody',
                    parent=styles['Normal'],
                    fontName='Times-Roman',
                    fontSize=12,
                    leading=18,
                    firstLineIndent=30,  # Indent paragraphs
                    alignment=4,  # Justified alignment
                    spaceAfter=8
                )

                # Bullet points style
                bullet_style = ParagraphStyle(
                    'AcademicBullet',
                    parent=styles['Normal'],
                    fontName='Times-Roman',
                    fontSize=12,
                    leading=16,
                    leftIndent=20,
                    spaceAfter=4
                )

                # Title Style
                title_style = ParagraphStyle(
                    'AcademicTitle',
                    parent=styles['Heading1'],
                    fontName='Times-Bold',
                    fontSize=20,
                    leading=24,
                    spaceAfter=15,
                    alignment=1  # Centered
                )

                # Subtitle Style
                sub_style = ParagraphStyle(
                    'AcademicSubtitle',
                    parent=styles['Normal'],
                    fontName='Times-Italic',
                    fontSize=11,
                    leading=15,
                    spaceAfter=25,
                    alignment=1  # Centered
                )

                # Heading 2 Style (for main sections/chapters)
                h2_style = ParagraphStyle(
                    'AcademicHeading2',
                    parent=styles['Heading2'],
                    fontName='Times-Bold',
                    fontSize=14,
                    leading=18,
                    spaceBefore=16,
                    spaceAfter=8,
                    keepWithNext=True
                )

                story = []

                story.append(Paragraph(title, title_style))
                if subtitle:
                    story.append(Paragraph(subtitle, sub_style))

                story.append(Spacer(1, 10))

                def add_pdf_section(heading, content):
                    if heading:
                        story.append(Paragraph(heading, h2_style))
                    if isinstance(content, dict) and content.get("type") == "table":
                        headers = content.get("headers", [])
                        rows = content.get("rows", [])
                        if headers or rows:
                            table_data = []
                            if headers:
                                table_data.append([Paragraph(f"<b>{h}</b>", ParagraphStyle('TH', fontName='Times-Bold', fontSize=10.5, leading=13, textColor=colors.whitesmoke)) for h in headers])
                            for r in rows:
                                table_data.append([Paragraph(str(val), ParagraphStyle('TD', fontName='Times-Roman', fontSize=10, leading=12)) for val in r])

                            t = Table(table_data, hAlign='LEFT')
                            t.setStyle(TableStyle([
                                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#1E293B")),
                                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
                                ('TOPPADDING', (0, 0), (-1, -1), 6),
                                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor("#F8FAFC"), colors.HexColor("#FFFFFF")]),
                                ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
                                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                            ]))
                            story.append(t)
                            story.append(Spacer(1, 10))
                    elif isinstance(content, list):
                        for item in content:
                            story.append(Paragraph(f"&bull; {item}", bullet_style))
                    else:
                        paragraphs = str(content).split("\n")
                        for p_text in paragraphs:
                            p_text_stripped = p_text.strip()
                            if p_text_stripped:
                                story.append(Paragraph(p_text_stripped, body_style))
                    story.append(Spacer(1, 8))

                # Add Sections
                if isinstance(sections, dict):
                    for heading, content in sections.items():
                        add_pdf_section(heading, content)
                elif isinstance(sections, list):
                    for section in sections:
                        if isinstance(section, dict):
                            add_pdf_section(section.get("heading", ""), section.get("content", ""))
                        else:
                            add_pdf_section("", str(section))

                doc.build(story, canvasmaker=NumberedCanvas)
                # Clean up HTML draft if compilation succeeded
                if os.path.exists(html_filepath):
                    try:
                        os.remove(html_filepath)
                    except Exception:
                        pass
                return f"Success: PDF file created at: {path}"
            except Exception as e:
                import traceback
                traceback.print_exc()
                return f"Warning: Failed to compile reportlab PDF: {str(e)}. Saved as HTML at: {html_filepath}"

        return f"Warning: 'reportlab' library is not installed. Saved as HTML page to: {html_filepath}"
