import os
import re
import urllib.parse
from playwright.sync_api import expect

class ClassroomScraper:
    def __init__(self, page):
        self.page = page

    def get_courses(self):
        """
        Navigates to Google Classroom home and parses the enrolled courses.
        """
        self.page.goto("https://classroom.google.com/h")
        try:
            self.page.wait_for_selector("a", timeout=12000)
        except Exception:
            return "Error: Timed out waiting for Google Classroom to load. Verify internet connection and login status."

        links = self.page.query_selector_all("a")
        courses = []
        seen_ids = set()

        for link in links:
            href = link.get_attribute("href") or ""
            # Link matches https://classroom.google.com/c/<id> or /c/<id>
            match = re.search(r"/c/([a-zA-Z0-9_-]{8,})", href)
            if match:
                course_id = match.group(1)
                if course_id not in seen_ids:
                    # Get title (often in heading tags or inner text)
                    text = link.inner_text().strip()
                    if text and len(text) > 2:
                        # Clean up formatting noise
                        name_lines = [l.strip() for l in text.split("\n") if l.strip()]
                        course_name = " - ".join(name_lines[:2]) if name_lines else text
                        seen_ids.add(course_id)
                        courses.append({
                            "id": course_id,
                            "name": course_name,
                            "url": f"https://classroom.google.com/c/{course_id}"
                        })

        if not courses:
            return "No courses found. Please check if you are logged in to the correct Google profile."
        return courses

    def get_assignments(self, course_id):
        """
        Navigates to Classwork tab of the course and lists available assignments.
        """
        # Go directly to classwork page
        url = f"https://classroom.google.com/c/{course_id}/y/all"
        self.page.goto(url)
        try:
            self.page.wait_for_selector("a", timeout=12000)
        except Exception:
            return f"Error: Timed out loading Classwork for course {course_id}."

        links = self.page.query_selector_all("a")
        assignments = []
        seen_ids = set()

        for link in links:
            href = link.get_attribute("href") or ""
            # Link pattern: /c/<course_id>/a/<assignment_id>/details
            match = re.search(r"/a/([a-zA-Z0-9_-]{8,})/details", href)
            if match:
                assign_id = match.group(1)
                if assign_id not in seen_ids:
                    # Read assignment title
                    text = link.inner_text().strip()
                    if text:
                        title_lines = [line.strip() for line in text.split("\n") if line.strip()]
                        title = title_lines[0] if title_lines else text

                        # Find potential due dates nearby
                        due_date = "No due date"
                        for sibling_line in title_lines[1:]:
                            if "due" in sibling_line.lower() or "tenggat" in sibling_line.lower():
                                due_date = sibling_line
                                break

                        seen_ids.add(assign_id)
                        assignments.append({
                            "id": assign_id,
                            "title": title,
                            "due_date": due_date,
                            "url": f"https://classroom.google.com/c/{course_id}/a/{assign_id}/details"
                        })

        if not assignments:
            return "No assignments found for this course."
        return assignments

    def get_assignment_detail(self, course_id, assignment_id):
        """
        Retrieves description, due dates, instructions, and attachments of a specific task.
        """
        url = f"https://classroom.google.com/c/{course_id}/a/{assignment_id}/details"
        self.page.goto(url)

        try:
            # Wait for heading text containing task title
            self.page.wait_for_selector("h1", timeout=12000)
        except Exception:
            return "Error: Timed out waiting for assignment details to load."

        # Parse title
        h1_element = self.page.query_selector("h1")
        title = h1_element.inner_text().strip() if h1_element else "Untitled Assignment"

        # Parse description / instructions
        # GCR puts descriptions inside elements with role="presentation" or specific div blocks
        desc_selector = "div[jsname='V67aGc']" # Stable dynamic selector for Google's instructions text
        desc_element = self.page.query_selector(desc_selector)
        if not desc_element:
            # Fallback looking for specific styling
            desc_element = self.page.query_selector("div[style*='white-space: pre-wrap']")

        description = desc_element.inner_text().strip() if desc_element else "No description/instructions provided."

        # Parse attachments (PDFs, docs, external links)
        attachments = []
        links = self.page.query_selector_all("a")
        seen_attach_urls = set()

        for link in links:
            href = link.get_attribute("href") or ""
            title_attr = link.get_attribute("title") or ""
            aria_label = link.get_attribute("aria-label") or ""

            # Filter GCR attachment links (mostly google drive, docs, or direct downloads)
            is_valid_attach = any(k in href for k in ["drive.google.com", "docs.google.com", "download", "attachment", "file"])
            if is_valid_attach and href not in seen_attach_urls:
                # Grab text of the anchor representing filename
                label = link.inner_text().strip()
                if not label:
                    label = title_attr or aria_label or "Attachment File"

                # Split off multi-line noise
                label = [l.strip() for l in label.split("\n") if l.strip()][0] if "\n" in label else label

                seen_attach_urls.add(href)
                attachments.append({
                    "name": label,
                    "url": href
                })

        return {
            "title": title,
            "description": description,
            "attachments": attachments,
            "url": url
        }

    def download_attachments(self, course_id, assignment_id, output_dir):
        """
        Navigates to assignment, clicks and downloads all associated attachments.
        """
        detail = self.get_assignment_detail(course_id, assignment_id)
        if isinstance(detail, str) and detail.startswith("Error"):
            return detail

        attachments = detail.get("attachments", [])
        if not attachments:
            return "No attachments found to download."

        os.makedirs(output_dir, exist_ok=True)
        downloaded_paths = []

        # Find all anchors that point to download/drive elements
        links = self.page.query_selector_all("a")

        for attach in attachments:
            name = attach["name"]
            url = attach["url"]

            # Match corresponding link on page to click
            matched_link = None
            for link in links:
                href = link.get_attribute("href") or ""
                if href == url:
                    matched_link = link
                    break

            if matched_link:
                try:
                    # Force opening download context
                    with self.page.expect_download(timeout=15000) as download_info:
                        # Click and wait for download trigger
                        matched_link.click(modifiers=["Control"]) # open in new tab or trigger direct download

                    download = download_info.value
                    filename = download.suggested_filename or name
                    # Clean filename characters
                    filename = re.sub(r'[\\/*?:"<>|]', "", filename)

                    dest_path = os.path.join(output_dir, filename)
                    download.save_as(dest_path)
                    downloaded_paths.append(dest_path)
                except Exception as e:
                    print(f"Failed to download {name}: {e}")

        if not downloaded_paths:
            return "Could not download any files. Ensure browser popups or download controls are allowed."

        return downloaded_paths
