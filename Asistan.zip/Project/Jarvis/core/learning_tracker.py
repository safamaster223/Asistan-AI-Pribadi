import os
import json
import datetime
import threading

_lock = threading.Lock()

def get_learnings_path():
    """
    Returns the absolute path to learnings.json.
    """
    core_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(core_dir)
    learnings_dir = os.path.join(project_root, "learnings")
    os.makedirs(learnings_dir, exist_ok=True)
    return os.path.join(learnings_dir, "learnings.json")

def get_dir_size(path):
    """
    Calculates total size of files in a directory in bytes.
    """
    total = 0
    if not os.path.exists(path):
        return 0
    for dirpath, dirnames, filenames in os.walk(path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            if os.path.exists(fp):
                total += os.path.getsize(fp)
    return total

def load_learnings_prompt():
    """
    Loads all learnings and formats them as a clean, compact system prompt block.
    """
    filepath = get_learnings_path()
    if not os.path.exists(filepath):
        return ""

    with _lock:
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                learnings = json.load(f)
        except Exception as e:
            print(f"Error loading learnings file: {e}")
            return ""

    if not learnings:
        return ""

    # Format learnings concisely
    lines = ["=== PERSISTENT LEARNINGS & DEVELOPMENT DEVELOPED BY CELLYA ==="]
    lines.append("These are points and key solutions you solved or learned previously. Use them to make highly efficient choices:")
    for item in learnings:
        cat = item.get("category", "General")
        insight = item.get("insight", "")
        if insight:
            lines.append(f"- [{cat}]: {insight}")

    return "\n".join(lines)

def add_learning_point(category, insight):
    """
    Appends a new learning point to learnings.json.
    Enforces a strict 1GB size limit on the learnings folder.
    """
    filepath = get_learnings_path()
    learnings_dir = os.path.dirname(filepath)

    with _lock:
        # Load existing
        learnings = []
        if os.path.exists(filepath):
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    learnings = json.load(f)
                    if not isinstance(learnings, list):
                        learnings = []
            except Exception:
                learnings = []

        # Create new entry
        new_entry = {
            "category": category,
            "insight": insight,
            "timestamp": datetime.datetime.now().isoformat()
        }
        learnings.append(new_entry)

        # Enforce folder size limit of 1GB (1,073,741,824 bytes)
        # We also serialize and check the hypothetical size of the JSON
        temp_data = json.dumps(learnings, indent=2, ensure_ascii=False)
        estimated_size = len(temp_data.encode('utf-8'))

        # Check current folder size excluding learnings.json, plus the new estimated size
        other_size = 0
        for f in os.listdir(learnings_dir):
            if f != "learnings.json":
                fp = os.path.join(learnings_dir, f)
                if os.path.isfile(fp):
                    other_size += os.path.getsize(fp)

        total_projected_size = other_size + estimated_size
        max_size = 1024 * 1024 * 1024 # 1GB

        # If we exceed the limit, prune oldest learnings until we are safe
        while total_projected_size > max_size and len(learnings) > 1:
            learnings.pop(0) # Remove oldest
            temp_data = json.dumps(learnings, indent=2, ensure_ascii=False)
            estimated_size = len(temp_data.encode('utf-8'))
            total_projected_size = other_size + estimated_size

        # Write safely
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(temp_data)
            return True
        except Exception as e:
            print(f"Failed to write learnings: {e}")
            return False
