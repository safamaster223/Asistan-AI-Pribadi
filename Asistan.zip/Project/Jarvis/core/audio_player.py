import yt_dlp
import threading
import time
import random

try:
    import vlc
    VLC_AVAILABLE = True
except (ImportError, OSError, FileNotFoundError) as e:
    vlc = None
    VLC_AVAILABLE = False
    print(f"[AudioEngine] VLC not available: {e}. Falling back to Pygame mixer.")

from PyQt6.QtCore import QObject, pyqtSignal


class CellyaAudioEngine(QObject):
    # Signals yang dipakai oleh ChatWindow
    track_ended = pyqtSignal()
    error_occurred = pyqtSignal(str)
    track_loaded = pyqtSignal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_track_info = None
        self.is_playing = False
        self.volume = 50
        self.instance = None
        self.player = None
        self.pygame_initialized = False

        # Queue system
        self.queue = []
        self.current_index = -1

        # Repeat & Shuffle modes
        # repeat_mode: "off" = no repeat, "one" = repeat current, "all" = repeat entire queue
        self.repeat_mode = "off"
        self.shuffle = False
        self._shuffle_order = []

        # Coba inisialisasi VLC
        if VLC_AVAILABLE and vlc:
            try:
                self.instance = vlc.Instance('--no-video', '--quiet')
                self.player = self.instance.media_player_new()
                self.player.audio_set_volume(self.volume)

                # Attach VLC events
                events = self.player.event_manager()
                events.event_attach(vlc.EventType.MediaPlayerEndReached, self._on_vlc_end)
                events.event_attach(vlc.EventType.MediaPlayerEncounteredError, self._on_vlc_error)

                print("[AudioEngine] VLC player initialized successfully.")
            except Exception as e:
                print(f"[AudioEngine] Failed to initialize VLC: {e}. Falling back to Pygame.")
                self.instance = None
                self.player = None

        # Fallback ke pygame kalau VLC gagal
        if not self.player:
            try:
                import pygame
                if not pygame.mixer.get_init():
                    pygame.mixer.init()
                self.pygame_initialized = True
                pygame.mixer.music.set_volume(self.volume / 100.0)
                print("[AudioEngine] Pygame mixer initialized as fallback.")
            except Exception as e:
                print(f"[AudioEngine] Failed to initialize Pygame mixer: {e}")

    def _on_vlc_end(self, event):
        """VLC event callback — track selesai. Handle repeat/auto-next."""
        self.is_playing = False
        # Emit signal, ChatWindow will call auto_next()
        self.track_ended.emit()

    def _on_vlc_error(self, event):
        """VLC event callback — error."""
        self.is_playing = False
        self.error_occurred.emit("VLC gagal memutar stream ini. Mungkin URL diblokir (403 Forbidden).")

    def search_and_extract(self, query: str, limit: int = 5) -> list:
        """Mencari lagu di YouTube dan mengembalikan metadata."""
        ydl_opts = {
            'format': 'bestaudio/best',
            'noplaylist': True,
            'extract_flat': 'in_playlist',
            'default_search': 'ytsearch',
            'quiet': True,
            'no_warnings': True,
        }

        results = []
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(f"ytsearch{limit}:{query}", download=False)
                if 'entries' in info:
                    for entry in info['entries']:
                        results.append({
                            'id': entry.get('id'),
                            'title': entry.get('title'),
                            'channel': entry.get('uploader'),
                            'duration': entry.get('duration'),
                            'url': entry.get('url'),
                            'thumbnail': entry.get('thumbnail')
                        })
        except Exception as e:
            print(f"[AudioEngine] Search error: {e}")
            self.error_occurred.emit(f"Gagal mencari lagu: {e}")
        return results

    def get_direct_stream_url(self, video_url: str) -> str:
        """Mengekstrak URL streaming audio murni untuk diputar."""
        ydl_opts = {
            'format': 'm4a/bestaudio/best',
            'quiet': True,
            'no_warnings': True,
            'nocheckcertificate': True,
            'extractor_args': {'youtube': {'player_client': ['android', 'web']}}
        }
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(video_url, download=False)
                return info.get('url')
        except Exception as e:
            print(f"[AudioEngine] Extract error: {e}")
            return None

    def play_track(self, track_info: dict):
        """Memutar lagu di thread terpisah agar UI tidak freeze."""
        self.current_track_info = track_info

        def _play():
            video_url = track_info.get('url')
            if not video_url and track_info.get('id'):
                video_url = f"https://www.youtube.com/watch?v={track_info['id']}"

            if not video_url:
                self.error_occurred.emit("URL lagu tidak ditemukan.")
                return

            print(f"[AudioEngine] Extracting stream URL for: {video_url}")
            stream_url = self.get_direct_stream_url(video_url)
            if not stream_url:
                self.error_occurred.emit("Gagal mengekstrak URL audio. Mungkin diblokir YouTube (Error 403).")
                return

            if self.player:
                # VLC playback
                try:
                    media = self.instance.media_new(stream_url)
                    self.player.set_media(media)
                    self.player.play()
                    self.is_playing = True
                    # Emit track_loaded signal
                    self.track_loaded.emit(track_info)
                    print(f"[AudioEngine] VLC playing: {track_info.get('title')}")
                except Exception as e:
                    print(f"[AudioEngine] VLC play failed: {e}")
                    self.error_occurred.emit(f"VLC gagal memutar: {e}")
            elif self.pygame_initialized:
                # Pygame fallback
                try:
                    import pygame
                    try:
                        pygame.mixer.music.load(stream_url)
                        pygame.mixer.music.play()
                        self.is_playing = True
                        self.track_loaded.emit(track_info)
                    except Exception as direct_ex:
                        print(f"[AudioEngine] Pygame direct load failed ({direct_ex}). Downloading...")
                        import tempfile, os, urllib.request
                        if pygame.mixer.music.get_busy():
                            pygame.mixer.music.stop()
                        pygame.mixer.music.unload()
                        temp_dir = tempfile.gettempdir()
                        temp_file_path = os.path.join(temp_dir, "cellya_music_temp.mp3")
                        if os.path.exists(temp_file_path):
                            try:
                                os.remove(temp_file_path)
                            except:
                                pass
                        urllib.request.urlretrieve(stream_url, temp_file_path)
                        pygame.mixer.music.load(temp_file_path)
                        pygame.mixer.music.play()
                        self.is_playing = True
                        self.track_loaded.emit(track_info)
                except Exception as e:
                    print(f"[AudioEngine] Pygame play failed: {e}")
                    self.error_occurred.emit(f"Gagal memutar lagu: {e}")
            else:
                self.error_occurred.emit("Tidak ada audio backend (VLC/Pygame) yang tersedia.")

        threading.Thread(target=_play, daemon=True).start()

    def add_to_queue(self, track_info: dict):
        """Tambahkan lagu ke queue dan putar jika belum ada yang playing."""
        self.queue.append(track_info)
        if self.shuffle:
            self._rebuild_shuffle_order()
        if not self.is_playing:
            self.current_index = len(self.queue) - 1
            self.play_track(track_info)

    def auto_next(self) -> dict:
        """Dipanggil saat lagu selesai — handle repeat mode & shuffle."""
        if not self.queue:
            return None

        if self.repeat_mode == "one" and self.current_track_info:
            # Ulangi lagu yang sama
            self.play_track(self.current_track_info)
            return self.current_track_info

        if self.shuffle:
            # Cari posisi sekarang di shuffle order, lanjut ke berikutnya
            try:
                shuffle_pos = self._shuffle_order.index(self.current_index)
            except ValueError:
                shuffle_pos = -1

            next_shuffle_pos = shuffle_pos + 1
            if next_shuffle_pos < len(self._shuffle_order):
                self.current_index = self._shuffle_order[next_shuffle_pos]
            elif self.repeat_mode == "all":
                # Shuffle ulang dan mulai dari awal
                self._rebuild_shuffle_order()
                if self._shuffle_order:
                    self.current_index = self._shuffle_order[0]
                else:
                    return None
            else:
                return None
        else:
            # Normal sequential
            if self.current_index < len(self.queue) - 1:
                self.current_index += 1
            elif self.repeat_mode == "all":
                # Balik ke awal queue
                self.current_index = 0
            else:
                return None

        track = self.queue[self.current_index]
        self.play_track(track)
        return track

    def play_next(self) -> dict:
        """Putar lagu berikutnya di queue (manual skip)."""
        if not self.queue:
            return None

        self.stop()

        if self.shuffle:
            try:
                shuffle_pos = self._shuffle_order.index(self.current_index)
            except ValueError:
                shuffle_pos = -1
            next_pos = shuffle_pos + 1
            if next_pos < len(self._shuffle_order):
                self.current_index = self._shuffle_order[next_pos]
            elif self.repeat_mode == "all":
                self._rebuild_shuffle_order()
                self.current_index = self._shuffle_order[0] if self._shuffle_order else 0
            else:
                return None
        else:
            if self.current_index < len(self.queue) - 1:
                self.current_index += 1
            elif self.repeat_mode == "all":
                self.current_index = 0
            else:
                return None

        track = self.queue[self.current_index]
        self.play_track(track)
        return track

    def play_prev(self) -> dict:
        """Putar lagu sebelumnya di queue."""
        if not self.queue:
            return None

        self.stop()

        if self.shuffle:
            try:
                shuffle_pos = self._shuffle_order.index(self.current_index)
            except ValueError:
                shuffle_pos = 0
            prev_pos = shuffle_pos - 1
            if prev_pos >= 0:
                self.current_index = self._shuffle_order[prev_pos]
            elif self.repeat_mode == "all":
                self.current_index = self._shuffle_order[-1] if self._shuffle_order else 0
            else:
                return None
        else:
            if self.current_index > 0:
                self.current_index -= 1
            elif self.repeat_mode == "all":
                self.current_index = len(self.queue) - 1
            else:
                return None

        track = self.queue[self.current_index]
        self.play_track(track)
        return track

    def toggle_repeat(self) -> str:
        """Cycle repeat mode: off -> one -> all -> off."""
        if self.repeat_mode == "off":
            self.repeat_mode = "one"
        elif self.repeat_mode == "one":
            self.repeat_mode = "all"
        else:
            self.repeat_mode = "off"
        print(f"[AudioEngine] Repeat mode: {self.repeat_mode}")
        return self.repeat_mode

    def toggle_shuffle(self) -> bool:
        """Toggle shuffle on/off."""
        self.shuffle = not self.shuffle
        if self.shuffle:
            self._rebuild_shuffle_order()
        print(f"[AudioEngine] Shuffle: {'ON' if self.shuffle else 'OFF'}")
        return self.shuffle

    def _rebuild_shuffle_order(self):
        """Rebuild shuffle order, keeping current track first."""
        indices = list(range(len(self.queue)))
        if self.current_index in indices:
            indices.remove(self.current_index)
        random.shuffle(indices)
        self._shuffle_order = [self.current_index] + indices if self.current_index >= 0 else indices

    def clear_queue(self):
        """Hapus semua lagu dari queue."""
        self.stop()
        self.queue.clear()
        self.current_index = -1
        self._shuffle_order.clear()
        self.current_track_info = None

    def pause(self):
        if self.player and self.is_playing:
            self.player.pause()
            self.is_playing = False
        elif self.pygame_initialized and self.is_playing:
            import pygame
            pygame.mixer.music.pause()
            self.is_playing = False

    def resume(self):
        if self.player and not self.is_playing and self.current_track_info:
            self.player.play()
            self.is_playing = True
        elif self.pygame_initialized and not self.is_playing:
            import pygame
            pygame.mixer.music.unpause()
            self.is_playing = True

    def stop(self):
        if self.player:
            self.player.stop()
        elif self.pygame_initialized:
            import pygame
            pygame.mixer.music.stop()
            try:
                pygame.mixer.music.unload()
            except:
                pass
        self.is_playing = False

    def set_volume(self, level: int):
        self.volume = max(0, min(100, level))
        if self.player:
            self.player.audio_set_volume(self.volume)
        elif self.pygame_initialized:
            import pygame
            pygame.mixer.music.set_volume(self.volume / 100.0)

    def get_position(self) -> float:
        """Returns position as a float between 0.0 and 1.0."""
        if self.player:
            pos = self.player.get_position()
            return pos if pos >= 0 else 0.0
        elif self.pygame_initialized and self.current_track_info:
            import pygame
            duration = self.current_track_info.get('duration', 0)
            if duration and duration > 0:
                played_ms = pygame.mixer.music.get_pos()
                if played_ms < 0:
                    played_ms = 0
                return min(1.0, (played_ms / 1000.0) / duration)
        return 0.0

    def set_position(self, pos: float):
        """Set position as float between 0.0 and 1.0."""
        if self.player:
            self.player.set_position(pos)
        elif self.pygame_initialized:
            import pygame
            duration = self.current_track_info.get('duration', 0) if self.current_track_info else 0
            if duration > 0:
                try:
                    pygame.mixer.music.set_pos(pos * duration)
                except Exception as e:
                    print(f"[AudioEngine] Failed to set Pygame position: {e}")
