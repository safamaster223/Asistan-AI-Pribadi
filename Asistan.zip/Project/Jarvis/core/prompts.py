SYSTEM_PROMPT = """
You are Jarvis, a lightweight, transparent, always-on-top desktop AI assistant.
You are a highly capable autonomous coding agent designed to help developers inspect, create, modify, and delete local files inside their workspace.
You communicate clearly, concisely, and execute actions only when requested or logical.

You are strictly sandboxed inside authorized workspace directories.
The primary safe workspace path is: {safe_root}

You also have authorized access to:
- The user's Downloads directory (e.g. `C:\\Users\\<User>\\Downloads`)
- The system Program Files directory (`C:\\Program Files` and `C:\\Program Files (x86)`)

You have access to 16 operations (tools):
1. `get_project_tree` - Retrieve directory structure of the primary workspace (excluding .git, venv, cache).
2. `read_file` - Read text content of a file in any authorized directory.
3. `write_file` - Create or edit a file with content in any authorized directory.
4. `delete_file` - Delete a file or directory in any authorized directory.
5. `list_directory_contents` - List contents of a subdirectory in any authorized directory.
6. `execute_terminal_command` - Execute a terminal/shell command (PowerShell or CMD) on Windows. Allows troubleshooting and solving PC issues.
7. `open_resource` - Opens a web page (URL), an application/protocol handler (e.g. spotify, roblox-player), or a local folder in VS Code, with optional Git auto-saving.
8. `search_youtube` - Searches YouTube for a query and returns the top 3-5 results with title, channel name, video URL, and duration.
9. `control_media` - Controls Windows system media playback (Play, Pause, Next, Prev) and volume (Mute, Up, Down).
10. `get_active_browser_info` - Detects the current active/foreground window. If it is a web browser, simulates keystrokes to extract the active URL, returning the title and URL.
11. `read_webpage_summary` - Takes a URL, downloads its HTML content in the background, strips tags/scripts, and returns the cleaned plain text.
12. `add_learning_point` - Saves a technical learning point, user preference, or system resolution to Cellya's learning database.
13. `browser_launch` - Launches Google Chrome using the user's local profile and session to open a webpage.
14. `classroom_scrape` - Scrapes Google Classroom data (courses, assignments, attachment downloads).
15. `forms_parse` - Opens a Google Forms link inside browser and extracts questions and choices.
16. `document_generate` - Creates formatted Word documents (.docx), PDFs (.pdf), CSVs (.csv), Excel sheets (.xlsx), or PowerPoint slides (.pptx) in the workspace. Supports styled tables, Excel formulas, and slide decks.

Rules & Guidelines:
- You cannot read, write, list, or delete files outside the allowed directories (primary workspace, Downloads, and Program Files).
- If the user requests access to a folder outside these allowed directories (such as system folders like C:\\Windows, or other drives), DO NOT call any tool. Instead, reply directly and politely explaining that the path is outside your allowed directories.
- You can accept absolute paths to Downloads and Program Files. For relative paths, resolve them relative to the primary safe workspace: {safe_root}
- **Step-by-step dependency**: Never call `write_file` to write or copy content from a file you haven't read yet. You must first call `read_file` to obtain the content, wait for the user/system to return the content, and then call `write_file` with that content in the next turn.
- **Terminal Execution Security**: Every terminal execution requests a confirmation dialog to the user. Explain clearly to the user what the command will do before or while running it.
- **One tool call at a time**: Prefer executing a single tool call per turn when operations depend on each other.
- Be concise, helpful, and developer-oriented. Use Markdown to format code snippets or explanations.
"""

TOOLS_SCHEMA = [
    {
        "name": "get_project_tree",
        "description": "Retrieves the directory structure of the safe workspace, ignoring .git, venv, and cache files.",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "read_file",
        "description": "Reads the text contents of a file inside the safe workspace.",
        "parameters": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "The absolute or relative path to the file to read."
                }
            },
            "required": ["file_path"]
        }
    },
    {
        "name": "write_file",
        "description": "Writes text content to a file inside the safe workspace. Creates parent directories if missing.",
        "parameters": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "The absolute or relative path to the file to write."
                },
                "content": {
                    "type": "string",
                    "description": "The text content to be written."
                }
            },
            "required": ["file_path", "content"]
        }
    },
    {
        "name": "delete_file",
        "description": "Deletes a file or directory inside the safe workspace.",
        "parameters": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "The absolute or relative path to the file/directory to delete."
                }
            },
            "required": ["file_path"]
        }
    },
    {
        "name": "list_directory_contents",
        "description": "Lists contents of a directory, returns name, type (file/directory), size, and modification time.",
        "parameters": {
            "type": "object",
            "properties": {
                "dir_path": {
                    "type": "string",
                    "description": "The absolute or relative path of the directory to list."
                }
            },
            "required": ["dir_path"]
        }
    },
    {
        "name": "execute_terminal_command",
        "description": "Runs a script or shell command on Windows. Prompts the user with a confirmation dialog before running.",
        "parameters": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The command or script text to execute."
                },
                "shell": {
                    "type": "string",
                    "enum": ["powershell", "cmd"],
                    "description": "Optional shell choice. Defaults to powershell."
                },
                "background": {
                    "type": "boolean",
                    "description": "Optional flag. Set to true if the command launches a GUI application (like chrome, notepad, spotify) or a long-running process, so it executes in the background and does not block/timeout. Defaults to false."
                }
            },
            "required": ["command"]
        }
    },
    {
        "name": "open_resource",
        "description": "Opens a web resource (URL), a whitelisted application protocol (like spotify or roblox-player), or a local folder in VS Code. Optionally auto-saves the active project via git commit.",
        "parameters": {
            "type": "object",
            "properties": {
                "target": {
                    "type": "string",
                    "description": "The URL, application protocol, or local folder path to open. Examples: 'https://github.com', 'spotify:', 'roblox-player:', 'code' (to open current project in VS Code), or a local directory path to open in VS Code."
                },
                "autosave": {
                    "type": "boolean",
                    "description": "If true, checks the active project's git status. If there are modified or untracked files, automatically stages and commits them before opening the target. Defaults to false."
                },
                "commit_message": {
                    "type": "string",
                    "description": "Optional custom commit message to use if autosave is true. If not specified, a default message is generated."
                }
            },
            "required": ["target"]
        }
    },
    {
        "name": "search_youtube",
        "description": "Searches YouTube for the given query and returns a list of top video results containing their title, channel name, video URL, and duration.",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query to look up on YouTube."
                },
                "limit": {
                    "type": "integer",
                    "description": "The maximum number of search results to return. Defaults to 5.",
                    "default": 5
                }
            },
            "required": ["query"]
        }
    },
    {
        "name": "control_media",
        "description": "Controls Windows system media and volume. Simulates pressing hardware media keys.",
        "parameters": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["play_pause", "next", "prev", "volume_up", "volume_down", "volume_mute"],
                    "description": "The media control action to perform."
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "get_active_browser_info",
        "description": "Detects the current active/foreground window. If it is a browser (e.g. Chrome, Edge, Firefox, Brave, Opera), simulates keyboard shortcuts to focus the address bar, copy, and return the active URL along with the window title.",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "read_webpage_summary",
        "description": "Takes a web URL, downloads its HTML content in the background, strips tags, scripts, stylesheets, and returns the cleaned text. Use this to read the text content of a webpage.",
        "parameters": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "The URL of the webpage to retrieve and clean."
                }
            },
            "required": ["url"]
        }
    },
    {
        "name": "add_learning_point",
        "description": "Saves a key technical learning point, user preference, or system resolution to Cellya's learning database. Use this when you solve a non-trivial bug, learn a user preference, or identify a highly efficient way to design a module.",
        "parameters": {
            "type": "object",
            "properties": {
                "category": {
                    "type": "string",
                    "description": "Domain of the insight (e.g. Python, PyQt6, Git, CSS, UI preference, POS design)."
                },
                "insight": {
                    "type": "string",
                    "description": "The concise learning point or solution summary. Keep it brief and concrete."
                }
            },
            "required": ["category", "insight"]
        }
    },
    {
        "name": "browser_launch",
        "description": "Launches Google Chrome automatically using the user's local profile and session. Headed browser is displayed so the user can see classroom links or active tabs.",
        "parameters": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "Optional URL to navigate to immediately upon launch (e.g. https://classroom.google.com)."
                }
            }
        }
    },
    {
        "name": "classroom_scrape",
        "description": "Scrapes and parses courses, enrolled classes, or lists assignments and due dates directly from Google Classroom.",
        "parameters": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["get_courses", "get_assignments", "get_assignment_detail", "download_attachments"],
                    "description": "The scraping operation to execute."
                },
                "course_id": {
                    "type": "string",
                    "description": "The classroom course identifier. Required for get_assignments, get_assignment_detail, and download_attachments."
                },
                "assignment_id": {
                    "type": "string",
                    "description": "The specific assignment identifier. Required for get_assignment_detail and download_attachments."
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "forms_parse",
        "description": "Opens a Google Forms link inside the active browser context and extracts all questions, inputs, and choices.",
        "parameters": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "The Google Form web link."
                }
            },
            "required": ["url"]
        }
    },
    {
        "name": "document_generate",
        "description": "Creates formatted output files (docx, pdf, csv, xlsx, pptx) representing assignment answers, data summaries, or research reports inside the safe workspace directory. Supports tables in docx/pdf, multiple sheets/formulas in Excel, and slides in PowerPoint.",
        "parameters": {
            "type": "object",
            "properties": {
                "format": {
                    "type": "string",
                    "enum": ["docx", "pdf", "csv", "xlsx", "pptx"],
                    "description": "The output file extension format. Use 'xlsx' for spreadsheet data requiring styling, sheets, or formulas, and 'pptx' for PowerPoint slide presentations."
                },
                "file_name": {
                    "type": "string",
                    "description": "Target file name to write, resolved relative to safe workspace (e.g. Cellya_Outputs/Assignment_1_Answers.docx, Cellya_Outputs/Budget.xlsx, or Cellya_Outputs/Presentation.pptx)."
                },
                "data": {
                    "type": "object",
                    "description": "Structured data payload. For docx/pdf, schema is: {title: string, subtitle?: string, sections: [{heading: string, content: string_or_list_or_table_dict}] or {Heading: string_or_list_or_table_dict}}. Using a list of dicts for sections is highly recommended to preserve logical order. Table dict is: {type: 'table', headers: [string], rows: [[string]]}. For csv/xlsx, schema is: {headings: [string], rows: [[string]_or_dict], sheets?: {SheetName: {headings: [string], rows: [...]}}}. Formulas in xlsx must start with '=' (e.g. '=SUM(B2:B10)'). For pptx, schema is: {title: string, subtitle?: string, slides: [{title: string, content: [string]}]}."
                }
            },
            "required": ["format", "file_name", "data"]
        }
    }
]
