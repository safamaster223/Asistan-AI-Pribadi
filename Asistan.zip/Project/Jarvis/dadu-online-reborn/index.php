<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Dadu Online - Premium Edition</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&family=Space+Grotesk:wght@500;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css?v=<?php echo time(); ?>">
</head>
<body class="bg-slate-950 text-slate-200 font-inter h-screen overflow-hidden flex flex-col selection:bg-indigo-500 selection:text-white">

    <!-- Main Wrapper -->
    <div class="flex-1 flex relative overflow-hidden">
        
        <!-- Left Sidebar: Session History -->
        <aside id="sidebarHistory" class="w-full md:w-80 h-full absolute md:relative z-30 md:z-20 bg-slate-950/95 md:bg-transparent backdrop-blur-2xl md:backdrop-blur-none transition-transform duration-300 -translate-x-full md:translate-x-0 flex flex-col border-r border-white/10 left-0">
            <div class="p-4 md:p-6 border-b border-white/10 flex justify-between items-center shrink-0">
                <div>
                    <h1 class="text-xl md:text-2xl font-space font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400">Dadu Pro</h1>
                    <p class="text-[10px] md:text-xs text-slate-400 mt-1">Riwayat Sesi Gacha</p>
                </div>
                <button id="newSessionBtn" class="w-8 h-8 md:w-10 md:h-10 rounded-full bg-indigo-500/20 text-indigo-400 hover:bg-indigo-500 hover:text-white transition-all flex items-center justify-center shadow-[0_0_15px_rgba(99,102,241,0.3)]" title="Sesi Baru">
                    <i class="fas fa-plus"></i>
                </button>
            </div>
            
            <div id="sessionList" class="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar"></div>

            <div class="p-4 border-t border-white/10 shrink-0">
                <button id="clearAllBtn" class="w-full py-2 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20 transition-all text-sm font-semibold">
                    <i class="fas fa-trash-alt mr-2"></i>Hapus Riwayat
                </button>
            </div>
        </aside>

        <!-- Main Arena -->
        <main id="mainArena" class="flex-1 h-full flex flex-col relative overflow-hidden bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-black z-10 w-full">
            
            <!-- Top Controls -->
            <header class="h-16 md:h-20 border-b border-white/5 flex items-center justify-between px-4 md:px-8 glass-panel z-10 shrink-0">
                <div class="flex items-center space-x-2 md:space-x-4">
                    <div class="flex items-center bg-slate-900/50 rounded-lg border border-white/10 p-1">
                        <button id="minDiceBtn" class="w-8 h-8 rounded text-slate-400 hover:text-white hover:bg-white/10 transition-all"><i class="fas fa-minus"></i></button>
                        <span id="diceCountDisplay" class="w-8 md:w-12 text-center font-space font-bold text-base md:text-lg">1</span>
                        <button id="addDiceBtn" class="w-8 h-8 rounded text-slate-400 hover:text-white hover:bg-white/10 transition-all"><i class="fas fa-plus"></i></button>
                    </div>
                    <span class="text-xs md:text-sm text-slate-400 hidden sm:inline">Jumlah Dadu</span>
                </div>
                
                <button id="rollBtn" class="px-4 py-2 md:px-8 md:py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-600 text-white font-bold font-space tracking-wide hover:shadow-[0_0_25px_rgba(99,102,241,0.5)] hover:scale-105 transition-all duration-300 flex items-center text-sm md:text-base">
                    <i class="fas fa-dice mr-2 md:mr-3 text-lg md:text-xl"></i> <span class="hidden sm:inline">GACHA SEKARANG</span><span class="sm:hidden">GACHA</span>
                </button>
            </header>

            <!-- Dice Grid Area -->
            <div class="flex-1 overflow-y-auto p-4 md:p-8 flex flex-col items-center custom-scrollbar relative">
                <div id="activeSessionHeader" class="w-full max-w-4xl mb-4 text-center hidden">
                    <h2 class="text-lg md:text-xl font-space text-indigo-300" id="activeSessionTitle">Sesi Aktif</h2>
                    <p class="text-xs md:text-sm text-slate-500" id="activeSessionTime"></p>
                </div>

                <!-- TOTAL DISPLAY -->
                <div id="totalDisplayContainer" class="mb-6 md:mb-8 text-center">
                    <div class="text-[10px] md:text-sm text-slate-400 font-space mb-1 uppercase tracking-widest">Total Angka</div>
                    <div id="totalDisplay" class="text-5xl md:text-7xl font-space font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-slate-400 drop-shadow-[0_0_25px_rgba(255,255,255,0.3)] transition-transform duration-200">0</div>
                </div>

                <!-- Dice Container -->
                <div id="diceContainer" class="flex flex-wrap gap-4 md:gap-8 w-full max-w-5xl justify-center mb-8 md:mb-12"></div>

                <!-- Current Roll Results Log -->
                <div id="currentRollLog" class="w-full max-w-4xl glass-panel rounded-2xl border border-white/10 p-4 md:p-6 hidden">
                    <h3 class="text-base md:text-lg font-space font-semibold mb-3 md:mb-4 text-cyan-400 border-b border-white/10 pb-2">Kondisi Awal</h3>
                    <div id="initialStateContainer" class="flex flex-wrap gap-2 mb-4 md:mb-6"></div>
                    
                    <h3 class="text-base md:text-lg font-space font-semibold mb-3 md:mb-4 text-indigo-400 border-b border-white/10 pb-2">Riwayat Lanjutan</h3>
                    <div id="subsequentRollsContainer" class="space-y-2 md:space-y-3"></div>
                </div>
            </div>
        </main>

        <!-- Right Sidebar: Leaderboard -->
        <aside id="sidebarLeaderboard" class="w-full md:w-80 h-full absolute md:relative z-30 md:z-20 bg-slate-950/95 md:bg-slate-950/80 backdrop-blur-2xl md:backdrop-blur-none transition-transform duration-300 translate-x-full md:translate-x-0 flex flex-col border-l border-white/10 right-0">
            <!-- Prize Pool Section -->
            <div class="p-4 md:p-6 border-b border-white/10 text-center relative overflow-hidden shrink-0">
                <div class="absolute inset-0 bg-gradient-to-b from-amber-500/10 to-transparent pointer-events-none"></div>
                <h2 class="text-[10px] md:text-xs font-space text-amber-400 uppercase tracking-widest mb-1 font-bold"><i class="fas fa-trophy mr-1"></i> Prize Pool Bulan Ini</h2>
                <div id="lbPrizePool" class="text-2xl md:text-3xl font-space font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-400 to-amber-500 drop-shadow-[0_0_15px_rgba(251,191,36,0.6)] mt-1 md:mt-2">Rp 0</div>
                
                <div class="mt-3 md:mt-4 bg-slate-900/80 rounded-lg p-2 border border-white/5">
                    <div class="text-[9px] md:text-[10px] text-slate-400 uppercase tracking-wider mb-1">Berakhir Dalam</div>
                    <div id="lbCountdown" class="text-xs md:text-sm font-space font-bold text-rose-400 tracking-widest">00d 00h 00m 00s</div>
                </div>
            </div>

            <!-- Top Ranking -->
            <div class="flex-1 overflow-y-auto p-4 space-y-3 md:space-y-4 custom-scrollbar" id="leaderboardContainer">
                <!-- Injected by JS -->
            </div>

            <!-- Admin Button -->
            <div class="p-4 border-t border-white/10 shrink-0">
                <button onclick="openAdminModal()" class="w-full py-2 md:py-3 rounded-xl bg-slate-800/50 text-slate-400 hover:bg-indigo-600 hover:text-white hover:shadow-[0_0_15px_rgba(99,102,241,0.4)] border border-white/5 transition-all text-xs md:text-sm font-bold flex items-center justify-center">
                    <i class="fas fa-user-shield mr-2"></i> Panel Admin
                </button>
            </div>
        </aside>
    </div>

    <!-- Mobile Bottom Navigation -->
    <nav class="md:hidden h-16 bg-slate-900/95 backdrop-blur-lg border-t border-white/10 flex justify-around items-center z-40 shrink-0 pb-safe">
        <button id="navHistory" onclick="switchTab('history')" class="nav-btn flex flex-col items-center text-slate-500 hover:text-indigo-400 transition-colors w-16">
            <i class="fas fa-history text-xl mb-1"></i>
            <span class="text-[9px] font-space uppercase tracking-wider">Riwayat</span>
        </button>
        
        <button id="navArena" onclick="switchTab('arena')" class="nav-btn flex flex-col items-center text-indigo-400 transition-colors relative -top-5">
            <div class="w-14 h-14 rounded-full bg-gradient-to-tr from-indigo-600 to-cyan-500 flex items-center justify-center text-white shadow-[0_0_20px_rgba(99,102,241,0.6)] border-4 border-slate-950">
                <i class="fas fa-dice text-2xl"></i>
            </div>
        </button>
        
        <button id="navLeaderboard" onclick="switchTab('leaderboard')" class="nav-btn flex flex-col items-center text-slate-500 hover:text-amber-400 transition-colors w-16">
            <i class="fas fa-trophy text-xl mb-1"></i>
            <span class="text-[9px] font-space uppercase tracking-wider">Ranking</span>
        </button>
    </nav>

    <!-- Admin Modal Overlay -->
    <div id="adminModal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/70 backdrop-blur-md opacity-0 transition-opacity duration-300 p-4">
        <div class="glass-panel w-full max-w-md rounded-2xl border border-white/10 shadow-2xl overflow-hidden flex flex-col transform scale-95 transition-transform duration-300" id="adminModalContent">
            <div class="p-4 md:p-5 border-b border-white/10 flex justify-between items-center bg-slate-900/80">
                <h2 class="text-base md:text-lg font-space font-bold text-white"><i class="fas fa-sliders-h text-indigo-400 mr-2"></i>Admin Dashboard</h2>
                <button onclick="closeAdminModal()" class="text-slate-400 hover:text-rose-400 transition-colors"><i class="fas fa-times text-xl"></i></button>
            </div>
            
            <div class="p-4 md:p-6 space-y-4 md:space-y-6 overflow-y-auto max-h-[75vh] custom-scrollbar bg-slate-950/50">
                <!-- Kelola Poin -->
                <div class="bg-slate-900/50 p-4 rounded-xl border border-white/5">
                    <h3 class="text-[10px] md:text-xs font-bold text-indigo-300 mb-3 uppercase tracking-wider"><i class="fas fa-coins mr-1"></i> Kelola Poin User</h3>
                    <div class="flex gap-2 mb-3">
                        <select id="adminUserSelect" class="flex-1 bg-slate-950 border border-white/10 rounded-lg px-2 py-2 text-xs md:text-sm text-white focus:outline-none focus:border-indigo-500"></select>
                        <input type="number" id="adminPointInput" placeholder="Jml Poin" class="w-24 md:w-28 bg-slate-950 border border-white/10 rounded-lg px-2 py-2 text-xs md:text-sm text-white focus:outline-none focus:border-indigo-500">
                    </div>
                    <div class="flex gap-2">
                        <button onclick="updatePoints('add')" class="flex-1 bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500 hover:text-white py-2 rounded-lg text-xs md:text-sm font-bold transition-all border border-emerald-500/30">+ Tambah</button>
                        <button onclick="updatePoints('sub')" class="flex-1 bg-rose-500/20 text-rose-400 hover:bg-rose-500 hover:text-white py-2 rounded-lg text-xs md:text-sm font-bold transition-all border border-rose-500/30">- Kurangi</button>
                    </div>
                </div>

                <!-- Pengaturan Hadiah -->
                <div class="bg-slate-900/50 p-4 rounded-xl border border-white/5">
                    <h3 class="text-[10px] md:text-xs font-bold text-amber-300 mb-3 uppercase tracking-wider"><i class="fas fa-gift mr-1"></i> Pengaturan Prize Pool</h3>
                    <div class="space-y-3">
                        <div>
                            <label class="text-[10px] md:text-[11px] text-slate-400 uppercase tracking-wider">Total Prize Pool</label>
                            <input type="text" id="adminPrizePool" class="w-full bg-slate-950 border border-white/10 rounded-lg px-3 py-2 text-xs md:text-sm text-white mt-1 focus:border-amber-500 focus:outline-none">
                        </div>
                        <div>
                            <label class="text-[10px] md:text-[11px] text-slate-400 uppercase tracking-wider">Hadiah Juara 1</label>
                            <input type="text" id="adminPrize1" class="w-full bg-slate-950 border border-white/10 rounded-lg px-3 py-2 text-xs md:text-sm text-white mt-1 focus:border-amber-500 focus:outline-none">
                        </div>
                        <div>
                            <label class="text-[10px] md:text-[11px] text-slate-400 uppercase tracking-wider">Hadiah Juara 2</label>
                            <input type="text" id="adminPrize2" class="w-full bg-slate-950 border border-white/10 rounded-lg px-3 py-2 text-xs md:text-sm text-white mt-1 focus:border-amber-500 focus:outline-none">
                        </div>
                        <div>
                            <label class="text-[10px] md:text-[11px] text-slate-400 uppercase tracking-wider">Hadiah Juara 3</label>
                            <input type="text" id="adminPrize3" class="w-full bg-slate-950 border border-white/10 rounded-lg px-3 py-2 text-xs md:text-sm text-white mt-1 focus:border-amber-500 focus:outline-none">
                        </div>
                        <div>
                            <label class="text-[10px] md:text-[11px] text-slate-400 uppercase tracking-wider">Batas Waktu (Deadline)</label>
                            <input type="datetime-local" id="adminDeadline" class="w-full bg-slate-950 border border-white/10 rounded-lg px-3 py-2 text-xs md:text-sm text-white mt-1 focus:border-amber-500 focus:outline-none">
                        </div>
                        <button onclick="saveSettings()" class="w-full bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white py-3 rounded-lg text-xs md:text-sm font-bold transition-all mt-4 shadow-[0_0_15px_rgba(99,102,241,0.4)]">Simpan Pengaturan</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/js/main.js?v=<?php echo time(); ?>"></script>
</body>
</html>