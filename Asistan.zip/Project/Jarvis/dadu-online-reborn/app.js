// State Management
let sessions = JSON.parse(localStorage.getItem('dadu_sessions')) || [];
let activeSessionId = null;
let diceCount = 1;
const MAX_DICE = 20;

// DOM Elements
const diceCountDisplay = document.getElementById('diceCountDisplay');
const diceContainer = document.getElementById('diceContainer');
const sessionList = document.getElementById('sessionList');
const currentRollLog = document.getElementById('currentRollLog');
const initialStateContainer = document.getElementById('initialStateContainer');
const subsequentRollsContainer = document.getElementById('subsequentRollsContainer');
const activeSessionHeader = document.getElementById('activeSessionHeader');
const activeSessionTitle = document.getElementById('activeSessionTitle');
const activeSessionTime = document.getElementById('activeSessionTime');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    renderSessionList();
    renderIdleDice();
});

// Controls
document.getElementById('addDiceBtn').addEventListener('click', () => {
    if (diceCount < MAX_DICE) {
        diceCount++;
        updateDiceCount();
        if(!activeSessionId) renderIdleDice();
    }
});

document.getElementById('minDiceBtn').addEventListener('click', () => {
    if (diceCount > 1) {
        diceCount--;
        updateDiceCount();
        if(!activeSessionId) renderIdleDice();
    }
});

document.getElementById('newSessionBtn').addEventListener('click', () => {
    activeSessionId = null;
    currentRollLog.classList.add('hidden');
    activeSessionHeader.classList.add('hidden');
    renderIdleDice();
    renderSessionList();
});

document.getElementById('clearAllBtn').addEventListener('click', () => {
    if(confirm('Apakah Anda yakin ingin menghapus semua riwayat sesi?')) {
        sessions = [];
        saveSessions();
        activeSessionId = null;
        currentRollLog.classList.add('hidden');
        activeSessionHeader.classList.add('hidden');
        renderSessionList();
        renderIdleDice();
    }
});

document.getElementById('rollBtn').addEventListener('click', rollDice);

function updateDiceCount() {
    diceCountDisplay.textContent = diceCount;
}

function renderIdleDice() {
    diceContainer.innerHTML = '';
    for (let i = 0; i < diceCount; i++) {
        diceContainer.appendChild(createDiceElement(6)); // Default show 6
    }
}

function createDiceElement(value) {
    const wrapper = document.createElement('div');
    wrapper.className = 'dice-wrapper';
    
    const dice = document.createElement('div');
    dice.className = 'dice';
    
    const face = document.createElement('div');
    face.className = 'dice-face';
    
    // Logic to place dots based on value
    const dots = [];
    if (value === 1) dots.push('dot-1');
    else if (value === 2) dots.push('dot-2', 'dot-3');
    else if (value === 3) dots.push('dot-2', 'dot-1', 'dot-3');
    else if (value === 4) dots.push('dot-2', 'dot-4', 'dot-5', 'dot-3');
    else if (value === 5) dots.push('dot-2', 'dot-4', 'dot-1', 'dot-5', 'dot-3');
    else if (value === 6) dots.push('dot-2', 'dot-4', 'dot-6', 'dot-7', 'dot-5', 'dot-3');

    dots.forEach(dotClass => {
        const dot = document.createElement('div');
        dot.className = `dot ${dotClass}`;
        face.appendChild(dot);
    });

    dice.appendChild(face);
    wrapper.appendChild(dice);
    return wrapper;
}

function rollDice() {
    const btn = document.getElementById('rollBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-3"></i> MENGACAK...';

    // Add rolling animation
    const allDice = document.querySelectorAll('.dice');
    allDice.forEach(d => d.classList.add('rolling'));

    setTimeout(() => {
        const results = Array.from({length: diceCount}, () => Math.floor(Math.random() * 6) + 1);
        
        // Stop animation and update values
        diceContainer.innerHTML = '';
        results.forEach(val => {
            diceContainer.appendChild(createDiceElement(val));
        });

        processRollResults(results);

        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-dice mr-3 text-xl"></i> GACHA SEKARANG';
    }, 800);
}

function processRollResults(results) {
    let session;
    
    if (!activeSessionId) {
        // Create New Session (Initial State)
        session = {
            id: 'ses_' + Date.now(),
            timestamp: new Date().toISOString(),
            diceCount: diceCount,
            initialState: results,
            subsequentRolls: []
        };
        sessions.unshift(session); // Add to top
        activeSessionId = session.id;
    } else {
        // Add to existing session
        session = sessions.find(s => s.id === activeSessionId);
        if (session) {
            session.subsequentRolls.push({
                rollIndex: session.subsequentRolls.length + 1,
                results: results
            });
        }
    }

    saveSessions();
    renderSessionList();
    renderActiveSessionLog();
}

function saveSessions() {
    localStorage.setItem('dadu_sessions', JSON.stringify(sessions));
}

function renderSessionList() {
    sessionList.innerHTML = '';
    
    if (sessions.length === 0) {
        sessionList.innerHTML = '<div class="text-center text-slate-500 text-sm mt-10">Belum ada riwayat sesi.</div>';
        return;
    }

    sessions.forEach((session, index) => {
        const date = new Date(session.timestamp);
        const timeString = date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
        const dateString = date.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
        
        const isActive = session.id === activeSessionId;
        
        const card = document.createElement('div');
        card.className = `session-card p-3 rounded-xl border border-white/5 cursor-pointer flex justify-between items-center ${isActive ? 'active' : 'bg-slate-900/40'}`;
        card.onclick = () => loadSession(session.id);
        
        card.innerHTML = `
            <div>
                <div class="font-space font-semibold text-sm ${isActive ? 'text-indigo-300' : 'text-slate-300'}">Sesi #${sessions.length - index}</div>
                <div class="text-xs text-slate-500 mt-1"><i class="far fa-clock mr-1"></i> ${dateString}, ${timeString}</div>
            </div>
            <div class="flex flex-col items-end">
                <span class="text-xs font-bold bg-slate-800 px-2 py-1 rounded text-slate-300">${session.diceCount} Dadu</span>
                <span class="text-[10px] text-slate-500 mt-1">${session.subsequentRolls.length} Lemparan</span>
            </div>
        `;
        sessionList.appendChild(card);
    });
}

function loadSession(id) {
    activeSessionId = id;
    const session = sessions.find(s => s.id === id);
    if (!session) return;

    diceCount = session.diceCount;
    updateDiceCount();
    
    // Show last roll in arena, or initial state if no subsequent rolls
    const lastResults = session.subsequentRolls.length > 0 
        ? session.subsequentRolls[session.subsequentRolls.length - 1].results 
        : session.initialState;
        
    diceContainer.innerHTML = '';
    lastResults.forEach(val => {
        diceContainer.appendChild(createDiceElement(val));
    });

    renderSessionList();
    renderActiveSessionLog();
}

function renderActiveSessionLog() {
    const session = sessions.find(s => s.id === activeSessionId);
    if (!session) return;

    activeSessionHeader.classList.remove('hidden');
    currentRollLog.classList.remove('hidden');
    
    const date = new Date(session.timestamp);
    activeSessionTitle.textContent = `Sesi Aktif (${session.diceCount} Dadu)`;
    activeSessionTime.textContent = `Dimulai: ${date.toLocaleString('id-ID')}`;

    // Render Initial State
    initialStateContainer.innerHTML = '';
    session.initialState.forEach(val => {
        initialStateContainer.innerHTML += `<span class="w-8 h-8 flex items-center justify-center bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 rounded font-bold">${val}</span>`;
    });

    // Render Subsequent Rolls
    subsequentRollsContainer.innerHTML = '';
    if (session.subsequentRolls.length === 0) {
        subsequentRollsContainer.innerHTML = '<div class="text-sm text-slate-500 italic">Belum ada lemparan lanjutan.</div>';
    } else {
        // Reverse to show newest first
        [...session.subsequentRolls].reverse().forEach(roll => {
            const rollDiv = document.createElement('div');
            rollDiv.className = 'flex items-center bg-slate-900/50 p-2 rounded-lg border border-white/5';
            
            let diceHtml = roll.results.map(val => 
                `<span class="w-7 h-7 flex items-center justify-center bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded text-sm font-bold">${val}</span>`
            ).join('');

            rollDiv.innerHTML = `
                <div class="w-24 text-xs text-slate-400 font-space">Lemparan ke-${roll.rollIndex}</div>
                <div class="flex flex-wrap gap-1 flex-1">${diceHtml}</div>
            `;
            subsequentRollsContainer.appendChild(rollDiv);
        });
    }
}
