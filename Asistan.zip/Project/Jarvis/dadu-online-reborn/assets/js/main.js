// State Management
let activeSessionId = null;
let diceCount = 1;
const MAX_DICE = 20;
let isNewSessionRequested = false;
let serverHistory = {};
let countdownInterval = null;

// DOM Elements
const diceCountDisplay = document.getElementById('diceCountDisplay');
const diceContainer = document.getElementById('diceContainer');
const sessionList = document.getElementById('sessionList');
const currentRollLog = document.getElementById('currentRollLog');
const initialStateContainer = document.getElementById('initialStateContainer');
const subsequentRollsContainer = document.getElementById('subsequentRollsContainer');
const activeSessionHeader = document.getElementById('activeSessionHeader');
const activeSessionTitle = document.getElementById('activeSessionTitle');
const activeSessionTime = document.getElementById('activeSessionTime');
const totalDisplay = document.getElementById('totalDisplay');

// Leaderboard Elements
const leaderboardContainer = document.getElementById('leaderboardContainer');
const lbPrizePool = document.getElementById('lbPrizePool');
const lbCountdown = document.getElementById('lbCountdown');

// Pemetaan rotasi CSS 3D untuk setiap angka dadu agar menghadap ke depan
const faceRotations = {
    1: { x: 0, y: 0 },
    2: { x: 0, y: -90 },
    3: { x: -90, y: 0 },
    4: { x: 90, y: 0 },
    5: { x: 0, y: 90 },
    6: { x: 180, y: 0 }
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadHistoryFromServer();
    loadLeaderboard();
});

// Mobile Tab Navigation
function switchTab(tab) {
    const history = document.getElementById('sidebarHistory');
    const leaderboard = document.getElementById('sidebarLeaderboard');
    const navHistory = document.getElementById('navHistory');
    const navLeaderboard = document.getElementById('navLeaderboard');
    
    // Reset Nav Colors
    navHistory.classList.remove('text-indigo-400');
    navHistory.classList.add('text-slate-500');
    navLeaderboard.classList.remove('text-amber-400');
    navLeaderboard.classList.add('text-slate-500');

    if (tab === 'history') {
        history.classList.remove('-translate-x-full');
        leaderboard.classList.add('translate-x-full');
        navHistory.classList.remove('text-slate-500');
        navHistory.classList.add('text-indigo-400');
    } else if (tab === 'leaderboard') {
        history.classList.add('-translate-x-full');
        leaderboard.classList.remove('translate-x-full');
        navLeaderboard.classList.remove('text-slate-500');
        navLeaderboard.classList.add('text-amber-400');
    } else {
        // Arena (Default)
        history.classList.add('-translate-x-full');
        leaderboard.classList.add('translate-x-full');
    }
}

// Controls
document.getElementById('addDiceBtn').addEventListener('click', () => {
    if (diceCount < MAX_DICE) {
        diceCount++;
        updateDiceCount();
        
        const newVal = Math.floor(Math.random() * 6) + 1;
        const die = createDiceElement(newVal, true);
        diceContainer.appendChild(die);
        
        const dice3d = die.querySelector('.dice-3d');
        setTimeout(() => {
            applyRotation(dice3d, newVal, false);
            setTimeout(updateTotalDisplay, 1000);
        }, 50);
    }
});

document.getElementById('minDiceBtn').addEventListener('click', () => {
    if (diceCount > 1) {
        diceCount--;
        updateDiceCount();
        if (diceContainer.lastChild) {
            diceContainer.removeChild(diceContainer.lastChild);
            updateTotalDisplay();
        }
    }
});

document.getElementById('newSessionBtn').addEventListener('click', () => {
    activeSessionId = null;
    isNewSessionRequested = true;
    currentRollLog.classList.add('hidden');
    activeSessionHeader.classList.add('hidden');
    
    document.querySelectorAll('.session-card').forEach(card => {
        card.classList.remove('active');
        card.classList.add('bg-slate-900/40');
    });
    
    if(window.innerWidth < 768) switchTab('arena');
    rollDice();
});

document.getElementById('clearAllBtn').addEventListener('click', async () => {
    if(confirm('Apakah Anda yakin ingin menghapus semua riwayat sesi dari database?')) {
        try {
            const response = await fetch('api/clear.php');
            const data = await response.json();
            if(data.success) {
                activeSessionId = null;
                isNewSessionRequested = false;
                currentRollLog.classList.add('hidden');
                activeSessionHeader.classList.add('hidden');
                diceContainer.innerHTML = '';
                totalDisplay.textContent = '0';
                loadHistoryFromServer();
                if(window.innerWidth < 768) switchTab('arena');
            }
        } catch (e) {
            console.error("Gagal menghapus riwayat", e);
        }
    }
});

document.getElementById('rollBtn').addEventListener('click', rollDice);

function updateDiceCount() {
    diceCountDisplay.textContent = diceCount;
}

function createDiceElement(value, instant = false) {
    const wrapper = document.createElement('div');
    wrapper.className = 'dice-wrapper';
    
    const die = document.createElement('div');
    die.className = 'dice-3d';
    die.dataset.value = value;
    die.innerHTML = `
        <div class="face front"><div class="dot c"></div></div>
        <div class="face right"><div class="dot tl"></div><div class="dot br"></div></div>
        <div class="face top"><div class="dot tl"></div><div class="dot c"></div><div class="dot br"></div></div>
        <div class="face bottom"><div class="dot tl"></div><div class="dot tr"></div><div class="dot bl"></div><div class="dot br"></div></div>
        <div class="face left"><div class="dot tl"></div><div class="dot tr"></div><div class="dot c"></div><div class="dot bl"></div><div class="dot br"></div></div>
        <div class="face back"><div class="dot tl"></div><div class="dot tr"></div><div class="dot ml"></div><div class="dot mr"></div><div class="dot bl"></div><div class="dot br"></div></div>
    `;
    
    die.addEventListener('click', () => {
        const newValue = Math.floor(Math.random() * 6) + 1;
        die.dataset.value = newValue;
        applyRotation(die, newValue, false);
        setTimeout(updateTotalDisplay, 1000);
    });

    applyRotation(die, value, instant);
    wrapper.appendChild(die);
    return wrapper;
}

function applyRotation(dieElement, faceValue, instant = false) {
    const rot = faceRotations[faceValue];
    
    if (instant) {
        dieElement.style.transition = 'none';
        dieElement.style.transform = `rotateX(${rot.x}deg) rotateY(${rot.y}deg)`;
        dieElement.dataset.rotX = rot.x;
        dieElement.dataset.rotY = rot.y;
        return;
    }

    let currentX = parseFloat(dieElement.dataset.rotX) || 0;
    let currentY = parseFloat(dieElement.dataset.rotY) || 0;

    let normX = currentX % 360;
    let normY = currentY % 360;
    if (normX < 0) normX += 360;
    if (normY < 0) normY += 360;

    let diffX = rot.x - normX;
    let diffY = rot.y - normY;

    let spinsX = (Math.floor(Math.random() * 3) + 2) * 360;
    let spinsY = (Math.floor(Math.random() * 3) + 2) * 360;

    if (Math.random() > 0.5) spinsX *= -1;
    if (Math.random() > 0.5) spinsY *= -1;

    let newX = currentX + diffX + spinsX;
    let newY = currentY + diffY + spinsY;

    dieElement.style.transition = 'transform 1s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
    dieElement.style.transform = `rotateX(${newX}deg) rotateY(${newY}deg)`;
    
    dieElement.dataset.rotX = newX;
    dieElement.dataset.rotY = newY;
}

function updateTotalDisplay() {
    const diceElements = document.querySelectorAll('.dice-3d');
    let total = 0;
    diceElements.forEach(d => {
        total += parseInt(d.dataset.value) || 0;
    });
    
    totalDisplay.style.transform = 'scale(1.2)';
    totalDisplay.textContent = total;
    setTimeout(() => {
        totalDisplay.style.transform = 'scale(1)';
    }, 200);
}

async function rollDice() {
    const btn = document.getElementById('rollBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2 md:mr-3"></i> <span class="hidden sm:inline">MENGACAK...</span><span class="sm:hidden">ACAK</span>';

    const diceElements = document.querySelectorAll('.dice-3d');
    
    diceElements.forEach(die => {
        let currentX = parseFloat(die.dataset.rotX) || 0;
        let currentY = parseFloat(die.dataset.rotY) || 0;
        die.style.transition = 'transform 0.5s linear';
        die.style.transform = `rotateX(${currentX + 360}deg) rotateY(${currentY + 360}deg)`;
    });

    try {
        const formData = new FormData();
        formData.append('dice_count', diceCount);
        if (isNewSessionRequested) {
            formData.append('new_session', 'true');
            isNewSessionRequested = false;
        }

        const response = await fetch('api/roll.php', {
            method: 'POST',
            body: formData
        });
        const data = await response.json();

        if (data.success) {
            setTimeout(() => {
                const currentDiceElements = document.querySelectorAll('.dice-wrapper');
                
                if (currentDiceElements.length === data.dice_values.length) {
                    data.dice_values.forEach((val, index) => {
                        const dice3d = currentDiceElements[index].querySelector('.dice-3d');
                        dice3d.dataset.value = val;
                        applyRotation(dice3d, val, false);
                    });
                } else {
                    diceContainer.innerHTML = '';
                    data.dice_values.forEach(val => {
                        diceContainer.appendChild(createDiceElement(val, false));
                    });
                }

                setTimeout(updateTotalDisplay, 1000);
                activeSessionId = data.session_number;
                loadHistoryFromServer();

                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-dice mr-2 md:mr-3 text-lg md:text-xl"></i> <span class="hidden sm:inline">GACHA SEKARANG</span><span class="sm:hidden">GACHA</span>';
            }, 500);
        }
    } catch (error) {
        console.error("Error rolling dice:", error);
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-dice mr-2 md:mr-3 text-lg md:text-xl"></i> <span class="hidden sm:inline">GACHA SEKARANG</span><span class="sm:hidden">GACHA</span>';
    }
}

async function loadHistoryFromServer() {
    try {
        const response = await fetch('api/history.php');
        const data = await response.json();
        
        if (data.success) {
            serverHistory = data.data;
            renderSessionList();
            
            if (Object.keys(serverHistory).length === 0) {
                rollDice();
            } else {
                if (activeSessionId && serverHistory[activeSessionId]) {
                    renderActiveSessionLog(activeSessionId);
                } else {
                    const sessionKeys = Object.keys(serverHistory).sort((a,b) => b - a);
                    activeSessionId = sessionKeys[0];
                    loadSession(activeSessionId, true);
                }
            }
        }
    } catch (error) {
        console.error("Error loading history:", error);
    }
}

function renderSessionList() {
    sessionList.innerHTML = '';
    const sessionKeys = Object.keys(serverHistory).sort((a,b) => b - a);

    if (sessionKeys.length === 0) {
        sessionList.innerHTML = '<div class="text-center text-slate-500 text-sm mt-10">Belum ada riwayat sesi.</div>';
        return;
    }

    sessionKeys.forEach((sessionNum) => {
        const rolls = serverHistory[sessionNum];
        const firstRoll = rolls[0];
        
        const date = new Date(firstRoll.created_at);
        const timeString = date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
        const dateString = date.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
        
        const isActive = sessionNum == activeSessionId;
        
        const card = document.createElement('div');
        card.className = `session-card p-3 rounded-xl border border-white/5 cursor-pointer flex justify-between items-center ${isActive ? 'active' : 'bg-slate-900/40'}`;
        card.onclick = () => loadSession(sessionNum, true);
        
        card.innerHTML = `
            <div>
                <div class="font-space font-semibold text-sm ${isActive ? 'text-indigo-300' : 'text-slate-300'}">Sesi #${sessionNum}</div>
                <div class="text-xs text-slate-500 mt-1"><i class="far fa-clock mr-1"></i> ${dateString}, ${timeString}</div>
            </div>
            <div class="flex flex-col items-end">
                <span class="text-xs font-bold bg-slate-800 px-2 py-1 rounded text-slate-300">${firstRoll.dice_values.length} Dadu</span>
                <span class="text-[10px] text-slate-500 mt-1">${rolls.length} Lemparan</span>
            </div>
        `;
        sessionList.appendChild(card);
    });
}

function loadSession(sessionNum, spinIn = false) {
    activeSessionId = sessionNum;
    isNewSessionRequested = false;
    
    const rolls = serverHistory[sessionNum];
    if (!rolls || rolls.length === 0) return;

    diceCount = rolls[0].dice_values.length;
    updateDiceCount();
    
    const lastRoll = rolls[rolls.length - 1];
        
    diceContainer.innerHTML = '';
    lastRoll.dice_values.forEach(val => {
        const die = createDiceElement(val, true);
        diceContainer.appendChild(die);
        
        if (spinIn) {
            const dice3d = die.querySelector('.dice-3d');
            applyRotation(dice3d, 1, true);
            setTimeout(() => applyRotation(dice3d, val, false), 50);
        }
    });

    if (spinIn) {
        setTimeout(updateTotalDisplay, 1000);
    } else {
        updateTotalDisplay();
    }

    renderSessionList();
    renderActiveSessionLog(sessionNum);
    
    // Auto switch to arena on mobile when loading a session
    if(window.innerWidth < 768) switchTab('arena');
}

function renderActiveSessionLog(sessionNum) {
    const rolls = serverHistory[sessionNum];
    if (!rolls || rolls.length === 0) return;

    activeSessionHeader.classList.remove('hidden');
    currentRollLog.classList.remove('hidden');
    
    const firstRoll = rolls[0];
    const date = new Date(firstRoll.created_at);
    
    activeSessionTitle.textContent = `Sesi Aktif #${sessionNum}`;
    activeSessionTime.textContent = `Dimulai: ${date.toLocaleString('id-ID')}`;

    initialStateContainer.innerHTML = '';
    firstRoll.dice_values.forEach(val => {
        initialStateContainer.innerHTML += `<span class="w-7 h-7 md:w-8 md:h-8 flex items-center justify-center bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 rounded text-sm md:text-base font-bold">${val}</span>`;
    });

    subsequentRollsContainer.innerHTML = '';
    if (rolls.length <= 1) {
        subsequentRollsContainer.innerHTML = '<div class="text-xs md:text-sm text-slate-500 italic">Belum ada lemparan lanjutan.</div>';
    } else {
        const subsequent = rolls.slice(1).reverse();
        
        subsequent.forEach(roll => {
            const rollDiv = document.createElement('div');
            rollDiv.className = 'flex items-center bg-slate-900/50 p-2 rounded-lg border border-white/5';
            
            let diceHtml = roll.dice_values.map(val => 
                `<span class="w-6 h-6 md:w-7 md:h-7 flex items-center justify-center bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded text-xs md:text-sm font-bold">${val}</span>`
            ).join('');

            rollDiv.innerHTML = `
                <div class="w-20 md:w-24 text-[10px] md:text-xs text-slate-400 font-space">Lemparan ke-${roll.roll_number}</div>
                <div class="flex flex-wrap gap-1 flex-1">${diceHtml}</div>
            `;
            subsequentRollsContainer.appendChild(rollDiv);
        });
    }
}

// ==========================================
// LEADERBOARD & ADMIN LOGIC
// ==========================================

async function loadLeaderboard() {
    try {
        const response = await fetch('api/leaderboard.php');
        const data = await response.json();
        
        if (data.success) {
            lbPrizePool.textContent = data.settings.prize_pool;
            startCountdown(data.settings.deadline);
            
            document.getElementById('adminPrizePool').value = data.settings.prize_pool;
            document.getElementById('adminPrize1').value = data.settings.prize_1;
            document.getElementById('adminPrize2').value = data.settings.prize_2;
            document.getElementById('adminPrize3').value = data.settings.prize_3;
            document.getElementById('adminDeadline').value = data.settings.deadline;

            leaderboardContainer.innerHTML = '';
            const userSelect = document.getElementById('adminUserSelect');
            userSelect.innerHTML = '';

            data.users.forEach((user, index) => {
                const rank = index + 1;
                let rankClass = 'rank-other';
                let icon = `<span class="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-400">${rank}</span>`;
                let prizeText = '';

                if (rank === 1) {
                    rankClass = 'rank-1';
                    icon = `<i class="fas fa-crown text-amber-400 text-xl drop-shadow-[0_0_5px_rgba(251,191,36,0.8)]"></i>`;
                    prizeText = `<div class="text-[10px] text-amber-300 mt-1"><i class="fas fa-gift mr-1"></i>${data.settings.prize_1}</div>`;
                } else if (rank === 2) {
                    rankClass = 'rank-2';
                    icon = `<i class="fas fa-medal text-slate-300 text-lg"></i>`;
                    prizeText = `<div class="text-[10px] text-slate-300 mt-1"><i class="fas fa-gift mr-1"></i>${data.settings.prize_2}</div>`;
                } else if (rank === 3) {
                    rankClass = 'rank-3';
                    icon = `<i class="fas fa-medal text-amber-700 text-lg"></i>`;
                    prizeText = `<div class="text-[10px] text-amber-600 mt-1"><i class="fas fa-gift mr-1"></i>${data.settings.prize_3}</div>`;
                }

                const card = document.createElement('div');
                card.className = `rank-card p-3 rounded-xl flex items-center gap-3 ${rankClass}`;
                card.innerHTML = `
                    <div class="w-8 flex justify-center">${icon}</div>
                    <div class="flex-1">
                        <div class="font-space font-bold text-sm text-white">${user.username}</div>
                        <div class="text-xs font-bold text-indigo-300">${user.points.toLocaleString('id-ID')} Pts</div>
                        ${prizeText}
                    </div>
                `;
                leaderboardContainer.appendChild(card);

                userSelect.innerHTML += `<option value="${user.id}">${user.username} (${user.points} Pts)</option>`;
            });
        }
    } catch (error) {
        console.error("Error loading leaderboard:", error);
    }
}

function startCountdown(deadlineStr) {
    if (countdownInterval) clearInterval(countdownInterval);
    
    const deadline = new Date(deadlineStr).getTime();
    
    countdownInterval = setInterval(() => {
        const now = new Date().getTime();
        const distance = deadline - now;
        
        if (distance < 0) {
            clearInterval(countdownInterval);
            lbCountdown.textContent = "WAKTU HABIS";
            return;
        }
        
        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        lbCountdown.textContent = `${days}d ${hours.toString().padStart(2, '0')}h ${minutes.toString().padStart(2, '0')}m ${seconds.toString().padStart(2, '0')}s`;
    }, 1000);
}

// Admin Modal Functions
function openAdminModal() {
    const modal = document.getElementById('adminModal');
    const content = document.getElementById('adminModalContent');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    
    setTimeout(() => {
        modal.classList.remove('opacity-0');
        content.classList.remove('scale-95');
        content.classList.add('scale-100');
    }, 10);
}

function closeAdminModal() {
    const modal = document.getElementById('adminModal');
    const content = document.getElementById('adminModalContent');
    
    modal.classList.add('opacity-0');
    content.classList.remove('scale-100');
    content.classList.add('scale-95');
    
    setTimeout(() => {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }, 300);
}

async function updatePoints(operation) {
    const userId = document.getElementById('adminUserSelect').value;
    const amount = document.getElementById('adminPointInput').value;
    
    if (!amount || amount <= 0) {
        alert("Masukkan jumlah poin yang valid!");
        return;
    }

    try {
        const formData = new FormData();
        formData.append('action', 'update_points');
        formData.append('user_id', userId);
        formData.append('amount', amount);
        formData.append('operation', operation);

        const response = await fetch('api/admin.php', { method: 'POST', body: formData });
        const data = await response.json();
        
        if (data.success) {
            document.getElementById('adminPointInput').value = '';
            loadLeaderboard();
        }
    } catch (error) {
        console.error("Error updating points:", error);
    }
}

async function saveSettings() {
    try {
        const formData = new FormData();
        formData.append('action', 'update_settings');
        formData.append('prize_pool', document.getElementById('adminPrizePool').value);
        formData.append('prize_1', document.getElementById('adminPrize1').value);
        formData.append('prize_2', document.getElementById('adminPrize2').value);
        formData.append('prize_3', document.getElementById('adminPrize3').value);
        formData.append('deadline', document.getElementById('adminDeadline').value);

        const response = await fetch('api/admin.php', { method: 'POST', body: formData });
        const data = await response.json();
        
        if (data.success) {
            alert("Pengaturan berhasil disimpan!");
            loadLeaderboard();
            closeAdminModal();
        }
    } catch (error) {
        console.error("Error saving settings:", error);
    }
}