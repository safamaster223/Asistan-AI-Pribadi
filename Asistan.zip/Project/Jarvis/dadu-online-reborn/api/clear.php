<?php
header('Content-Type: application/json');
require 'db.php';

try {
    $pdo->exec("TRUNCATE TABLE rolls");
    $pdo->exec("DELETE FROM sessions");
    $pdo->exec("ALTER TABLE sessions AUTO_INCREMENT = 1");
    
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>