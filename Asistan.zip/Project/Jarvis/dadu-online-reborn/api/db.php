<?php
$host = 'localhost';
$dbname = 'dadu_online';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Auto-create database and tables
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname`");
    $pdo->exec("USE `$dbname`");
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS sessions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        session_number INT NOT NULL,
        is_active TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS rolls (
        id INT AUTO_INCREMENT PRIMARY KEY,
        session_id INT NOT NULL,
        roll_number INT NOT NULL,
        dice_count INT NOT NULL,
        dice_values JSON NOT NULL,
        total_sum INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (session_id) REFERENCES sessions(id)
    )");

    // NEW: Users Table for Leaderboard
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL,
        points INT DEFAULT 0
    )");

    // NEW: Settings Table for Prize Pool
    $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
        setting_key VARCHAR(50) PRIMARY KEY,
        setting_value TEXT
    )");

    // Seed Dummy Data if empty
    $stmt = $pdo->query("SELECT COUNT(*) FROM users");
    if ($stmt->fetchColumn() == 0) {
        $pdo->exec("INSERT INTO users (username, points) VALUES 
            ('Cellya Claire', 8500), 
            ('Rio Amakawa', 7200), 
            ('Latifa', 5400), 
            ('Aishia', 3100)");
            
        $pdo->exec("INSERT INTO settings (setting_key, setting_value) VALUES 
            ('prize_pool', 'Rp 15.000.000'),
            ('prize_1', 'Rp 7.500.000 + RTX 4070'),
            ('prize_2', 'Rp 5.000.000'),
            ('prize_3', 'Rp 2.500.000'),
            ('deadline', '" . date('Y-m-t 23:59:59') . "')
        ");
    }

} catch (PDOException $e) {
    die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
}
?>