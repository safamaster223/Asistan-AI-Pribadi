<?php
header('Content-Type: application/json');
require 'db.php';

$action = $_POST['action'] ?? '';

try {
    if ($action === 'update_points') {
        $user_id = (int)$_POST['user_id'];
        $amount = (int)$_POST['amount'];
        $operation = $_POST['operation']; // 'add' or 'sub'

        if ($operation === 'add') {
            $stmt = $pdo->prepare("UPDATE users SET points = points + ? WHERE id = ?");
        } else {
            $stmt = $pdo->prepare("UPDATE users SET points = GREATEST(0, points - ?) WHERE id = ?");
        }
        $stmt->execute([$amount, $user_id]);
        
        echo json_encode(['success' => true]);
    } 
    elseif ($action === 'update_settings') {
        $prize_pool = $_POST['prize_pool'];
        $prize_1 = $_POST['prize_1'];
        $prize_2 = $_POST['prize_2'];
        $prize_3 = $_POST['prize_3'];
        $deadline = $_POST['deadline'];

        $stmt = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = ?");
        $stmt->execute([$prize_pool, 'prize_pool']);
        $stmt->execute([$prize_1, 'prize_1']);
        $stmt->execute([$prize_2, 'prize_2']);
        $stmt->execute([$prize_3, 'prize_3']);
        $stmt->execute([$deadline, 'deadline']);

        echo json_encode(['success' => true]);
    }
    else {
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>