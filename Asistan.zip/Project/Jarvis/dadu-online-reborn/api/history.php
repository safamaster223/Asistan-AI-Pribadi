<?php
header('Content-Type: application/json');
require 'db.php';

try {
    // Ambil semua riwayat, diurutkan dari sesi terbaru dan putaran terbaru
    $stmt = $pdo->query("
        SELECT s.session_number, r.roll_number, r.dice_values, r.total_sum, r.created_at 
        FROM sessions s 
        JOIN rolls r ON s.id = r.session_id 
        ORDER BY s.session_number DESC, r.roll_number ASC
    ");
    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Kelompokkan berdasarkan nomor sesi
    $grouped = [];
    foreach ($history as $row) {
        $sess = $row['session_number'];
        if (!isset($grouped[$sess])) {
            $grouped[$sess] = [];
        }
        $row['dice_values'] = json_decode($row['dice_values']);
        $grouped[$sess][] = $row;
    }
    
    echo json_encode(['success' => true, 'data' => $grouped]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>