<?php
header('Content-Type: application/json');
require 'db.php';

try {
    // Get Top Users
    $stmt = $pdo->query("SELECT id, username, points FROM users ORDER BY points DESC LIMIT 10");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get Settings
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
    $settings_raw = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $settings = [];
    foreach ($settings_raw as $row) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }

    echo json_encode([
        'success' => true,
        'users' => $users,
        'settings' => $settings
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>