<?php
header('Content-Type: application/json');
require 'db.php';

$dice_count = isset($_POST['dice_count']) ? (int)$_POST['dice_count'] : 1;
$force_new_session = isset($_POST['new_session']) && $_POST['new_session'] === 'true';

if ($dice_count < 1) $dice_count = 1;
if ($dice_count > 20) $dice_count = 20; // Batas maksimal dadu

try {
    $pdo->beginTransaction();

    // Cari sesi yang masih aktif
    $stmt = $pdo->query("SELECT * FROM sessions WHERE is_active = 1 ORDER BY id DESC LIMIT 1");
    $session = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($force_new_session && $session) {
        // Tutup sesi saat ini jika dipaksa buat baru
        $stmt = $pdo->prepare("UPDATE sessions SET is_active = 0 WHERE id = ?");
        $stmt->execute([$session['id']]);
        $session = false; // Anggap tidak ada sesi aktif
    }

    if (!$session) {
        // Cari nomor sesi terakhir untuk increment
        $stmt = $pdo->query("SELECT MAX(session_number) as max_sess FROM sessions");
        $max_sess = $stmt->fetch(PDO::FETCH_ASSOC);
        $new_session_number = ($max_sess['max_sess'] ?? 0) + 1;

        // Buat sesi baru
        $stmt = $pdo->prepare("INSERT INTO sessions (session_number, is_active) VALUES (?, 1)");
        $stmt->execute([$new_session_number]);
        
        $session_id = $pdo->lastInsertId();
        $session_number = $new_session_number;
        $current_roll_number = 1;
    } else {
        $session_id = $session['id'];
        $session_number = $session['session_number'];
        
        // Hitung jumlah putaran di sesi ini
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM rolls WHERE session_id = ?");
        $stmt->execute([$session_id]);
        $roll_count = $stmt->fetchColumn();

        $current_roll_number = $roll_count + 1;
    }

    // Generate nilai dadu secara acak dan aman
    $dice_values = [];
    $total_sum = 0;
    for ($i = 0; $i < $dice_count; $i++) {
        $val = random_int(1, 6);
        $dice_values[] = $val;
        $total_sum += $val;
    }

    // Simpan riwayat putaran
    $stmt = $pdo->prepare("INSERT INTO rolls (session_id, roll_number, dice_count, dice_values, total_sum) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$session_id, $current_roll_number, $dice_count, json_encode($dice_values), $total_sum]);

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'session_number' => $session_number,
        'roll_number' => $current_roll_number,
        'dice_values' => $dice_values,
        'total_sum' => $total_sum
    ]);

} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>