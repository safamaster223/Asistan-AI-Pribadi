import os
import subprocess
import sys

def install_and_convert():
    print("Memeriksa dependensi markdown-pdf...")
    try:
        import markdown_pdf
    except ImportError:
        print("Menginstal markdown-pdf...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "markdown-pdf"])
        
    from markdown_pdf import MarkdownPdf, Section
    
    md_path = "Cellya_Outputs/Laporan_Materi_4_Logistic_Regression.md"
    pdf_path = "Cellya_Outputs/Laporan_Materi_4_Logistic_Regression.pdf"
    
    print(f"Membaca file {md_path}...")
    with open(md_path, "r", encoding="utf-8") as f:
        content = f.read()
        
    # Menambahkan placeholder gambar agar user tahu di mana harus meletakkan gambar
    content = content.replace(
        "## 5.3. Evaluasi Model: Confusion Matrix dan Metrik Kinerja", 
        "## 5.3. Evaluasi Model: Confusion Matrix dan Metrik Kinerja\n\n> **[PLACEHOLDER GAMBAR: Masukkan Gambar Slide Confusion Matrix di sini]**\n"
    )
    content = content.replace(
        "### 6.2. Studi Kasus Perhitungan Gini Impurity", 
        "### 6.2. Studi Kasus Perhitungan Gini Impurity\n\n> **[PLACEHOLDER GAMBAR: Masukkan Gambar Slide Gini Impurity Box A & Box B di sini]**\n"
    )
    content = content.replace(
        "### 6.3. Studi Kasus: Iris Classification", 
        "### 6.3. Studi Kasus: Iris Classification\n\n> **[PLACEHOLDER GAMBAR: Masukkan Gambar Slide Decision Tree Iris di sini]**\n"
    )
    
    # Menyimpan kembali MD yang sudah diupdate
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(content)
        
    print("Mengonversi ke PDF...")
    pdf = MarkdownPdf(toc_level=2)
    pdf.add_section(Section(content))
    pdf.save(pdf_path)
    print(f"Berhasil! PDF disimpan di {pdf_path}")

if __name__ == "__main__":
    install_and_convert()