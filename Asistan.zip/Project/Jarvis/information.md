# Jarvis Assistant - Architecture, Flow & Setup Information

Dokumen ini menjelaskan alur kerja (workflow), fitur-fitur, cara instalasi/setup API Key di berbagai perangkat, serta cara menjalankan dan menghentikan asisten desktop pintar **Jarvis**.

---

## 1. Fitur Utama Jarvis Assistant

Asisten desktop Jarvis memiliki kemampuan utama sebagai berikut:
1. **Floating Overlay Widget**:
   * Menampilkan gelembung bundar melayang yang responsif di atas semua jendela aplikasi lainnya (*Always on Top*).
   * Memiliki 2 mode visual avatar Lottie Animasi:
     * **Serious Mode (Teacher)** menggunakan visual *Square Box.json* (disimpan sebagai `serious.json`).
     * **Fun Mode (Cat)** menggunakan visual *laughing cat.json* (disimpan sebagai `fun.json`).
   * Gelembung dapat digeser (*drag-and-drop*) ke posisi layar mana pun dan koordinatnya akan disimpan secara otomatis.
   * Cukup klik ganda (double-click) pada gelembung untuk membuka/menutup jendela obrolan (Chat Window).
2. **Interactive Chat Window**:
   * Dialog interaktif untuk mengajukan perintah atau pertanyaan secara real-time.
   * Didukung fitur pemilih model AI (Model Selector) secara instan.
   * Panel Statistik Penggunaan API Harian (Daily API Usage Stats) yang dapat dipantau langsung untuk membatasi kuota harian.
3. **Perekaman Layar (Screen Capture)**:
   * Tombol kamera (📸) untuk mengambil cuplikan layar aktif secara otomatis, melampirkannya sebagai gambar masukan (Multimodal Vision), dan mengirimkannya ke AI.
4. **Alat Pengelola File Lokal (File Operations)**:
   * **get_project_tree**: Memetakan struktur folder utama proyek secara rekursif (mengabaikan file biner/sampah).
   * **read_file**: Membaca isi file teks secara lokal.
   * **write_file**: Membuat baru atau memodifikasi file teks.
   * **delete_file**: Menghapus file atau folder.
   * **list_directory_contents**: Melihat isi folder secara terperinci (ukuran file, waktu modifikasi).
5. **Eksekusi Perintah Terminal Terproteksi**:
   * **execute_terminal_command**: Menjalankan skrip PowerShell atau CMD langsung di komputer.
   * **Sistem Keamanan**: Setiap kali Jarvis memicu eksekusi perintah terminal, aplikasi akan menampilkan pop-up kotak dialog konfirmasi (`QMessageBox` Permission Required). Perintah tidak akan dijalankan kecuali pengguna memilih tombol **Yes**.
6. **Membaca PDF Lokal & Online**:
   * **PDF Lokal**: Membaca file `.pdf` yang ada di workspace lokal pengguna atau folder Downloads dengan cara mengekstrak teksnya halaman-demi-halaman menggunakan pustaka `pypdf`.
   * **PDF Online**: Membaca file `.pdf` secara langsung dari tautan/URL browser aktif di latar belakang tanpa mengunduhnya ke harddisk (langsung diproses melalui memori RAM).
7. **Voice Mode (Text-to-Speech)**:
   * Memiliki tombol toggle audio (mute/unmute) di bagian baris atas Chat Window.
   * Jika diaktifkan, Jarvis akan membacakan seluruh respons teks asisten secara langsung menggunakan mesin suara Windows SAPI5 bawaan di dalam thread terpisah agar antarmuka aplikasi tidak membeku (*freeze*).

---

## 2. Alur Kerja (Workflow)

```
[Pengguna] ────(Klik Ganda Bubble)────> [OverlayWidget (QtWebEngineView + Lottie)]
    │                                                      │ (Toggles)
    │                                                      ▼
    ├───────(Kirim Pesan / Capture)──────────────> [ChatWindow]
    │                                                      │
    ▼                                                      ▼
[AIRequestWorker (QThread)] <───(Proses Latar Belakang)─── [JarvisApp (main.py)]
    │
    ├─> Hubungi AI API (Groq / Gemini / Gravity)
    │
    ├─> Mendapatkan Perintah / Tool Call dari AI (misal: "read_file" / "execute_terminal_command")
    │
    ├─── [Jika Perintah Terminal] ────> [Popup Minta Izin (QMessageBox)]
    │                                                │
    │                                                ├─> [Yes] ──> Eksekusi Terminal
    │                                                └─> [No]  ──> Tolak Perintah
    │
    └─> Kirim respons jawaban teks secara *streaming* ke Chat Window
```

---

## 3. Struktur Direktori Utama

* `Jarvis/main.py`: File entri utama aplikasi untuk menginisialisasi Qt Application, Overlay, Chat, dan Tray.
* `Jarvis/assets/`: Berisi halaman HTML player (`player.html`), file JavaScript (`lottie.min.js`), serta file JSON animasi Lottie (`serious.json` dan `fun.json`).
* `Jarvis/config/`: Menyimpan konfigurasi lokal pengguna (`settings.json`) dan statistik harian (`usage_stats.json`).
* `Jarvis/core/`: Berisi logika mesin AI (`ai_engine.py`), manajemen file (`file_manager.py`), serta pelacakan token (`usage_tracker.py`).
* `Jarvis/ui/`: Desain antarmuka visual (`overlay_widget.py`, `chat_window.py`, dan file styling `styles.py`).

---

## 4. Pengaturan API Key di Berbagai Perangkat

Konfigurasi API Key diletakkan pada sebuah file bernama **`.env`** di dalam folder root aplikasi **`Jarvis/`** (sebaris dengan `main.py`).

### Cara Setup di Perangkat Baru:
1. Buka folder proyek Jarvis di perangkat tersebut.
2. Temukan atau buat file baru bernama **`.env`** di dalam folder `Jarvis/` (contoh: `Jarvis/.env`).
3. Masukkan kunci API masing-masing penyedia (provider) yang ingin Anda gunakan dengan format berikut:

```env
# API Keys untuk Jarvis Assistant
GROQ_API_KEY=gsk_xxx...
GEMINI_API_KEY=AQ.xxx...
GRAVITY_API_KEY=sk-xxx...
GRAVITY_API_BASE=http://localhost:20128/v1
```

### Penjelasan Kunci API & Tempat Mendapatkannya:
* **GROQ_API_KEY**: Digunakan untuk memanggil model cepat seperti `Llama 3.3 70B`. Dapatkan secara gratis/berbayar di [Groq Console](https://console.groq.com/).
* **GEMINI_API_KEY**: Digunakan untuk model multimodal Google Gemini langsung. Dapatkan di [Google AI Studio](https://aistudio.google.com/).
* **GRAVITY_API_KEY** & **GRAVITY_API_BASE**: Digunakan untuk memanggil agen AI lokal atau proxy kustom dengan protokol OpenAI. Secara default, ia mengarah ke `http://localhost:20128/v1`.

---

## 5. Cara Menjalankan Aplikasi (Run)

### A. Menggunakan Skrip Batch (Windows - Paling Praktis)
Cukup klik ganda pada file berikut di File Explorer:
`Jarvis/run_jarvis.bat`
*Skrip ini akan mengaktifkan virtual environment python secara otomatis dan menjalankan Jarvis di latar belakang tanpa meninggalkan jendela hitam CMD.*

### B. Menggunakan Terminal / PowerShell secara Manual
1. Buka PowerShell atau Command Prompt di direktori root proyek (`C:\Users\heker\Project`).
2. Jalankan perintah berikut:
   ```powershell
   Jarvis/venv/Scripts/python.exe Jarvis/main.py
   ```

---

## 6. Cara Menghentikan Aplikasi (Stop)

Asisten Jarvis berjalan sebagai ikon baki sistem (System Tray) dan gelembung melayang. Untuk menutupnya secara bersih:

### A. Melalui Menu Aplikasi
1. Klik kanan pada gelembung melayang Jarvis (Overlay Bubble) atau klik kanan pada ikon lingkaran biru di System Tray taskbar (pojok kanan bawah dekat jam).
2. Pilih opsi **Exit Jarvis**. Aplikasi akan menutup dengan aman setelah menyimpan posisi jendela Anda ke `settings.json`.

### B. Secara Paksa Melalui Terminal (Jika aplikasi hang/freeze)
Buka PowerShell dan ketik perintah berikut untuk membunuh proses Python:
```powershell
Stop-Process -Name "python", "pythonw" -Force
```

1. Bagaimana Cellya Mengakses GCR Tanpa Login Ulang? (Chrome Profile Sharing)

Google memiliki sistem keamanan yang sangat ketat untuk mendeteksi bot. Jika Cellya mencoba melakukan login GCR menggunakan email dan password secara otomatis (automated login), Google kemungkinan besar akan memblokirnya dengan verifikasi 2-langkah (2FA) atau mendeteksinya sebagai aktivitas mencurigakan.

Solusinya:
Cellya akan menjalankan browser Chrome otomatis (menggunakan Playwright atau Selenium) dengan memuat User Data Directory dari Google Chrome asli Anda di Windows.
Path default Chrome profile di Windows 11 biasanya terletak di:
C:\Users\<Username>\AppData\Local\Google\Chrome\User Data

Dengan memuat profil Chrome Anda, browser otomatis yang dibuka oleh Cellya akan:
- Mewarisi sesi login aktif (Active Session), cookies, dan akun Google Anda yang sudah masuk di laptop.
- Membuka classroom.google.com langsung dalam keadaan sudah login tanpa perlu memasukkan email/password lagi.

---
2. Bagaimana Alur Kerja Deteksi Kelas & Tugas?

1. Membuka & Scrape Daftar Kelas:
  - Cellya memicu browser terotomatisasi untuk pergi ke halaman utama GCR.
  - Membaca struktur HTML (DOM) untuk mengambil nama-nama kelas yang aktif.
  - Menampilkan daftar kelas di Chat Window Anda.
2. Membuka Kelas & Membaca Tugas:
  - Saat Anda menyuruh "buka kelas A", Cellya mengklik link kelas tersebut di browser.
  - Dia lalu mengarahkan ke tab "Classwork" (Tugas Kelas).
  - Membaca semua daftar tugas, mengambil tanggal tenggat (due date), judul tugas, dan deskripsi singkat.
3. Mengunduh & Membaca Lampiran:
  - Jika tugas memiliki lampiran (PDF, DOCX, CSV, atau Google Doc), Cellya akan menginstruksikan browser untuk mengunduh lampiran tersebut ke folder sementara di komputer Anda.
  - Menggunakan pustaka Python seperti pypdf (untuk PDF), python-docx (untuk dokumen Word), atau pustaka bawaan csv untuk membaca isinya dan merangkumnya kepada Anda.

---
3. Otomatisasi Pembuatan File Jawaban (DOCX, PDF, CSV)

Ketika Anda menyuruh Cellya untuk membuatkan jawaban tugas:
- Cellya akan memproses instruksi tugas tersebut menggunakan AI Engine.
- Cellya akan membuat folder baru di workspace lokal Anda, misalnya: C:\Users\heker\Project\Jarvis\Cellya_Tasks\Tugas_Matematika\.
- Cellya akan menulis file jawaban menggunakan pustaka Python:
  - python-docx: Untuk menghasilkan file dokumen .docx yang rapi dengan format paragraf, tabel, atau poin-poin.
  - csv / pandas: Untuk menghasilkan lembar kerja tabel .csv.
  - reportlab (atau parser teks ke PDF): Untuk membuat file .pdf.

---
4. Bagaimana Cara Membaca Google Forms?

Google Forms memiliki struktur HTML yang teratur:
- Pertanyaan biasanya dibungkus dalam elemen HTML tertentu dengan teks label pertanyaan yang jelas.
- Pilihan ganda (radio buttons) atau isian teks (text inputs) memiliki penanda atribut yang mudah dibaca oleh program scraper.
- Cellya akan membuka link Google Form di browser terotomatisasi (tetap menggunakan sesi akun Anda agar form yang butuh login institusi/sekolah tetap bisa dibuka).
- Dia akan membaca semua pertanyaan dari kode HTML Form, menyusunnya dalam ringkasan, lalu memberikan Anda analisis soal beserta saran jawaban terbaiknya.

---
Rencana Implementasi (Apa yang Perlu Kita Tambahkan ke Cellya):

Untuk mewujudkan ini, kita perlu menambahkan beberapa hal ke sistem Jarvis saat ini:
1. Instalasi Pustaka Pendukung:
  - playwright (atau selenium): Untuk mengendalikan browser Chrome.
  - python-docx: Untuk membuat dan menulis file .docx.
  - reportlab (atau pustaka PDF writer): Untuk membuat file .pdf.
2. Penambahan Tool Baru di AI Engine (core/ai_engine.py):
  - gcr_list_classes: Membuka browser, mengambil daftar kelas.
  - gcr_get_assignments(class_name): Mengambil daftar tugas dari kelas tertentu.
  - gcr_get_assignment_detail(assignment_name): Mengunduh file lampiran tugas dan mengekstrak rinciannya.
  - scrape_google_form(form_url): Membaca pertanyaan dari link Google Form.
  - generate_document_answer(filename, format, content): Membuat file DOCX/PDF/CSV berisi jawaban yang diformat rapi di folder khusus.

Bagaimana menurut Anda? Apakah kita ingin mulai merancang tool otomatisasi browser ini untuk Cellya Claire? Kita bisa memulainya dengan mendesain alur browser automation-nya terlebih dahulu agar aman dan tidak memicu proteksi Google.